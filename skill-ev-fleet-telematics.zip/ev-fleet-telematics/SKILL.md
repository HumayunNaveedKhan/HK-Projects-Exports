---
name: "ev-fleet-telematics"
description: >-
  Complete engineering context for the EV bike fleet telematics system (HS
  Solutions / Humayun Khan for Mentor Mobility, end client K-Electric): an
  ESP32 node reading a DALY BMS over BLE and GNSS over UART, remotely
  controlling the battery charge/discharge MOSFETs (immobilizer + charge
  control), logging to Google Sheets, and streaming live data to Firebase with
  a public dashboard. USE THIS SKILL WHENEVER the conversation touches this EV
  bike project or ANY module — MCU/ESP32, BMS/DALY/BLE, GNSS/GPS,
  GSM/4G/cellular/SIM7670G, dashboard/Firebase/Google Sheets, speedometer,
  temperature, load cells, OTA, immobilizer, cell balancing, or the custom PCB
  — even when the user names just one module without re-explaining the project,
  because this skill carries the shared hardware facts, verified 0xA5 protocol
  and MOSFET opcodes, pin maps, Firebase/Sheets config, and hard-won gotchas
  every module depends on. Also use it when starting a new module chat or asking
  about wiring, opcodes, MOSFET frames, SOC, or fleet scaling.
---

# EV Bike Fleet Telematics

This skill is the shared brain for an EV bike fleet telematics system. Read it
at the start of any chat about this project or one of its modules, then open the
one or two reference files relevant to the module you're working on. The
`references/` files hold the deep detail; this SKILL.md is the map plus the
facts every module needs.

> **READ FIRST — generations.** The body of this SKILL.md was written during
> **Gen 1** (ESP32-C3 · WiFi · Firebase + Google Sheets · GitHub Pages
> dashboard). Its **verified hardware facts, BLE/0xA5 protocol, MOSFET opcodes,
> safety interlock and gotchas remain authoritative.** Its **cloud
> configuration is superseded.** The current production line is **Gen 2**:
> ESP32-S3-WROOM-1 N16R8 · SIM800L 2G (→ SIM7670G 4G) · ThingsBoard ·
> **firmware v8.8.0**, plus a separate **Mk2 handlebar dashboard** S3.
> **Open `references/project-state-current.md` before answering anything about
> current state, versions, cloud config, deliverables or roadmap.**

## What the system is (60-second orientation)

An **ESP32 telematics node** on each electric bike that:
- reads a **DALY smart BMS** over **Bluetooth (BLE, 0xA5 protocol)** — pack
  voltage, current, SOC, per-cell voltages, temperature, faults, MOSFET states;
- reads a **GNSS module** over **UART** (NMEA) — position, speed, time;
- **controls the battery's charge and discharge MOSFETs** — used as a remote
  **immobilizer** (cut drive power) and **charge controller**;
- **logs history** to **Google Sheets** (~20 s cadence);
- **streams live data** to **Firebase Realtime Database** (~3 s) and receives
  control commands back through it;
- serves a **local web dashboard** (LAN / fallback WiFi AP) and a **public
  cloud dashboard** on GitHub Pages;
- updates firmware **over the air (OTA)**.

**Who / why:** built by **Humayun Khan (HS Solutions, Karachi)** as telematics
architect for **Mentor Mobility**'s EV bike fleet; end client **K-Electric
(KE)**. Pilot = **100 bikes**, then scale. Humayun builds everything *except*
the BMS (bought: DALY) and the motor controller.

**Prototype MCU:** ESP32-C3 SuperMini. **Production:** ESP32-S3-WROOM-1-N16R8 on
a custom PCB with a separate 4G modem (SIM7670G), separate GNSS, and SD card.
**Uplink now:** WiFi. **Migrating to:** 4G cellular.

## Current main deliverables (the files to build on)

- Firmware: **`evbike_node_v4_latching.ino`**
- Public dashboard: **`index_v5_pro.html`**
- Apps Script: **`evbike_sheets_v4.gs`**
- Bench MOSFET tester (keep as a tool): `daly_mos_bench_test_c3.ino`

If the user has these files, build on them rather than starting fresh. If not,
the reference files here contain everything needed to regenerate them.

## The three-subsystem, always-on architecture

The BMS link, GNSS, and network are **independent**; any one can fail without
stopping the others.
- **Network down** → GPS + BMS keep running; node raises its **own fallback
  WiFi AP** (`EVBIKE-01` / `evbike1234` @ `192.168.4.1`) so the dashboard and
  controls still work; keeps retrying, drops AP on recovery.
- **BMS out of BLE range** → GPS + logging continue; dashboards show **"NOT IN
  RANGE"** and dim the battery panel (never show stale numbers as if live).
- **GPS lost** → BMS + logging continue; dashboards show **"NO FIX."**
- **Logging** runs on its own timer and records whatever is valid, tagging each
  row with which subsystems were live (so a parked/stolen bike is still
  tracked).
- **LED (GPIO8, active-LOW):** fast blink = BMS out of range; slow blink =
  offline; solid = all good.

## Facts every module shares (memorize these)

- **BMS BLE name:** `DL-1771060607EB`. **Only ONE BLE central allowed — CLOSE
  THE DALY PHONE APP** or the ESP32 can't connect. (#1 cause of "won't
  connect.")
- **BLE GATT:** service `FFF0`, notify `FFF1`, write `FFF2`, no pairing.
- **Protocol:** DALY **0xA5**, 13-byte frames, checksum = `sum(bytes 0..11) &
  0xFF`.
- **MOSFET control (VERIFIED ON HARDWARE):** charge cmd `0xDA`, discharge cmd
  `0xD9`, write address `0x40`. Frame:
  `A5 40 <cmd> 08 <01=on|00=off> 00 00 00 00 00 00 00 <cksum>`. BMS echoes back
  `A5 01 <cmd> 08 <state> ...`.
- **DISCHARGE IS THE MASTER SWITCH (undocumented, verified):** discharge OFF
  forces charge OFF; the BMS refuses charge ON while discharge is OFF.
- **Current sign:** negative = discharge, positive = charge.
- **SOC comes from the BMS**, never from voltage (LiFePO4 curve is flat).
- **Pack:** 15S LiFePO4, ~60 Ah, ~2.88 kWh, 48 V nominal / 54.75 V full.
- **MCU (proto):** ESP32-C3, LED GPIO8 active-LOW, **USB CDC On Boot = Enabled**,
  partition **"Minimal SPIFFS (1.9MB APP with OTA)"**, libs **NimBLE-Arduino +
  TinyGPSPlus**.
- **Safety interlock (firmware-enforced):** discharge-OFF refused unless GPS
  speed < 3 km/h AND |current| < 5 A. Discharge-ON and both charge commands
  always allowed.

## Firebase / Sheets config (real values)

- **RTDB host:** `ev-bike-fleet-telematics-default-rtdb.firebaseio.com`
- **Web API key** (public by design — identifies the project, does not grant
  access): `AIzaSyCd0iCbS4KB_EO2cMjwEhCcw0MfFzMTEr4`. Goes in firmware
  `FB_APIKEY` and dashboard `CFG.apiKey`.
- **Device account:** `node@evbike.local` + a password you invent (`FB_PASS`).
- **DB keys:** `/bike` (telemetry out), `/cmd` (control in), `/ack` (result out).
- **DB rules:** `auth != null` on `/bike`, `/cmd`, `/ack` (mandatory before
  going live — control is a safety system).
- **Sheet ID:** `1VKMw7wuelku01M2dsu_t3gtN8feR2PtOdl5g7icAB4Q`
- **Apps Script `/exec` deployment ID:**
  `AKfycbw_DGzUBRAdccXSBPSbGTc_Sm1mp582IAf1xhaVuF3JJ-DUlzbDNk-aPIGIK1abe0H0`
- **Public dashboard:** https://humayunnaveedkhan.github.io/EV-DB/ (repo
  `EV-DB`, file saved as `index.html`).

## Top gotchas (check here first when debugging)

1. **DALY app open** → BLE won't connect. Close it.
2. **Apps Script 302:** `/exec` returns a 302; the row is only written if the
   redirect is followed. Use `setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS)`.
3. **WAN command bug (fixed):** dashboard sends `ts: Date.now()` (13 digits);
   parsing it as `uint32_t` **overflows** and corrupts the dedup so WAN commands
   are swallowed. Dedup `ts` as a **string**. (LAN has no ts, so it always
   worked — that's how it was isolated.)
4. **Partition too small:** default 1.31 MB fails at ~101% with BLE+WiFi+TLS.
   Use Minimal SPIFFS (1.9MB APP with OTA).
5. **C3 nothing on serial:** enable USB CDC On Boot; press RESET after upload;
   re-select the port; suspect a charge-only USB cable.
6. **`'X' does not name a type` compile error:** a non-ASCII / smart-quote char
   inside the `R"HTML(...)HTML"` dashboard string terminates it early. Keep
   embedded HTML all-ASCII (entities like `&deg; &middot;`); download files,
   don't copy-paste.
7. **MOSFET control reliability:** the real fix is the **strict BLE interlock**
   (`if(mos.busy) return;` in `pollBms`) so read frames never collide with the
   write frame — plus retry, echo-detection, and a latching engine that
   re-asserts the commanded state on drift.
8. **No position-history array in Firebase** (86 MB/bike/day on cellular); the
   trail lives in the browser.

## How to use this skill per module

Read the reference file(s) for the module in play. Each file assumes the shared
facts above and adds module-specific depth.

| Module / topic | Read |
|---|---|
| **Current state, firmware versions, cloud config, deliverables, roadmap** | **`references/project-state-current.md`** (start here) |
| Owner profile, stakeholders, privacy boundary, scope | `references/profile-and-scope.md` |
| Consolidated gotcha ledger | `references/learnings-ledger.md` |
| Working style, conventions, toolchain | `references/working-style.md` |
| Hardware, wiring, pin maps, PCB, power, BOM | `references/hardware.md` |
| MCU / ESP32 firmware structure, build, OTA, loop | `references/mcu-firmware.md` |
| BMS, BLE, 0xA5 protocol, MOSFET control, immobilizer | `references/bms-ble.md` |
| GNSS / GPS wiring, NMEA, trip distance | `references/gnss.md` |
| GSM / 4G / cellular / SIM7670G migration | `references/gsm-cellular.md` |
| Dashboard, Firebase, Google Sheets, backend | `references/dashboard-cloud.md` |
| Speedometer, temperature, load cells (new/planned modules) | `references/sensors-new-modules.md` |
| Vision, fleet scaling, RBAC, commercials | `references/vision-scaling.md` |

**When several modules interact** (e.g. "push speedometer data to the
dashboard"), read both files. **When starting a fresh module chat**, read this
SKILL.md plus that module's reference before proposing anything, so the shared
protocol and pin facts are honored and nothing regresses.

## Working style that fits this project

- **Verified hardware facts are ground truth.** Don't re-derive opcodes,
  pinouts, or the discharge-master behavior — they were confirmed on the bench.
- **Validate embedded HTML** (ASCII-only, balanced raw-string delimiters,
  balanced braces/parens, all JS element IDs present) before handing over
  firmware or dashboards — this project has repeatedly hit the smart-quote
  raw-string trap.
- **Safety first on control:** never weaken the immobilizer speed/current
  interlock or the auth rules on the database.
- Prefer building on the current main files over rewriting from scratch.
