---
name: overview
description: EV bike fleet telematics for Mentor Mobility (K-Electric, TCS clients) — Humayun's roles, credentials, node/dash firmware state, cloud setup, CV work
sources: [backfill]
aliases: [EV telematics, EVBIKE-01, Mentor Mobility EV fleet, EV bike fleet telematics]
---

## Who and where

- Humayun Naveed Khan is an R&D engineer and Team Lead at the HHRCM Lab, NCRA-NEDUET, Karachi
- CTO and Co-Founder of two NIC Karachi-incubated startups: Haptronica and RobAutoStem
- Works as an independent technical consultant; affiliated with HS Solutions
- Appointed to a senior R&D management role at Thal Engineering (Deputy Manager R&D)
- Has completed a short industrial consultancy engagement (Thal 500A industrial contactor)
- Credentials: 7 patents filed (1 granted, IPO Pakistan No. 144343), 20 peer-reviewed publications, PKR 95M+ in managed funding, 8 products delivered to industrial customers, PKR 1M Sindh Innovative Startup Awards 2025 winner, M.Eng. CGPA 3.89, B.E. CGPA 3.60
- Contact and profiles: linkedin.com/in/humayunnaveedkhan | github.com/HumayunNaveedKhan | humayunnaveedkhan.github.io/portfolio | ORCID 0009-0003-1109-1120

## Project purpose

- Primary ongoing project is an EV bike fleet telematics platform built for Mentor Mobility, with K-Electric and TCS as end clients
- Target is a 100-bike pilot deployment in Karachi
- System spans two ESP32-S3 nodes — a telematics node (ESP32-S3-WROOM-1 N16R8) and a Mk2 handlebar LED dashboard (also ESP32-S3)
- The two nodes are connected via bidirectional UART: node GPIO15/TX → dash GPIO16/RX; node GPIO16/RX ← dash GPIO15/TX (straight-through wiring is incorrect)

## Current state — telematics node (firmware v8.8.0)

- BMS communication over BLE using DALY 0xA5 protocol (NimBLE 2.x API)
- GNSS via Ebyte E108-GN03D (AT6558R chipset, concurrent multi-constellation)
- Cellular uplink via SIM800L (Jazz SIM, APN: `jazzconnect.mobilinkworld.com`) to ThingsBoard MQTT
- MOSFET immobilizer with three-state machine (IMM_IDLE / IMM_PENDING / IMM_LATCHED)
- LittleFS offline queue with ~588 hours buffer capacity
- ThingsBoard OTA with MD5 verification and resume capability
- NVS-persisted odometer and bidirectional dash link (dash_link.h v3)
- Two-tier telemetry cadence: 30s fast / 900s slow
- Engineering telemetry keys prefixed with `e_` (e_rpm, e_gear, e_tmot, e_tctl)
- Custom partition table: 2 MB app slots, 11.875 MB LittleFS

## Current state — Mk2 dashboard (full S3 rewrite)

- Three-chip MAX7219 cascade via hardware SPI at 8 MHz with dirty-digit tracking at 60 Hz
- Chip A: 47 status LEDs; Chip B: 3× 5161AS speed digits; Chip C: 8-digit odometer module
- TM1637 trip display
- 11 optocoupler inputs (ignition, 3 safety switches, 4 gear trip switches, hall RPM)
- 2× DS18B20 temperature sensors
- Brightness button on GPIO18; trip-reset switch on GPIO17 (10-second hold)
- Attract animation (dim comet, 5s) for BMS-offline state
- Bulb check on ignition rising edge
- 8-second task watchdog with safe `waitMs()` replacements
- Per-channel opto inversion stored in NVS
- WiFi as a 20-second opt-in button hold (FreeRTOS task, core 0)
- Blocking diagnostics refused while moving
- Validated LED map (as-built physical layout): safety=1, emergency=2, breaker=3, Ind R=4, headlight=5, Ind L=6, BMS OK=7, BMS hot=8, SOC 9–18, controller OK=19, controller hot=20, current 21–30, motor OK=31, motor hot=32, RPM 33–42, gears G4→N descending 43–47

## Current state — known outstanding issues

- Brownout resets during GSM registration (SIM800L power rail)
- BLE link dropping silently (blerc 0x08/0x13 — possible rail or app interference)
- IGN_ENABLED pending physical optocoupler wiring; BENCH_MODE still at 1
- TLS (item 12) and 4G LTE (item 15) pending SIM7670G module
- ThingsBoard Cloud Free constraints: 1M data point/month cap (at ~86% utilization with one bike), 30-day TTL, 5-device ceiling

## Current state — cloud and backend

- ThingsBoard Cloud Free (EU Frankfurt, `mqtt.eu.thingsboard.cloud` port 1883)
- Oracle Cloud was rejected due to card authorization issues
- Tailscale Funnel used as interim public access; DuckDNS domain `mmevfleet.duckdns.org`
- Device ID: `30b150d0-9001-11f1-be6c-6b7076fe8a8d`; BIKE_ID: `EVBIKE-01`; EU region tenant
- Firmware version format: bare semver (e.g. "8.4.0"); FW_TITLE: "EVBIKE-FW"
- Three-stakeholder dashboard architecture: role-based dashboards for K-Electric, TCS and Mentor Mobility with a hard privacy boundary enforced at the API layer — MM never receives GPS coordinates or rider identities; KE never receives rider names; bikes appear as anonymized asset IDs
- Recommended dashboard build order: TCS first, then KE, then MM

## Current state — CV and resume work

- Full CV was updated (DOCX, XML-level manipulation to preserve formatting)
- Targeted resumes produced for: Head of Technology (KeyMik, remote), contract Electrical Engineer (Hire Feed/micro1), and industrial R&D (Thal Engineering)
- The Thal resume deliberately excludes the EV/bike project and E-BEX by name but includes their derived skills (LiFePO4 BMS, wide-input DC-DC, TVS, reverse-polarity protection, Hall-effect sensing, GNSS, cellular connectivity)
- The Deputy Manager R&D title is not to appear on documents submitted to Thal
- The Thal 500A industrial contactor consultancy is compressed to a single professional line
- J&P Coats projects show Humayun as Co-Lead
- Lab title must always be written "HHRCM Lab NCRA-NEDUET"; role is "Team Lead" (not "Team Lead R&D")

## On the horizon

- Merging the two ESP32-S3 nodes into a single unit is technically feasible (5.5% CPU, 43% RAM, 2 spare pins) but deferred to a possible v9.0.0 once dashboard firmware is stable; rationale is protecting deployed production telematics firmware and preserving independent OTA at 100-bike scale
- SIM7670G Cat-1 module delivery to enable 4G LTE and TLS support
- Self-hosted ThingsBoard migration (Docker stack with Caddy HTTPS + nginx MQTT stream) to Oracle Cloud Always Free — pending card/provisioning resolution; A1 capacity retries ongoing
- Scaling from single-bike bench prototype to 100-bike pilot
- ThingsBoard monthly data exports (Python tool `tb_export.py` + GitHub Actions weekly backup workflow in place)
