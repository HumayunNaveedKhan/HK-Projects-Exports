# GNSS / GPS module

Module: **Ebyte E108-GN03D** (AT6558R), multi-constellation. All facts VERIFIED.

## Electrical / serial
- UART, **9600 baud, 8N1**, standard NMEA sentences.
- **3.3 V native — no level shifter** with ESP32.
- Wiring to ESP32-C3: GPS **TXD → GPIO4** (the data wire that matters — module
  output into ESP RX), GPS **RXD → GPIO5** (optional, only to command the GPS),
  VCC → 3V3, GND → GND.
- ⚠️ **Wire by silkscreen label, not ribbon color** — colors differ per unit.
  On the tested unit: red=VCC, black=GND, yellow=TXD, green=RXD, blue=1PPS,
  white=ON_OFF.

## Firmware
- `HardwareSerial GPSS(1); GPSS.begin(9600, SERIAL_8N1, GNSS_RX=4, GNSS_TX=5);`
  with `setRxBufferSize(1024)`.
- Parse with **TinyGPSPlus**. Feed it every loop: `while(GPSS.available())
  gps.encode(GPSS.read());` — call this `gnssFeed()` and run it first in the
  loop and inside every blocking wait so NMEA is never dropped.
- Fields used: `location.lat/lng`, `speed.kmph`, `satellites.value`,
  `hdop.hdop`, `time`/`date`. Local time = UTC+5 (Pakistan).

## Confirmed fix
25.007362°N, 67.071099°E, HDOP 1.4, 10 sats, <10 m (indoor test).

## Behaviors / gotchas
- **"ANTENNA OPEN" NMEA message is non-fatal** — onboard element works.
- **Cold start after long storage takes several minutes.** The library doesn't
  affect acquisition time, only parsing. Add an RTC/coin-cell on the PCB for
  warm starts.
- **Talker IDs are GN/BD/GL** (multi-constellation), not just GP — match
  RMC/GGA by suffix, not a "GP" prefix.
- GPS-silent debug ladder: module LED off / no power → GND miswired to a GPIO;
  module LED on but no data → TXD not on the ESP RX pin (swap TX/RX).

## Trip distance (billing-critical)
Accumulate haversine between consecutive fixes **only when speed > 3 km/h and
the jump is 1–200 m**. This rejects GPS wander while parked, which would
otherwise inflate mileage — and KE will audit per-km figures, so this matters.
Status flag `gps` = valid && age<8 s && nonzero lat.

## Cellular note
When moving to the SIM7670G data-only modem, GNSS stays a **separate** module
(L76K / u-blox). If ever using an integrated-GNSS modem (A7670G-LABE), the
wiring above still applies to whatever GNSS chip is chosen. See
`gsm-cellular.md`.
