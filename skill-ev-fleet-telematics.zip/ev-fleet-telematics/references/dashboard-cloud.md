# Dashboard · Firebase · Google Sheets — the cloud/backend

Main dashboard: **`index_v5_pro.html`**. Main script: **`evbike_sheets_v4.gs`**.

## Data path
```
ESP32  --PUT /bike (3s)-->  Firebase RTDB  --realtime-->  public dashboard
       --GET /cmd (2s)---   Firebase RTDB  <--set /cmd--   (dashboard control)
       --PUT /ack------->   Firebase RTDB  --realtime-->   (dashboard result)
       --GET (20s)------>   Google Sheets (history)
       --serves-------->    local page (LAN / fallback AP)
```

## Firebase — real values & setup
- **RTDB host:** `ev-bike-fleet-telematics-default-rtdb.firebaseio.com`
- **Web API key:** `AIzaSyCd0iCbS4KB_EO2cMjwEhCcw0MfFzMTEr4`
  - This is the **Web API Key** (Project settings → General → Web API Key), NOT
    the DB URL. **Public by design** — it identifies the project, it does not
    grant access. Goes in firmware `FB_APIKEY` and dashboard `CFG.apiKey`.
- **Device account:** `node@evbike.local` + a password you invent (`FB_PASS`).
- **Dashboard account:** your own email + password.

One-time console setup:
1. Authentication → Sign-in method → enable **Email/Password**.
2. Authentication → Users → Add user: `node@evbike.local` (firmware) and your
   own email (dashboard login).
3. Realtime Database → Rules → publish:
```json
{ "rules": {
    "bike": { ".read": "auth != null", ".write": "auth != null" },
    "cmd":  { ".read": "auth != null", ".write": "auth != null" },
    "ack":  { ".read": "auth != null", ".write": "auth != null" }
}}
```
**Mandatory before going live** — control is a safety system; an open DB lets a
stranger cut a rider's power.

## Database keys
- **`/bike`** — node PUTs full telemetry every ~3 s; dashboard subscribes.
- **`/cmd`** — dashboard writes `{ fet:"chg|dsg", on:0|1, ts:Date.now(), by:email }`;
  node polls.
- **`/ack`** — node writes `{ ts:<same>, msg, chg, dsg }`; dashboard subscribes.

## Telemetry payload fields (`/bike`, built by `fbPayload()`)
`id,tgt,net,bmsok,gpsok,ip,wrssi,rssi, v,i,ichg,idsg,pkchg,pkdsg,kw,soc,ah,ahn,
cyc,ns,ein,eout,avg,dmv,mn,mni,mx,mxi,hv,t,st,chg,dsg,bal,life, lat,lon,spd,sat,
hdop,km,clk, busy,tchg,tdsg,canoff,canchg,why,mres, lg,lf,lmsg,up,ts, c[],f[]`.
(`ichg/idsg` = split positive charge/discharge amps; `pkchg/pkdsg` = session
peaks; `tchg/tdsg` = latch targets, -1 unset; `canoff/canchg` = whether
discharge-off / charge-on is currently allowed; `c[]` = cell mV; `f[]` = fault
strings.)

## THE WAN COMMAND BUG (fixed — remember this)
The dashboard sends `ts: Date.now()` — a 13-digit ms value (e.g.
`1784931893271`). Early firmware parsed it into a **`uint32_t`** (max ~4.29e9),
which **overflowed and corrupted the dedup check**, so **every WAN command was
silently swallowed**. LAN worked because `/api/mos` sends no `ts` — that's how
it was isolated. **Fix:** parse and dedup `ts` as a **string** (`lastCmdId`),
loose-compare the ack `ts`, add ack retry + an offline-BMS ack so the dashboard
never hangs on "waiting."

## Public dashboard — `index_v5_pro.html`
- Deploy: save as `index.html` in the **`EV-DB`** repo root, push. Live at
  **https://humayunnaveedkhan.github.io/EV-DB/**.
- Fill `CFG` (apiKey already set; add authDomain/databaseURL/projectId).
- **Design:** "Mentor Mobility Fleet Console." Slate/graphite palette, single
  amber signal accent; Archivo (display) + IBM Plex Mono (all live numbers) +
  Inter (body). Signature = the **status ledger** (Vehicle/Battery/Position
  tracks) at top. SOC dial + vitals, bidirectional current-flow bar, Leaflet map
  (dark-inverted tiles, browser-side trail), iOS toggle sliders.
- **Auth gate** is the real access control (page JS is public). Toggles flip
  from the confirmed hardware state and disable when an action can't succeed
  (charge locked while discharge off; discharge-off locked while moving/≥5 A).
- Control round trip ~3–6 s: toggle → `/cmd` → node → `/ack` → result shown.

## Local diagnostic page
Served by the firmware at `http://<ip>/` (and `192.168.4.1` on the fallback AP).
Compact status + LAN control via `/api/mos?fet=chg|dsg&on=0|1`, telemetry via
`/api/data`. Offline/field fallback; no internet or Firebase needed.

## Google Sheets — `evbike_sheets_v4.gs`
- **Sheet ID:** `1VKMw7wuelku01M2dsu_t3gtN8feR2PtOdl5g7icAB4Q`
- **`/exec` deployment ID:**
  `AKfycbw_DGzUBRAdccXSBPSbGTc_Sm1mp582IAf1xhaVuF3JJ-DUlzbDNk-aPIGIK1abe0H0`
- `SECRET` stays `''` unless you add a matching `&key=` in firmware.
- v4 columns: GPS, split charge/discharge current + peaks, SOC, energy in/out,
  cell stats, temp, health, MOSFET states, faults, RSSI, **BMS Live** flag.
- **When BMS not live, battery columns are written blank** (not stale) — filter
  `BMS Live = YES` before energy/SOC analysis.
- **Color coding:** run `setupFormatting()` once — health green/amber/red,
  MOSFET ON/OFF green/red, faults red, current gradients, SOC + spread
  gradients, greyed offline rows.
- Uses `openById`, `LockService`, and returns after the 302 is followed.
- **Deploy update:** Manage deployments → Edit (pencil) → **New version** →
  Deploy (keeps the `/exec` URL).

## Two gotchas that bite here
1. **Apps Script 302:** the row is only written if the redirect is followed —
   firmware must use `setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS)`.
2. **A Google Sheet cannot host live control buttons** — it's a log, not a
   control surface. Control lives on the dashboard (live Firebase link); the
   sheet records the resulting MOSFET state per row as an audit trail.

## Dashboard lineage (reference)
`evbike_dashboard.html` (standalone + demo mode) → `index.html` →
`index_v3_final.html` → `index_v4_latching.html` → **`index_v5_pro.html`**.

## Validate before shipping a dashboard
ASCII-only if it'll be embedded in firmware; balanced tags; every `$('id')`
resolves to an HTML `id`; Firebase + Leaflet imports present; CFG filled. A
quick demo-data render (bypass the login, call `paint(demo)`) catches layout
issues before deploy.
