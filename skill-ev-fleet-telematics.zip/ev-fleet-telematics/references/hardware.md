# Hardware — BOM, wiring, pin maps, power, PCB

All facts marked **VERIFIED** were confirmed on the physical bench. Do not
re-derive them.

## Battery pack (VERIFIED)
- 15S LiFePO4 (15 cells in series).
- ~60 Ah, ~2.88 kWh.
- 48 V nominal, **54.75 V full** (15 × 3.65 V), ~40 V empty.
- New pack, ~25 cycles at test time; cell delta 2–6 mV at rest.
- **LiFePO4 voltage curve is flat → never estimate SOC from voltage. Read SOC
  from the BMS.**

## BMS — DALY Smart BMS (VERIFIED)
- Hardware ID `BMS-GD230-309E`; BLE name `DL-1771060607EB`.
- DALY 0xA5 protocol tunneled over BLE. 1 temperature sensor.
- GATT: service `FFF0`, notify `FFF1`, write `FFF2`, no pairing.
- **Single BLE central only — close the DALY phone app.**
- Full protocol + control details: see `bms-ble.md`.

## GNSS — Ebyte E108-GN03D (VERIFIED)
- AT6558R chipset, multi-constellation (GPS/BeiDou/GLONASS).
- UART, 9600 8N1, NMEA. 3.3 V native — no level shifter.
- Confirmed fix: 25.007362°N, 67.071099°E, HDOP 1.4, 10 sats, <10 m.
- Ribbon colors on the tested unit (⚠️ **wire by silkscreen label, not color**):
  red=VCC, black=GND, yellow=TXD, green=RXD, blue=1PPS, white=ON_OFF.
- Wiring to ESP32-C3: GPS **TXD→GPIO4**, GPS **RXD→GPIO5** (optional), VCC→3V3,
  GND→GND.
- "ANTENNA OPEN" NMEA message is non-fatal. Cold start after storage can take
  minutes. More in `gnss.md`.

## MCU
- **Prototype:** ESP32-C3 SuperMini. LED on **GPIO8, active LOW**. **USB CDC On
  Boot must be Enabled.**
- **Production:** ESP32-S3-WROOM-1-**N16R8** (16 MB flash / 8 MB PSRAM) on a
  custom PCB.

## Pin map (ESP32-C3 prototype)
| Signal | Pin | Notes |
|---|---|---|
| Status LED | GPIO8 | active LOW (onboard) |
| GNSS RX (into ESP) | GPIO4 | connect to GPS TXD |
| GNSS TX (out of ESP) | GPIO5 | connect to GPS RXD (optional) |
| BMS | — | wireless BLE, no pins |

## Cellular modem selection (SELECTED, not yet integrated)
- **Chosen:** SIM7670G data-only (global Cat-1 LTE); pair with a separate GNSS
  (L76K ~PKR900, or u-blox NEO-M8N / MAX-M10S).
- Also acceptable: A7670G-LABE (integrated GNSS; ~PKR600/unit more than
  data-only + separate GNSS).
- **Hard rules:** global bands (never `-CN`/China-locked); UART + AT + English
  docs; if module UART is 1.8 V it needs a level shifter to 3.3 V on the S3.
- **Rejected (don't re-suggest):** SIM7670G mPCIe (wrong form factor, USB-not-
  UART risk, 2.7× price); EG800Z-CN (China bands, no GNSS on data variant);
  ML307R (China Mobile locked, no GNSS, thin docs).
- 2G bench modem on hand: SIM800L (own 3.7–4.2 V rail + fat cap; AT code carries
  forward). Full migration plan in `gsm-cellular.md`.

## Power & protection (production PCB)
- Main buck must accept **≥100 V input** (e.g. MP9486A class) — **not LM2596**.
- Cellular modem gets its **own ~3.8 V regulator + 1000 µF bulk cap** (LTE
  bursts brown out shared rails).
- Front-end: **fuse → SMBJ58A TVS → reverse-polarity MOSFET**.
- **Keep LTE antenna away from GNSS antenna** (desense).
- Size fuses / DC-DC from **measured peak charge/discharge amps** — the firmware
  tracks `pkchg` / `pkdsg` for exactly this.
- Add an **RTC / coin-cell** so GNSS can warm-start (cold start after storage is
  slow).

## Planned sensor additions
Speedometer, temperature (beyond the BMS's one sensor), and load cells are
planned modules. See `sensors-new-modules.md` for integration approach and free
GPIO considerations.
