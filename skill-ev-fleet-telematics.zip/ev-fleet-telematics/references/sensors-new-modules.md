# New / planned modules — speedometer, temperature, load cells

These are modules to add to the node. None are finalized yet — this file
captures the intended approach and the constraints they must respect (shared
pins, the always-on architecture, the data pipeline). When building one, also
read `mcu-firmware.md` (loop/timing/pins) and `dashboard-cloud.md` (how to
surface the data).

## Integration principles (apply to every new sensor)
- **Own timer, non-blocking.** Add the sensor read as another timed task in the
  loop; never block BLE/GPS/web/OTA. Keep `gnssFeed()` pumping during any wait.
- **Add fields to `fbPayload()`**, not a separate uplink — one payload keeps the
  dashboard and Sheets in sync. Add matching columns to `evbike_sheets_v4.gs`
  and a matching readout to `index_v5_pro.html`.
- **Respect the status model.** If a sensor can be absent/faulted, give it a
  validity flag so the dashboard can show "no data" instead of a stale number.
- **Watch the ESP32-C3 pin budget.** GPIO4/5 are GNSS, GPIO8 is the LED. On the
  production ESP32-S3 there's far more IO — prefer to prototype a pin, then
  finalize on the S3 PCB.

## Speedometer
Two viable sources:
1. **GPS speed** (already available: `gps.speed.kmph()`). Zero extra hardware,
   good above ~5 km/h, poor at very low speed and briefly stale on fix loss.
   Best default for the dashboard's "Speed" readout.
2. **Wheel/hall sensor** for instantaneous, low-speed-accurate speed and a true
   odometer: a hall sensor + wheel magnet(s) → count pulses on an interrupt,
   speed = pulses × circumference / time. Needs one GPIO with interrupt; debounce
   in ISR; store an odometer total (survives with the RTC/flash on the S3).
- **Recommended:** fuse both — hall for instantaneous/low-speed + odometer, GPS
  as sanity check and fallback. Feed the dashboard from the hall speed when
  available, GPS otherwise.
- Belongs in the bike node (not the dock).

## Temperature
- The DALY BMS already reports **one pack temperature** (0x96). For more coverage
  (motor, ambient, charger), add dedicated sensors.
- **DS18B20** (1-Wire) is the natural choice: multiple sensors on one GPIO, each
  addressable, 3.3 V, well-supported (OneWire + DallasTemperature libs). One
  data pin + 4.7 kΩ pull-up.
- Add each as `t_motor`, `t_amb`, etc. in the payload; gate alarms so a
  disconnected sensor reads "no data," not a wild value.
- Keep the BMS temp as the authoritative pack temp; added sensors are
  supplementary.

## Load cells (rider/cargo weight)
- **HX711** 24-bit ADC + a load cell (or 4 in a Wheatstone bridge for a
  platform). Two GPIOs (DOUT + SCK), bit-banged; 3.3 V.
- Use case: rider/cargo weight, tamper/theft detection (weight change while
  parked), load-based range estimation.
- Calibrate with known masses → store scale factor + tare offset (in flash/RTC).
- Read slowly (HX711 is 10–80 SPS); average several samples; add `load_kg` to the
  payload with a validity flag.
- Mechanical mounting matters more than the electronics — the cell must see the
  actual load path.

## How these reach the user
Every sensor value flows the same way: firmware reads it → adds it to
`fbPayload()` → appears live on `index_v5_pro.html` (add a readout tile) and in
`evbike_sheets_v4.gs` history (add a column, extend `setupFormatting()` if it
needs color). No new transport, no new backend.

## Fleet-view caveat
Some of these (load, precise location, speed profile) are rider-behavior data.
Per the RBAC intent (see `vision-scaling.md`), the OEM should get **battery
diagnostics only**, not rider behavior — keep that boundary in mind when
deciding which new fields are exposed to which audience.
