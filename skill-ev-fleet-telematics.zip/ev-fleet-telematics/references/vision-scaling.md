# Vision · fleet scaling · RBAC · commercials

## The vision
Mentor Mobility runs/pilots a fleet of electric bikes; end customer is
**K-Electric (KE)** (ecosystem also mentions PSO, TCS). Pilot = **100 bikes**,
then scale. Humayun Khan / HS Solutions (Karachi) is the telematics architect and
builds everything except the BMS (DALY) and motor controller: sensors, IoT node,
firmware, data pipeline, cloud, dashboard.

## Current stage
Working prototype on ESP32-C3 over WiFi: BMS telemetry, GPS, verified remote
MOSFET control (immobilizer + charge), Google Sheets history, Firebase live
dashboard with control. Next: harden control (done — interlock + latching),
migrate to ESP32-S3 + custom PCB + 4G cellular, add speedometer/temp/load-cell
modules.

## Scaling considerations (100 bikes and beyond)
- **Backend:** Firebase + Sheets is a **pilot** backend. At fleet scale move to
  **ThingsBoard / MQTT** with a time-series DB and role-based access control.
- **RBAC / data ownership (important design tension):** the OEM should receive
  **battery diagnostics only**, NOT rider location or behavior. KE, the fleet
  operator, and the OEM need different views. The current single-project Firebase
  does not enforce per-role boundaries — that's a scale-up task.
- **Public / KE read-only view:** do NOT loosen the auth rules to share data.
  Build a **separate node/path exposing only non-sensitive fields**.
- **Immobilizer** must keep the speed=0 + low-current interlock — never a remote
  cut on a moving bike.
- **Charger 220 V control** belongs in the charging dock, not the bike node.
- **Data integrity for billing:** trip distance uses the parked-wander rejection
  (speed>3 km/h, 1–200 m jumps) specifically because KE will audit per-km and
  energy figures. Keep energy counters (kWh in/out) and BMS-Live flagging honest.

## Telemetry rows to add as it scales
kWh totals, charger-plugged detection, odometer, geofence, crash/IMU detection,
device health/heartbeat. (Speedometer/temperature/load-cell modules in
`sensors-new-modules.md` cover some of these.)

## Commercial context
Terms were drafted between Mentor Mobility and HS Solutions: a development fee
plus milestone payments, a component advance, and production at cost+30% fixed at
PCB finalization. **IP intended to be owned by Mentor Mobility with Humayun named
as inventor.** The agreement is likely legally binding — **a Pakistani lawyer
should review it**, especially the IP and production-rights clauses. (This is
context, not legal advice; when asked, be factual and recommend professional
review rather than opining.)

## Production hardware direction
ESP32-S3-WROOM-1-N16R8 on a custom PCB; separate SIM7670G 4G modem; separate
GNSS; SD card; ≥100 V buck; modem on its own 3.8 V rail + bulk cap; fuse → TVS →
reverse-polarity FET; RTC/coin-cell for GPS warm start. See `hardware.md` and
`gsm-cellular.md`.
