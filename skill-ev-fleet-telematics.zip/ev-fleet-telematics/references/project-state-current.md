# HK-EV-Fleet-Telematics — Complete Project Export

**Exported:** 9 October 2026
**Owner:** Humayun Naveed Khan — HS Solutions / HHRCM Lab, NCRA-NEDUET, Karachi
**Client:** Mentor Mobility · **End clients:** K-Electric (KE), TCS
**Purpose of this document:** a single, self-contained transfer of the whole project — scope, architecture, every firmware generation and its state, verified hardware facts, cloud configuration, delivered artefacts, learnings, open issues and roadmap — so a fresh Claude account can pick the project up with no loss of context.

---

## 0. How to read this document

The project has run through **two hardware/cloud generations plus a dashboard sub-project**. A lot of confusion is avoidable if you keep them separate:

| Generation | MCU | Uplink | Backend | Status |
|---|---|---|---|---|
| **Gen 1** (pilot) | ESP32-C3 SuperMini | WiFi | Firebase RTDB + Google Sheets + GitHub Pages dashboard | **Superseded** — kept as reference and as the source of the verified BMS protocol work |
| **Gen 2** (current production line) | ESP32-S3-WROOM-1 N16R8 | SIM800L 2G (→ SIM7670G 4G) | ThingsBoard (Cloud Free EU; self-hosted planned) | **Active — firmware v8.8.0** |
| **Mk2 dashboard** | ESP32-S3-WROOM-1 N16R8 | UART link to Gen-2 node | n/a | **Active — full S3 rewrite, bench validated** |

Where this document gives a config value (API key, device ID, host), check the generation tag before reusing it.

---

## 1. What the system is

A per-bike telematics node on an electric motorcycle that:

- reads a **DALY smart BMS** over **BLE** using the **0xA5 protocol** — pack voltage, current, SOC, per-cell voltages, temperature, faults, MOSFET states;
- reads a **GNSS module** over **UART** (NMEA) — position, speed, time;
- reads **vehicle signals directly** — ignition, gears, indicators, headlight, emergency, breaker, safety switches, Hall wheel-speed, motor and controller temperatures;
- **controls the battery's charge and discharge MOSFETs** — remote **immobilizer** and **charge controller**;
- **buffers offline** and **uplinks telemetry** to a fleet platform, receiving control commands back;
- drives a **handlebar LED dashboard** over a bidirectional UART link;
- updates firmware **over the air**.

Humayun builds everything **except** the BMS (bought: DALY) and the motor controller.

**Deployment target:** 100-bike pilot in Karachi, then fleet scale.

---

## 2. Stakeholders and the privacy boundary

Three stakeholders see the same fleet through **different dashboards with a hard privacy boundary enforced at the API layer**, not by convention:

- **TCS** — logistics operator view.
- **K-Electric** — utility/energy view; **never receives rider names**.
- **Mentor Mobility** (OEM) — battery and vehicle health view; **never receives GPS coordinates or rider identities**; bikes appear as anonymised asset IDs.

**Recommended build order:** TCS first, then KE, then MM.

This is also the answer to requirement 14 (data ownership): the separation is a technical access-control boundary that makes a leak impossible, not a contract clause. On ThingsBoard Community Edition, the field-level split is achieved by splitting the battery stream to a separate entity (true field-level RBAC is a Professional Edition feature).

---

## 3. Architecture — the three-subsystem rule

The **BMS link, GNSS and network are independent**. Any one can fail without stopping the others. This principle has survived both generations and should not be traded away.

- **Network down** → GPS + BMS keep running; data queues to flash; retries continue. (Gen 1 additionally raised a fallback WiFi AP `EVBIKE-01` / `evbike1234` @ `192.168.4.1` so the local dashboard and controls still worked.)
- **BMS out of BLE range** → GPS + logging continue; dashboards show **"NOT IN RANGE"** and dim the battery panel. Never show stale numbers as if live.
- **GPS lost** → BMS + logging continue; dashboards show **"NO FIX."**
- **Logging** runs on its own timer and records whatever is valid, tagging each row with which subsystems were live — so a parked or stolen bike is still tracked.

---

## 4. Verified hardware facts (ground truth — do not re-derive)

These were confirmed on the bench. Treat them as authoritative.

### DALY BMS over BLE
- **BLE device name:** `DL-1771060607EB`
- **GATT:** service `FFF0`, notify `FFF1`, write `FFF2`, no pairing
- **Only ONE BLE central allowed** — the DALY phone app must be closed or the ESP32 cannot connect. This is the #1 cause of "won't connect".
- **Protocol:** DALY 0xA5, 13-byte frames, checksum = `sum(bytes 0..11) & 0xFF`
- **MOSFET control:** charge cmd `0xDA`, discharge cmd `0xD9`, write address `0x40`
  Frame: `A5 40 <cmd> 08 <01=on|00=off> 00 00 00 00 00 00 00 <cksum>`
  BMS echoes back `A5 01 <cmd> 08 <state> ...`
- **DISCHARGE IS THE MASTER SWITCH** (undocumented, verified): discharge OFF forces charge OFF; the BMS refuses charge ON while discharge is OFF. Firmware now blocks the invalid combination rather than letting the BMS silently reject it.
- **Current sign:** negative = discharge, positive = charge
- **SOC comes from the BMS**, never derived from voltage (the LiFePO₄ curve is flat)
- **0x93 frame byte d[3] is a rolling counter (0–255), NOT an SOH percentage.** SOH must be derived differently — the project uses the DALY life/health register plus a four-level verdict from cell spread: HEALTHY <20 mV, WATCH <50 mV, INVESTIGATE <100 mV, ALARM ≥100 mV.
- **Opcodes in use:** `0x90` SOC/voltage/current, `0x93` MOSFET/status, `0x94` cycle count, cell voltage frames for c1..c15

### Pack
15S LiFePO₄, ~60 Ah, ~2.88 kWh, 48 V nominal / 54.75 V full.

### Safety interlock (firmware-enforced)
Discharge-OFF is **refused unless speed < 3 km/h AND |current| < 5 A**. Discharge-ON and both charge commands are always allowed. This interlock is not in the client spec but every regulator will expect it — keep it and present it as a feature.

**Three-state immobilizer machine (current policy):** `IMM_IDLE` / `IMM_PENDING` / `IMM_LATCHED`.
- An immobilize request while moving stays **PENDING** until safe; it never auto-clears on throttle, reboot or OTA.
- Only an explicit web **mobilize** command clears a latch.
- **Fleet-safety bug fixed:** an OTA once persisted a stale discharge-OFF target and bikes booted immobilized. Updates must never carry over an immobilized state.

### Gen-2 node pin and interface notes
- GNSS: Ebyte E108-GN03D (AT6558R) over UART
- Modem RXD needs a 1k/2k divider; Hall sensor needs 10k/15k
- Wheel: 1 pulse/rev × **1.70 m circumference**, 1 s calculation window, 3 s zero-timeout
- Hall speed sensor: 5 V, red = signal (active-low), yellow = 5 V, green = GND
- Node↔dash UART is **crossed**: node GPIO15/TX → dash GPIO16/RX; node GPIO16/RX ← dash GPIO15/TX. Straight-through wiring is wrong.

### Mk2 dashboard hardware
- 3 × cascaded MAX7219 on hardware SPI @ 8 MHz, dirty-digit shadow tracking, ~60 Hz render
  - Chip A: 47 status LEDs · Chip B: 3 × 5161AS speed digits · Chip C: 8-digit odometer
- TM1637 modules: trip (GPIO14/21), RPM (GPIO2/45), current (GPIO47/48)
- 2 × DS18B20 on a shared 1-Wire bus at GPIO3
- 74HCT125N level shifter (replaced a 1N4148 diode dropper that overheated)
- Pin map: SPI 11/12/13 · UART link 15/16 · opto ignition 4 · indicators 5/6 · headlight 7 · emergency 8 · breaker 9 · safety 10 · RPM hall 1 · gears 38/39/40/41 · speed-sensor opto 42 · brightness button 18 · trip switch 17
- **Avoid for pulled-up opto inputs:** GPIO35 (PSRAM), 43/44 (UART0), 45/46 (strapping, no pulls)
- **MAX7219 pin 24 is DOUT, not SEG C** (SEG C is pin 20) — earlier documentation had five pins wrong
- Pins 16/17/18/19 are adjacent → repeated solder-bridge faults between SEG B/G and V+
- Both GND pins (4 and 9) must be connected
- Chip B needs **15 kΩ RSET** (not 10 kΩ) because of the three-digit scan limit
- **LED index rule: index = LED number − 1.** No lookup table. Validated arithmetically.
- **Validated LED map:** safety=1, emergency=2, breaker=3, Ind R=4, headlight=5, Ind L=6, BMS OK=7, BMS hot=8, SOC 9–18, controller OK=19, controller hot=20, current 21–30, motor OK=31, motor hot=32, RPM 33–42, gears G4→N descending 43–47
- A TM1637 stays dark unless `setBrightness` is immediately followed by a write

### Node↔dash link protocol
Bidirectional UART, 22-byte forward frame (sync `AA55`) / 14-byte reverse frame (sync `55AA`), CRC16-CCITT. Reverse frame carries the trip-reset flag (10-second hold on GPIO17, edge-triggered, 5 Hz while pending). Trip reset zeroes `tripKm` on the node but **never touches the NVS-backed odometer**. Header: `dash_link.h` v3.

---

## 5. Firmware version history and state

### Gen 1 — ESP32-C3 branch
| Version | What it added |
|---|---|
| … → v4 | `evbike_node_v4_latching.ino` — main Gen-1 deliverable. Cell array `c[]`, latching MOSFET engine, fallback AP, Firebase + Sheets logging |
| v5.0.0 | OTA-safe MOSFET latch handling; discharge-master coupling model enforced firmware-side |
| v6.0.0-tls | TLS work; three-state immobilizer machine (IDLE/PENDING/LATCHED) |

Also on this branch: a standalone **GNSS-only test firmware** (serial `7`/`8` simulate ignition on/off, `9` pins current location) with a matching focused ThingsBoard dashboard (map, trajectory, pin-location button, realtime log table), and `daly_mos_bench_test_c3.ino`, a bench MOSFET tester worth keeping as a permanent tool.

**Root-caused on this branch:** the persistent DALY BLE `rc=13` connect failure was WiFi/BLE radio coexistence on the single-core C3 — fixed by **connecting BLE before WiFi in `setup()`**.

### Gen 2 — ESP32-S3 telematics node (current)
| Version | What it added |
|---|---|
| v7.0.0 | First S3 + SIM800L + ThingsBoard MQTT build |
| v7.1 / v7.2 | NimBLE 2.x API compatibility; compliance key reduction 54 → 18 fields; lean 30 s tier + 600 s full tier |
| v8.0.0-REALTIME | Cadence profiles (2 s REALTIME needs self-hosted TB); single `temp` key; cells published as `c1..c15` for the stock bar chart; pack voltage `v` in the fast tier; `rssi` in dBm converted from CSQ; `acc` moved to the slow tier; full charge/discharge control with `BENCH_MODE` bypass; `getLocation` RPC; immediate control-state publish on MOSFET change; restored reset-reason reporting |
| v8.4.0 | LittleFS offline queue replacing the 12-slot RAM ring; ThingsBoard MQTT OTA client with MD5 verification and resume; corrected SOH derivation after the d[3] rolling-counter discovery; custom `partitions.csv` (2 MB app slots, 11.875 MB LittleFS ≈ **588 hours** of buffer) |
| **v8.8.0** | **Current.** Bidirectional dash link (`dash_link.h` v3), NVS-persisted odometer, trip reset over the reverse frame, engineering telemetry keys prefixed `e_` (`e_rpm`, `e_gear`, `e_tmot`, `e_tctl`), two-tier cadence 30 s fast / 900 s slow |
| v9.0.0 (deferred) | Possible merge of the two S3 nodes into one unit |

**Current flags:** `PROFILE_REALTIME 0` (mandatory while on TB Cloud Free), `BENCH_MODE 1` (must be `0` before anything carries a rider), `IGN_ENABLED 0` (pending physical optocoupler wiring).

### Mk2 dashboard firmware
Full S3 rewrite, evolved through many iterations: hardware SPI replacing `shiftOut`; dirty-digit shadow tracking; FreeRTOS WiFi task on core 0, opt-in by a **20-second button hold** (never at boot — roads have no WiFi and the display must be instant); 8-second task watchdog with a safe `waitMs()` replacing raw `delay()`; bulb check on the ignition rising edge; blocking diagnostics refused while moving (rpm > 200); attract animation (dim comet, 5 s) confined to the BMS-dependent block so locally-sensed signals (gears, RPM, switches, local temps) stay live regardless of link state; 350 ms wipe transition between modes; `bnS diSC` on the odometer when the link drops; per-channel opto inversion stored in NVS.

### Why the two nodes stay separate
Merging is technically easy — one S3 runs everything at **5.5 % CPU, 43 % RAM, with 2 spare pins**. It is deferred anyway, to protect deployed production telematics firmware and preserve **independent OTA at 100-bike scale**, and to keep the safety-critical immobilizer path isolated from display code.

---

## 6. Cloud and backend

### Current — ThingsBoard
- **ThingsBoard Cloud Free**, EU Frankfurt: `mqtt.eu.thingsboard.cloud`, port **1883** (plaintext — SIM800L cannot do TLS)
- Device ID `30b150d0-9001-11f1-be6c-6b7076fe8a8d` · BIKE_ID `EVBIKE-01` · EU region tenant
- `FW_VERSION` is **bare semver** with no prefix (e.g. `"8.4.0"`); `FW_TITLE` is `"EVBIKE-FW"`
- APN `jazzconnect.mobilinkworld.com` (Jazz SIM)
- **Free-tier constraints that drive design:** 1,000,000 data points/month (≈86 % used by one bike), **30-day TTL**, 5-device ceiling. At a 2 s cadence one bike publishes ~302,000 points/day and would exhaust the cap in 3.3 days — hence 30 s is the hard floor until self-hosted.
- Dashboards were generated in Python from the user's own exported widget JSONs (`build_dashboard_v7.py`), progressing v2→v7, specifically to guarantee valid `typeFullFqn` values — guessed FQNs produce blank widgets.
- Monthly exports: `tb_export.py` + a GitHub Actions weekly backup workflow.

### Planned — self-hosted ThingsBoard
Docker stack `evfleet-thingsboard.tar.gz`: ThingsBoard CE + **Caddy** for HTTPS + **nginx stream** for MQTTS on 8883 + a **certsync sidecar** sharing Let's Encrypt certificates. Target: Oracle Cloud Always Free. Interim access was via **Tailscale Funnel** (`humayuns-macbook-pro.tail9ee71e.ts.net`, port 10000) and **DuckDNS** `mmevfleet.duckdns.org` (that DuckDNS token was exposed in chat and should be regenerated).

**Oracle status:** rejected/blocked on a PKR 31,742.90 (~$100) card authorization hold; A1 capacity retries ongoing via `oci_create_evfleet_v2.sh` / `oci_retry_launch.sh`.

### Gen 1 — Firebase + Sheets (superseded, kept for reference)
- RTDB host `ev-bike-fleet-telematics-default-rtdb.firebaseio.com`
- Web API key `AIzaSyCd0iCbS4KB_EO2cMjwEhCcw0MfFzMTEr4` (public by design — identifies the project, grants nothing)
- Device account `node@evbike.local` + invented password in `FB_PASS`
- Keys: `/bike` (telemetry out), `/cmd` (control in), `/ack` (result out); DB rules `auth != null` on all three — mandatory, because control is a safety system
- Sheet ID `1VKMw7wuelku01M2dsu_t3gtN8feR2PtOdl5g7icAB4Q`
- Apps Script `/exec` deployment `AKfycbw_DGzUBRAdccXSBPSbGTc_Sm1mp582IAf1xhaVuF3JJ-DUlzbDNk-aPIGIK1abe0H0`
- Public dashboard https://humayunnaveedkhan.github.io/EV-DB/ (repo `EV-DB`, file saved as `index.html`)
- **No position-history array in Firebase** — that would cost ~86 MB/bike/day on cellular; the trail lives in the browser.

---

## 7. The 17-point client requirement sheet

Latest documented position (compliance PDF): **16 delivered, 1 in progress.** Honest engineering status:

| # | Requirement | Status / implementation |
|---|---|---|
| 1 | GPS location | Multi-constellation GNSS (GPS/GLONASS/BeiDou/Galileo), lat/lon 6 dp, ~2.5 m, 12–16 sats, HDOP 0.7–1.0 reported as accuracy. Spec asked ≥30 s when moving. **Delivered** |
| 2 | Ignition status | Hardware ignition line, 80 ms debounce, event-driven push on state change; starts/ends a numbered journey and force-saves the odometer on switch-off. **Delivered** |
| 3 | Vehicle speed | Wheel-mounted Hall pulse sensor — a direct physical measurement, not GPS-derived; works in tunnels/basements. Spec preferred ECU-sourced; depends on whether the controller exposes a bus. **Delivered** |
| 4 | Battery SOC | DALY `0x90`, 0.1 % resolution; also remaining Ah. **Delivered** |
| 5 | Battery SOH | DALY life/health register + four-level cell-spread verdict (the earlier, more actionable indicator). **Delivered** |
| 6 | Cycle count | DALY `0x94`. **Delivered** |
| 7 | Cell voltages | `c1..c15`. **Delivered** |
| 8 | Battery temperature | As reported by the BMS probe. Note honestly: the DALY exposes **one** sensor, not separate pack and cell readings. **Delivered** |
| 9 | Current / Ah | From BMS, signed. **Delivered** |
| 10 | Remote immobilizer | MOSFET discharge cut via RPC; spec allowed ≤60 s, actual ~2 s. Plus the speed/current interlock. **Delivered** |
| 11 | Charger connect/disconnect | Charge MOSFET via RPC. **Delivered** |
| 12 | API: REST or MQTT/TLS | REST/JSON over HTTPS is true today; **device backhaul is still plaintext MQTT**. TLS lands with SIM7670G. **Delivered as written; hardening pending** |
| 13 | Auth: OAuth2 / API key | Per-device token today, upgradeable to certificates. OAuth awaits the client's identity provider details. **Client config** |
| 14 | Data ownership | Self-hosted = company owns everything; stakeholder split enforced at the API layer. **Delivered** |
| 15 | 4G LTE SIM | **The one open item** — SIM7670G awaiting delivery/approval. Transport swap only; no schema, platform or dashboard change. **Awaiting SIM** |
| 16 | Offline buffering | LittleFS store-and-forward, ~588 hours. **Delivered** |
| 17 | Firmware OTA | ThingsBoard OTA with MD5 verification and resume; demonstrated end-to-end over both LAN and WAN. **Delivered** |

**Framing rule the client asked for:** low-key wording — "delivered", not "meets/exceeds"; implementation claims made verbally, not in writing. Be upfront that 15 is the gap; volunteering it makes the other sixteen credible.

---

## 8. Delivered artefacts

### Firmware and code
- `evbike_node_v4_latching.ino` (Gen-1 main), `evbike_sheets_v4.gs` (Apps Script), `index_v5_pro.html` (Gen-1 public dashboard)
- `daly_mos_bench_test_c3.ino` — bench MOSFET tester, keep permanently
- Gen-2 node firmware v7.0.0 → **v8.8.0** + `partitions.csv`
- Mk2 dashboard firmware (full S3 rewrite) + `dash_link.h` v3
- Isolation test sketches: `bms_simple.ino`, `gnss_test_node`, `speed_test`

### Python / ops tooling
- `tb_export.py` — ThingsBoard data export (monthly, against the 30-day TTL)
- GitHub Actions weekly backup workflow
- `build_dashboard_v7.py` — generates ThingsBoard dashboard JSON from exported widget JSONs
- `mk2_netlist.py` — KiCad netlist generator
- `oci_create_evfleet_v2.sh`, `oci_retry_launch.sh` — Oracle A1 provisioning + capacity retry
- `evfleet-thingsboard.tar.gz` — self-hosted Docker stack (TB CE + Caddy + nginx stream + certsync)

### Documents
- `EV_Fleet_Requirements_Compliance.pdf` — 17-point compliance matrix
- `EV_Fleet_Telematics_Brief.pdf` — one-page non-technical demo brief
- `Demo_Startup_Checklist.pdf` — exact commands + troubleshooting table
- Full capacity/specification PDF
- Hardware connection specification (pin assignments, level shifting, RS485 display-link spec: 12-byte Modbus CRC16 frame @ 9600 baud carrying SOC, current, temperature, flags)
- `EVBIKE_DASH_MK2_HANDBOOK.md`, `MK2_TRIP_ODOMETER.md`, `MK2_VEROBOARD_BUILD.md`
- A 117-row skills-and-concepts learning table and a system capabilities/specifications table

### Demonstrated working
OTA pipeline end-to-end; discharge/charge MOSFET actuation via RPC (immediate); live location and speed gauge; cell-voltage bar chart; three-state immobilizer; trip reset over the reverse UART frame.

---

## 9. Learnings — the gotcha list

**Radio and protocol**
1. BLE must be initialized **before** WiFi on the C3; the reverse wedges BLE (`rc=13`).
2. The DALY phone app being open blocks the ESP32's BLE connection entirely.
3. `0x93` byte d[3] is a rolling counter, not SOH.
4. Discharge is the master switch; charge-ON while discharge-OFF is refused by the BMS.
5. MOSFET reliability comes from a **strict BLE interlock** (`if (mos.busy) return;` in `pollBms`) so read frames never collide with the write frame — plus retry, echo detection, and a latching engine that re-asserts the commanded state on drift.

**Cellular and networking**
6. SIM800L tops out at TLS 1.0/1.1 → cannot reach HTTPS-only endpoints (Firebase, Google, Tailscale Funnel). Plain MQTT only.
7. SIM900A is permanently rejected — region-locked on Pakistani networks.
8. Brownout resets during GSM registration trace to the SIM800L power rail (still unresolved; do not fly blind on it).

**GNSS**
9. AT6558R (E108-GN03D) is the production baseline — concurrent multi-constellation. NEO-7M and VK2828U7G5LF are downgrades (GPS-only). u-blox M8 (VK2828U8G5LF) would be a genuine upgrade. A non-fixing NEO-6M was what forced the move.

**Build and toolchain**
10. Default 1.31 MB partition fails at ~101 % with BLE+WiFi+TLS. Use **Minimal SPIFFS (1.9 MB APP with OTA)** on the C3, or the custom `partitions.csv` on the S3.
11. C3 shows nothing on serial unless **USB CDC On Boot** is enabled; press RESET after upload, re-select the port, and suspect a charge-only USB cable.
12. `'X' does not name a type` on compile = a non-ASCII / smart-quote character inside an `R"HTML(...)HTML"` raw string terminating it early. Keep embedded HTML **all-ASCII** (`&deg;`, `&middot;`), and download files rather than copy-pasting.

**Cloud**
13. Apps Script `/exec` returns a **302**; the row is only written if the redirect is followed — `setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS)`.
14. WAN command bug (fixed): the dashboard sends `ts: Date.now()` (13 digits); parsing it as `uint32_t` overflows and corrupts dedup, silently swallowing WAN commands. **Dedup `ts` as a string.** LAN has no `ts`, which is how it was isolated.
15. ThingsBoard **latest-value keys never expire** — the 30-day TTL prunes history only. Smoke-test keys persist forever unless manually deleted, and will quietly poison any widget bound to them.
16. Guessed `typeFullFqn` values produce blank/invalid ThingsBoard widgets. Build dashboards from your own exported widget JSONs.
17. OCI Cloud Shell uses delegation-token auth (no `~/.oci/config`); FIPS mode blocks ed25519 keys (use RSA-4096); A1 instances frequently report "out of host capacity" in single-AD regions.
18. No position-history array in the realtime DB — ~86 MB/bike/day on cellular. Keep the trail in the browser.

**Hardware**
19. MAX7219 pin 24 is DOUT, not SEG C (SEG C is pin 20). Five pins in the old documentation were wrong.
20. 74HCT125 replaced a 1N4148 diode dropper that overheated in practice.
21. Per-channel opto inversion became necessary after LED 1 (safety) stayed lit regardless of wiring.
22. At a 1 m run on a bike, **plain UART is viable** with common grounding, twisted pairs routed away from motor phases, 220 Ω series on TX and 10 kΩ pull-ups on RX. Validate RS485 under motor load before assuming it is needed.
23. A dead Hall sensor can look exactly like a firmware bug — swap the sensor before rewriting code.

**Process**
24. WiFi was removed from the boot path once it was established that roads have no WiFi and the display must be instant.
25. An OTA that persists actuator state can immobilize a fleet. Updates must never carry over a commanded-off state.

---

## 10. Open issues

| Issue | Detail |
|---|---|
| Brownout resets during GSM registration | SIM800L power rail. Unresolved. |
| Silent BLE link drops | `blerc 0x08` (possible rail interference) / `0x13` (phone app interference). |
| `IGN_ENABLED 0` | Pending physical optocoupler wiring. |
| `BENCH_MODE 1` | Must become `0` before any bike carries a rider. |
| TLS (item 12) and 4G LTE (item 15) | Both blocked on SIM7670G delivery. |
| TB Cloud Free ceiling | 1 M points/month at ~86 % with **one** bike. Does not scale to 100 — self-hosting is a prerequisite, not an optimisation. |
| Oracle Cloud | Card authorization hold; A1 capacity retries ongoing. |
| DuckDNS token | Was exposed in chat — regenerate. |
| MQTT access token | Rotated several times; earlier tokens are invalid. |

---

## 11. Roadmap

1. **SIM7670G arrival** → 4G LTE + TLS; transport swap only, no schema/platform/dashboard change. Closes items 12 and 15.
2. **Self-hosted ThingsBoard** on Oracle Always Free (or an alternative VPS) → removes the data-point cap and the 30-day TTL, enables the 2 s REALTIME cadence profile and MQTTS on 8883.
3. **Three-stakeholder dashboards**, built TCS → KE → MM, with the privacy boundary at the API layer.
4. **Fleet provisioning** to 100 bikes — device templates, per-device credentials, staged OTA rollout.
5. **Custom PCB** → KiCad → JLCPCB assembly for production scaling.
6. **v9.0.0 single-node merge**, only once the dashboard firmware is stable and production telematics firmware is protected.
7. Field hardening: brownout fix, BLE drop root-cause, `BENCH_MODE 0`, ignition opto wiring.

---

## 12. Working style (carry this across)

- Direct and results-oriented; working code over lengthy explanation. Push back when answers become over-diagnostic.
- **Verified hardware facts are ground truth** — do not re-derive opcodes, pinouts or the discharge-master behaviour.
- **Build on the current main files** rather than rewriting from scratch.
- **Validate embedded HTML before handing it over**: ASCII-only, balanced raw-string delimiters, balanced braces/parens, every JS element ID present. This project has hit the smart-quote raw-string trap repeatedly.
- **Never weaken** the immobilizer speed/current interlock or the database auth rules.
- Bench-validate with isolated test sketches before integrating.
- Keep engineering keys (`e_*`) separate from rider-facing telemetry.
- Semantic firmware versioning, every version documenting what changed and why.
- File uploads often arrive empty — pasting text is the reliable path.
- Document hardware in KiCad netlists, markdown handbooks and veroboard build guides.
- Lab title is always written **"HHRCM Lab NCRA-NEDUET"**; role is **"Team Lead"** (not "Team Lead R&D").

---

## 13. Toolchain

**MCUs:** ESP32-S3-WROOM-1 N16R8 (telematics + dashboard), ESP32-C3 SuperMini (prototype)
**Firmware:** Arduino IDE, NimBLE-Arduino 2.x, TinyGPSPlus, LittleFS, FreeRTOS, ESP-IDF partition tooling
**Cellular:** SIM800L (interim), SIM7670G Cat-1 (target); Jazz SIM
**Displays:** MAX7219 ×3 cascade, TM1637 ×3, 5161AS digits
**Cloud:** ThingsBoard Cloud Free (EU) → self-hosted ThingsBoard CE; Docker, Caddy, nginx stream; Oracle Cloud (pending)
**Networking:** Tailscale Funnel + MagicDNS, DuckDNS
**VCS/CI:** GitHub, GitHub Actions
**PCB:** KiCad, SKiDL, JLCPCB assembly pathway
**Docs:** markdown handbooks, reportlab-generated PDFs

---

## 14. What is in the rest of this export

| Path | Contents |
|---|---|
| `01_PROJECT_EXPORT.md` | This document |
| `02_IMPORT_PROMPT.md` | Ready-to-paste first message for the new account |
| `memory/overview.md` | Project memory — scope, current state, roadmap |
| `memory/engineering-learnings.md` | Project memory — the gotcha ledger |
| `memory/ways-of-working.md` | Project memory — working style and toolchain |
| `skill-ev-fleet-telematics/SKILL.md` | The installable project skill (shared brain) |
| `skill-ev-fleet-telematics/references/*.md` | Eight deep-dive reference files: hardware, mcu-firmware, bms-ble, gnss, gsm-cellular, dashboard-cloud, sensors-new-modules, vision-scaling |

**Note on the skill:** it was written during Gen 1, so its config values (Firebase, Sheets, GitHub Pages dashboard, ESP32-C3 prototype) describe that generation. Its **verified hardware facts, BLE/0xA5 protocol, MOSFET opcodes, safety interlock and gotchas are still current and authoritative.** Section 6 of this document supersedes its cloud configuration.
