# BMS · BLE · 0xA5 protocol · MOSFET control · immobilizer

Everything needed to talk to the DALY BMS and control the MOSFETs. All opcodes
and behaviors here are **VERIFIED ON HARDWARE**.

## BLE connection
- NimBLE-Arduino. Scan for name `DL-1771060607EB`.
- Service `0000fff0-...` (`FFF0`); notify `0000fff1-...` (`FFF1`); write
  `0000fff2-...` (`FFF2`). No pairing/bonding.
- **One central only — close the DALY phone app.**
- After connect, tune params: `updateConnParams(24,48,0,400)`; subscribe to
  notify; kick an initial `0x90` read.

## 0xA5 frame format (13 bytes)
```
0    1     2    3    4 5 6 7 8 9 10 11   12
A5   ADDR  CMD  08   <---- 8 data ---->  CKSUM
```
- Byte 0 = `0xA5`. Byte 3 = length `0x08`. Byte 12 = `sum(bytes 0..11) & 0xFF`.
- **Read address = `0x80`.** **MOSFET write address = `0x40`.**

## Read commands (ADDR 0x80)
| CMD | Meaning | Parse |
|---|---|---|
| 0x90 | SOC / V / I | V=be16(d)×0.1; I=(be16(d+4)−30000)×0.1; SOC=be16(d+6)×0.1 |
| 0x93 | MOS / Ah / life | d[0]=state(0 idle/1 chg/2 dsg), d[1]=chgMOS, d[2]=dsgMOS, d[3]=life; Ah=be32(d+4)/1000 |
| 0x94 | counts / cycles | d[0]=cells, d[1]=temp sensors, cycles=be16(d+5) |
| 0x95 | cell voltages | multiframe: d[0]=frame#, then 3× be16 mV |
| 0x96 | temps | multiframe: d[0]=frame#, temp=d[1..]−40 °C |
| 0x97 | balance | any nonzero byte → balancing active |
| 0x98 | faults | 7 fault bytes, bit-mapped |

- `be16(p)= (p[0]<<8)|p[1]`; `be32` similarly.
- **Current sign: negative = discharge, positive = charge** (the −30000 is the
  zero point).
- Poll order used in firmware: 0x90, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98.

## Fault bit map (0x98)
7 bytes × 8 bits. Byte/bit groups (as labeled in firmware):
- byte0: cell over/under-voltage, pack over/under-voltage (×2 levels each)
- byte1: charge/discharge temp high/low (×2)
- byte2: charge/discharge overcurrent, SOC high/low (×2)
- byte3: cell voltage spread, temp spread
- byte4: charge/discharge MOS hot, sensor fault, stuck, open
- byte5: AFE fault, voltage sense dropout, cell temp sensor, EEPROM, clock,
  precharge, comms, internal comms
- byte6: current sensor fault, pack voltage sense fault, short-circuit
  protection, charge-blocked-low-voltage

## MOSFET control (VERIFIED — crown jewel)
- Charge cmd `0xDA`; discharge cmd `0xD9`; write addr `0x40`.
- Frame: `A5 40 <cmd> 08 <01=on|00=off> 00×7 <cksum>`.
- **BMS echoes** the command as `A5 01 <cmd> 08 <state> ...` — watch for it as a
  fast confirm.

Verified frames:
```
Charge ON  : A5 40 DA 08 01 00 00 00 00 00 00 00 C8
Charge OFF : A5 40 DA 08 00 00 00 00 00 00 00 00 C7
Dischg ON  : A5 40 D9 08 01 00 00 00 00 00 00 00 C7
Dischg OFF : A5 40 D9 08 00 00 00 00 00 00 00 00 C6
```

## UNDOCUMENTED behavior (VERIFIED — design around it)
**Discharge is the master switch.** Discharge OFF also forces charge OFF; the
BMS **refuses charge ON while discharge is OFF**; discharge ON restores charge.
→ Dashboards disable "Charge on" whenever discharge is off (`canchg` flag), so
no command is issued that the BMS will silently reject.

## Reliable control — the pattern that works
1. **Strict BLE interlock:** `pollBms()` starts with `if(mos.busy) return;` and
   breaks mid-loop if a command starts. This stops read frames colliding with
   the write frame on the BLE link — **this is the real reliability fix**, not
   retries. (Discovered in the user's working LAN-only code.)
2. **Robust `mosSet()`:** send the frame, then confirm via BOTH the echo
   (`A5 01 <cmd> ...`) AND a fresh 0x93 read, **retrying up to 5 times** (covers
   the BMS being asleep and eating the first command as a wake).
3. **Latching engine:** `g_targetChg` / `g_targetDsg` remember the commanded
   state (seeded from the first live 0x93). `enforceLatch()` runs after each
   poll and re-asserts the target if the BMS drifts — one correction per pass so
   it can't thrash. Respects the interlock and safety checks. Dashboard shows
   "holding on/off..." while enforcing (`tchg`/`tdsg` fields).

## Immobilizer / safety (FIRMWARE-enforced, not just UI)
- **Discharge OFF refused unless BOTH:** GPS speed < 3 km/h (unknown = moving =
  refused) AND |current| < **5 A**.
- **Discharge ON and both charge commands always allowed** (never strand a
  rider).
- Why 5 A (not 2 A): the pack idles at several amps, so 2 A refused *every*
  discharge-off. 5 A actuates when parked/lightly loaded while still blocking
  under drive load. Cutting at up to 5 A is a minor MOSFET arc-stress —
  acceptable for occasional use; add a "coast to zero first" step if
  immobilizing frequently under load.

## SOC / health
- SOC from BMS only. Health verdict from cell spread at rest:
  <20 mV HEALTHY, <50 WATCH, <100 INVESTIGATE, else ALARM; UNDER LOAD when
  |I|>1 A; NO DATA when BMS offline.

## Bench tool
`daly_mos_bench_test_c3.ino` is the standalone tester (runtime opcode/address
dropdowns) used to discover and verify all of the above. Keep it for bench work;
the opcode-tuning UI is deliberately removed from cloud builds for safety.
