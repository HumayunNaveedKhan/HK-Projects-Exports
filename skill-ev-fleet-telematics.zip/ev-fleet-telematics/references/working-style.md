---
name: ways-of-working
description: Working style, firmware/bench validation practices, documentation habits, and the toolchain (ESP32-S3, NimBLE, ThingsBoard, KiCad, GitHub Actions, Python tools)
sources: [backfill]
aliases: [workflow, toolchain, tools]
---

## Working and collaboration patterns

- Direct, results-oriented communication style; prefers working code over lengthy explanations; pushes back when responses become overly diagnostic
- File uploads frequently arrive empty — text paste is the reliable alternative
- Iterative firmware versioning with explicit semantic version numbers tracking feature additions
- Bench validation before field deployment; dedicated test sketches (bms_simple.ino, gnss_test_node, speed_test) used to isolate subsystems before integration
- Compliance documentation and client-facing PDFs produced in parallel with firmware (low-key framing; implementation claims delivered verbally rather than in writing)
- Engineering keys prefixed and separated from rider-facing data in telemetry payloads
- Hardware decisions documented in KiCad netlists, markdown handbooks, and veroboard build guides

## Tools and resources

- Microcontrollers: ESP32-S3-WROOM-1 N16R8 (telematics + dashboard), ESP32-C3 SuperMini (earlier prototype)
- Firmware/IDE: Arduino IDE with NimBLE-Arduino 2.x, ESP-IDF partition tooling, LittleFS, FreeRTOS
- Cellular: SIM800L (production interim), SIM7670G Cat-1 (production target); Jazz SIM
- Display ICs: MAX7219 (3-chip cascade), TM1637
- Cloud/backend: ThingsBoard Cloud Free (EU), Oracle Cloud (pending), Docker, Caddy, nginx stream
- Networking: Tailscale Funnel (interim public access), DuckDNS, Tailscale MagicDNS
- Version control/CI: GitHub, GitHub Actions (weekly TB export)
- PCB/manufacturing: KiCad, JLCPCB assembly pathway for production scaling
- Documentation: markdown handbooks (EVBIKE_DASH_MK2_HANDBOOK.md, MK2_TRIP_ODOMETER.md, MK2_VEROBOARD_BUILD.md), compliance PDFs, netlist generator (mk2_netlist.py)
- Python tooling: tb_export.py (ThingsBoard data export), build_dashboard_v7.py, mk2_netlist.py, oci_create_evfleet_v2.sh, oci_retry_launch.sh
