# MCU / ESP32 firmware — structure, build, OTA, network

Main firmware: **`evbike_node_v4_latching.ino`** (ESP32-C3 prototype).

## Build settings (MANDATORY)
- Board: **ESP32C3 Dev Module**
- **USB CDC On Boot: Enabled** (else nothing on serial)
- **Partition: "Minimal SPIFFS (1.9MB APP with OTA)"** — default 1.31 MB fails
  at ~101% with BLE+WiFi+TLS. "Huge APP" works if OTA not needed.
- Libraries: **NimBLE-Arduino**, **TinyGPSPlus** (rest are built-in: WiFi,
  WebServer, ESPmDNS, ArduinoOTA, HTTPClient, WiFiClientSecure).

## Firmware modules (what lives in the file)
1. **BLE engine** — scan/connect/subscribe/poll the DALY (see `bms-ble.md`).
2. **Strict BLE interlock** — `if(mos.busy) return;` at top of `pollBms()`.
3. **Robust `mosSet()`** — retry ×5, echo + 0x93 confirm.
4. **Latching engine** — `enforceLatch()` re-asserts commanded MOSFET state.
5. **GNSS** — TinyGPS++ NMEA; trip distance by haversine, gated speed>3 km/h and
   jump 1–200 m (see `gnss.md`).
6. **Energy integration** — V×I → kWh in/out; never interpolate across >30 s gap.
7. **Google Sheets logging** — own ~20 s timer, independent of BMS; **follows
   the 302 redirect** (`setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS)`).
8. **Firebase** — sign-in, token refresh, PUT `/bike` every 3 s, poll `/cmd`
   every 2 s, write `/ack` (see `dashboard-cloud.md`).
9. **Network self-healing** — fallback AP on WiFi loss, retry, drop AP on
   recovery.
10. **Local diagnostic page** — served at `http://<ip>/`; LAN control via
    `/api/mos?fet=chg|dsg&on=0|1`, telemetry via `/api/data`.
11. **OTA** — ArduinoOTA, host `evbike`, pass `evbike2026` (change it).

## The loop (priority order)
`gnssFeed()` first every iteration (never drop NMEA) → `web.handleClient()` →
`ArduinoOTA.handle()` → `updateStatus()` → `led()`. Then timed tasks: BLE poll +
`enforceLatch()` (POLL_MS), trip update (1 s), network tick (5 s), Firebase push
(3 s) + cmd poll (2 s), Sheets log (20 s). During any blocking wait, keep
pumping `web/ota/gnss` so nothing starves.

## Status model
`updateStatus()` sets three independent flags: `net` (WiFi connected), `bms`
(online + valid + fresh <15 s), `gps` (valid + age <8 s + nonzero). Everything
downstream (LED, dashboards, logging blanks) keys off these.

## Config block (top of file)
```
BIKE_ID     "EVBIKE-01"
TARGET_NAME "DL-1771060607EB"
STA_SSID / STA_PASS         your WiFi
AP_SSID "EVBIKE-01" / AP_PASS "evbike1234"
OTA_HOST "evbike" / OTA_PASS "evbike2026"
FB_HOST/FB_APIKEY/FB_EMAIL/FB_PASS   see dashboard-cloud.md
GAS_URL     the Apps Script /exec URL
Pins: LED 8, GNSS_RX 4, GNSS_TX 5
Thresholds: SAFE_SPEED_KMH 3, SAFE_CURRENT_A 5
Opcodes: MOS_CMD_CHARGE 0xDA, MOS_CMD_DISCHARGE 0xD9, MOS_WRITE_ADDR 0x40
```

## OTA workflow
First flash over USB. After that: Arduino IDE → Tools → Port →
`evbike at <ip>`, password `evbike2026`. Needs the OTA partition. ("LAN OTA" =
this, over the local network; remote/cellular OTA is future work.)

## Validation checklist before shipping firmware
This project repeatedly hit the embedded-HTML raw-string trap. Before handing
over any `.ino` with a `R"HTML(...)HTML"` block, verify:
- 0 non-ASCII bytes in the file;
- exactly one `R"HTML(` and one `)HTML";`, and `)HTML"` never appears inside the
  page body;
- C++ braces/parens balanced (tokenizer-aware, ignoring strings/comments);
- every `$('id')` / `getElementById('id')` in the embedded JS exists as an HTML
  `id`;
- new symbols/functions are declared before use (forward-declaration order).

## Firmware lineage (reference)
GNSS bring-up (`gnss_tinygps_c3.ino` keeper) → `bms_gnss_to_sheets_c3.ino` →
`evbike_bms_gnss_ap_c3.ino` → `evbike_node_v1_integrated.ino` (LAN full) →
`evbike_node_v2_firebase.ino` (Firebase+auth+cmd/ack+split current) →
`evbike_node_v3_final.ino` (5 A, retry×5, echo) → **`evbike_node_v4_latching.ino`**
(strict interlock + latching + WAN ts-string fix + real API key).
`daly_mosfet_robust.ino` is the control-logic patch as a standalone reference.

## Common firmware gotchas
- C3 nothing on serial → USB CDC On Boot; RESET after upload; re-select port;
  charge-only cable.
- Partition too small → see build settings.
- `'X' does not name a type` → smart-quote in the HTML raw string; keep ASCII.
- WAN commands ignored → `ts` overflow; dedup as string (see
  `dashboard-cloud.md`).
