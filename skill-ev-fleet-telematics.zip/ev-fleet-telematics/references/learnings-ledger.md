---
name: engineering-learnings
description: Hard-won findings on DALY BMS, BLE/WiFi order, SIM800L/SIM900A, GNSS modules, MAX7219 pinout, immobilizer safety, RS485 vs UART, OCI provisioning
sources: [backfill]
aliases: [lessons learned, gotchas]
---

- BLE/WiFi coexistence on ESP32-C3: BLE must be initialized before WiFi; the reverse causes BLE to enter a wedged state (rc=13 failures)
- DALY BMS protocol: frame byte d[3] in the 0x93 response is a rolling counter (0–255), not an SOH percentage — SOH must be derived differently
- SIM800L tops out at TLS 1.0/1.1 and cannot reach HTTPS-only endpoints (Firebase, Google, Tailscale Funnel); plain MQTT only
- SIM900A is permanently rejected (region-locked on Pakistani networks)
- GNSS module evaluation: AT6558R (E108-GN03D) provides concurrent multi-constellation and is the current production baseline; NEO-7M and VK2828U7G5LF are downgrades (GPS-only, no concurrent GLONASS/BeiDou); u-blox M8 (VK2828U8G5LF) would be a genuine upgrade
- MAX7219 pinout correction: pin 24 is DOUT (not SEG C); SEG C is pin 20 — earlier documentation had five pins wrong
- Level shifting: 74HCT125 replaced the 1N4148 diode dropper after the diode overheated in practice
- WiFi on the boot path was removed after establishing that roads have no WiFi and instant display is required
- Sequential LED fill rule: index = LED number − 1; no lookup table required (validated arithmetically)
- Per-channel opto inversion was added after LED 1 (safety) was always lit regardless of wiring
- Immobilizer safety: fleet-safety bug fixed where OTA updates persisted a discharge-OFF target causing bikes to boot immobilized; discharge is DALY's master switch — charge-ON is refused while discharge is OFF
- RS485 vs plain UART: at a 1-meter cable run on a bike, plain UART is viable with common grounding, twisted pairs routed away from motor phases, and 220Ω series resistors on TX / 10kΩ pull-ups on RX; RS485 should be validated under motor load before assuming it is needed
- OCI provisioning: Cloud Shell uses delegation token auth (no `~/.oci/config`); FIPS mode blocks ed25519 keys (use RSA-4096); A1 instances frequently show "out of host capacity" in single-AD regions
