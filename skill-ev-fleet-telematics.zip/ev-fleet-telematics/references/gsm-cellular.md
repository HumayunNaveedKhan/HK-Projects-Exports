# GSM / 4G / cellular — the WiFi → LTE migration

The node currently uplinks over **WiFi**. Production moves to **4G cellular**.
This file is the plan and the constraints.

## Module choice (SELECTED)
- **SIM7670G data-only** (global Cat-1 LTE). User owns a genuine breakout.
  Pair with a **separate GNSS** (L76K ~PKR900, or u-blox NEO-M8N / MAX-M10S).
- **Also acceptable:** A7670G-LABE (integrated GNSS; ~PKR600/unit more than
  data-only + separate GNSS). Decision was deferred to a GPS fix-quality test.

## HARD RULES for any 4G module
1. **Global bands** — never a `-CN` / China-locked variant.
2. **UART + AT command set + English documentation.**
3. If the module UART is **1.8 V**, add a **level shifter** to 3.3 V for the
   ESP32-S3.

## Rejected (do NOT re-suggest)
- **SIM7670G mPCIe** — wrong form factor, risk of USB-not-UART, ~2.7× price.
- **EG800Z-CN** — China bands, no GNSS on the data variant.
- **ML307R** — China Mobile locked, no GNSS, thin English docs.
- One A7670G-LABE listing had absurd ~PKR20k shipping — use a different seller.

## Bench modem
SIM800L (2G) for cheap bench testing only: own 3.7–4.2 V rail + fat cap. The AT
command HTTP flow written for it carries forward to the 4G module.

## Power (critical for LTE)
- Modem gets its **own regulator (~3.8 V) + 1000 µF bulk cap**. LTE TX current
  bursts (up to ~2 A) will brown out a shared rail and reset the ESP.
- **Keep the LTE antenna away from the GNSS antenna** (desense).

## Firmware integration point
The swap is localized: `logSheets()` and `fbPush()` are the two functions that
do HTTP-over-WiFi. Replace their transport with the modem's AT-command HTTPS, or
move to **MQTT** for the live path. Keep the payload builder (`fbPayload()`)
unchanged — it's transport-agnostic.

Sequence for AT-based HTTP(S) POST (generic Cat-1): power/reset modem → wait for
network registration (`AT+CGREG?`) → set APN → open bearer → HTTPS init → set
URL + headers → POST body → read response → close. Mirror the WiFi timeouts
(~9 s) and keep pumping `gnssFeed()` between AT waits.

## Data-budget discipline (why the payload is lean)
- **No position-history array** anywhere in the uplink — 180 track points every
  4 s ≈ 86 MB/bike/day, ruinous on an M2M SIM. The trail is rebuilt in the
  browser from the single live fix. Keep this rule when moving to cellular.
- Consider widening the push interval on cellular (e.g. 5–10 s) and moving the
  live channel to MQTT (retained last-value) to cut overhead.

## At fleet scale
At 100 bikes, move the backend off Firebase/Sheets to **ThingsBoard / MQTT with
a time-series DB and RBAC** (see `vision-scaling.md`). Firebase + Sheets is the
pilot backend, fine for a handful of bikes on WiFi.

## Future
Remote/cellular OTA (updating firmware over the LTE link) is not implemented —
current OTA is LAN-only (see `mcu-firmware.md`).
