---
name: hk-ev-fleet-telematics
description: >-
  Complete engineering context for the HK-EV-Fleet-Telematics project — a 100-bike
  EV-bike fleet telematics + dashboard system (builder: Mentor Mobility; end clients:
  K-Electric / TCS; Karachi pilot). Two ESP32-S3 nodes over crossed UART: a telematics
  node (DALY BMS over BLE + GNSS + cellular + ThingsBoard cloud + immobilizer) and a
  handlebar dashboard node (3× MAX7219 cascade driving 47 status LEDs + 5161AS speed
  digits + 8-digit odometer, plus TM1637 trip/RPM/current). USE THIS SKILL WHENEVER the
  conversation touches this EV bike project or ANY of its modules, parts, protocols,
  tools or aliases — even if just one is named without re-explaining the project. Triggers:
  Mentor Mobility, K-Electric, TCS, EV bike, telematics node, dash / dashboard / Mk2 /
  handlebar node, DALY BMS, 0xA5 protocol, BLE, NimBLE, MOSFET immobilizer, charge control,
  SOC, cell balancing, GNSS, GPS, E108-GN03D, AT6558R, NMEA, wheel speed / speedometer,
  SIM800L, SIM7670G, Cat-1, GSM, 2G, Jazz APN, MQTT, ThingsBoard, LittleFS offline queue,
  OTA, MAX7219, MAX7219CNG, 5161AS, TM1637, 74HCT125, 74AHCT125, MAX3485, RS485, ESP32-S3-WROOM-1,
  N16R8, ESP32-C3 SuperMini, optocoupler / opto inputs, ignition, gears, trip reset, odometer,
  KiCad, PCBA / PCBB, Gerber, DS18B20, MP9486A buck, mk2_dash.ino, dash_link.h, evbike_node,
  telnet console, dev WiFi, brightness/dimming, watchdog, or fleet scaling.
---

# HK-EV-Fleet-Telematics

An EV-bike fleet telematics + handlebar-dashboard system. Builder: **Mentor Mobility**.
End clients: **K-Electric / TCS**. Deployment: **100-bike Karachi pilot** (currently 1 bike
on the bench).

This skill carries the shared, hard-won facts every module depends on. Open the matching
reference file (routing table at the bottom) for depth. **Separate VERIFIED from ASSUMED**
is observed throughout: VERIFIED = seen working on real hardware or in a flashed build;
ASSUMED = design intent not yet proven on hardware. When something is unknown it says
"unknown", not a guess.

---

## The system in 60 seconds

Each bike carries **two ESP32-S3 nodes** joined by a short CAT-cable UART link:

1. **Telematics node** (ESP32-S3-WROOM-1 **N16R8**). The brain. Talks to the **DALY BMS
   over BLE** (NimBLE 2.x), reads **GNSS** over UART and computes **wheel speed** off a hall
   pulse, controls the **battery MOSFETs** (immobilizer + charge control), streams telemetry
   to **ThingsBoard Cloud** over cellular (**SIM800L** 2G interim → **SIM7670G** Cat-1 target),
   queues offline to **LittleFS**, and supports **OTA**.
2. **Dashboard node** ("**Mk2**", handlebar). Second ESP32-S3. Drives the rider display:
   **3× MAX7219 cascade** (47 discrete status LEDs + 3× 5161AS 7-seg speed digits + an
   8-digit odometer), plus **TM1637** modules for trip / RPM / current. Reads local optos
   (ignition, gears, switches, RPM). Gets live data from the node and sends rpm/gear/temps
   and a trip-reset request back.

The two nodes talk over a **bidirectional framed UART link** (`dash_link.h` v3):
node→dash 22-byte frame, dash→node 14-byte frame. **The link is CROSSED** (each TX to the
other's RX) — straight-through is wrong.

Cloud is ThingsBoard; the old design (superseded) used Firebase + Google Sheets and a single
node — see `references/project-state-current.md`.

---

## Architecture (data flow)

```
        DALY BMS ──BLE(NimBLE)──┐
   GNSS E108 ──UART 9600──┐     │
   wheel hall ──pulse──┐  │     │
                       ▼  ▼     ▼
                 ┌───────────────────────┐        ┌──────────────────────┐
  MOSFET ctrl ◄──┤   TELEMATICS NODE      ├─UART──►│   DASHBOARD (Mk2)     │
  (A5 0x40)      │   ESP32-S3 N16R8       │ crossed│   ESP32-S3            │
                 │   immobilizer,         │◄─UART──┤   3× MAX7219 cascade  │
  cellular ◄─────┤   LittleFS queue, OTA  │  rev   │   TM1637 ×3, optos    │
  (SIM800L/7670) └───────────────────────┘        └──────────────────────┘
       │
       ▼
  ThingsBoard Cloud (MQTT 1883)
```

- **Forward (node→dash):** soc, current, pack V, speed, temps, flags, seq, CRC16. Dash renders.
- **Reverse (dash→node):** rpm, gear, motor/controller temps, flags (b7 = trip-reset request,
  edge-triggered). Node publishes these as engineering keys `e_rpm/e_gear/e_tmot/e_tctl`.

---

## Verified ground-truth facts

**UART link between nodes — CROSSED (VERIFIED wiring intent, this session):**
- node GPIO15 (TX) → dash GPIO16 (RX)
- node GPIO16 (RX) ← dash GPIO15 (TX)
- common GND in the same bundle. Straight-through (15→15, 16→16) does NOT work.

**DALY BMS 0xA5 protocol (VERIFIED on hardware):**
- Frame: 13 bytes `A5 ADDR CMD 08 <8 data> CKSUM`; CKSUM = sum(bytes 0..11) & 0xFF.
- Read address 0x80; MOSFET write address 0x40.
- Current = (raw − 30000) × 0.1 A (negative = discharge).
- GATT: service **FFF0**, notify **FFF1**, write **FFF2**.
- MOSFET opcodes: **0xDA = charge**, **0xD9 = discharge**. Discharge is the master switch.

**MAX7219 DIP-24 (VERIFIED — corrected after a wrong datasheet read):**
- **Pin 24 = DOUT**, NOT SEG C. **SEG C = pin 20.** (Five pins were wrong before the fix.)
- LED index rule: `index = LED number − 1`. No lookup table.
- Both GND pins (**4 and 9**) must be connected — not internally tied.
- RSET: chip A 10 kΩ; **chip B needs 15 kΩ** (3-digit scan limit).
- Decode-off (reg 0x09 = 0x00) for discrete LEDs; BCD decode only on 5161AS digits.

**GNSS (VERIFIED):** Ebyte **E108-GN03D** (**AT6558R**), 9600 8N1 NMEA, 3.3 V native,
multi-constellation (GN/BD/GL talker IDs). Wheel: 1 pulse/rev × **1.70 m**, 1 s window,
3 s zero-timeout.

**As-built 47-LED map (VERIFIED, CURRENT — supersedes the old 44-LED layout):**
safety=1, emergency=2, breaker=3, IndR=4, headlight=5, IndL=6, BMS OK=7, BMS hot=8,
SOC 9–18, controller OK=19, controller hot=20, current 21–30, motor OK=31, motor hot=32,
RPM 33–42, gears G4→N descending 43–47.

**Cloud (VERIFIED config):** ThingsBoard Cloud Free, EU host **mqtt.eu.thingsboard.cloud:1883**,
plain MQTT (SIM800L has no TLS). `mqtt.setBufferSize(1024)` is mandatory (default 256 truncates).
Two-tier telemetry 30 s / 900 s. Engineering keys `e_*` kept separate from rider-facing keys.

**Cellular (VERIFIED):** Jazz SIM, APN **jazzconnect.mobilinkworld.com**. GPIO17/18 are the
SIM800L UART on the node — do not reuse.

---

## Top gotchas (root cause → fix)

1. **MAX7219 pin 24 wrong** → documented as SEG C; it is DOUT (SEG C = pin 20). Surfaced
   when BCD decode was enabled on the speed digits. Fix: corrected pinout, five pins.
2. **Diode level-shifter (1N4001) smoked** → root cause: one shared series diode can't carry
   ~300 mA × multiple MAX7219 chips. Fix: **74HCT125** buffer, V+ at full 5 V.
3. **LED 1 (safety) always lit** → root cause: opto polarity / normally-closed interlock.
   Fix: per-channel opto inversion in NVS (`optoInv`, `i N` command).
4. **NimBLE 2.x compile error** (`NimBLEScanResults` from bool) → fix: `getResults(5000,false)`
   (ms not s), connect by `NimBLEAddress`, `setPower(9)`.
5. **MQTT rc=−2** → NOT auth. Host/port unreachable (placeholder IP / unpublished Docker port /
   Funnel). Also set buffer to 1024.
6. **Watchdog trips during groupTest** (11.4 s > 8 s) → fix: `waitMs()` feeds WDT every 10 ms,
   replaces `delay()` in blocking diagnostics; `testAllowed()` refuses them while moving.
7. **GPIO traps on S3**: GPIO35 = PSRAM (unusable), 43/44 = UART0, 45/46 = strapping (no
   internal pulls → can't INPUT_PULLUP an opto). Speed opto → GPIO42; RPM TM1637 DIO → GPIO45.
8. **File uploads frequently arrive empty** → text paste is the reliable alternative.

---

## Routing table — open the right reference file

| If the topic is… | Open |
|---|---|
| Telematics node firmware, trip/odometer, dashFeed, publish keys | `references/telematics-node.md` |
| Mk2 dashboard firmware: render loop, WDT, WiFi task, telnet, brightness | `references/dashboard-mk2.md` |
| The node↔dash UART link, frame formats, CRC, reverse flags | `references/dash-link-protocol.md` |
| DALY BMS, 0xA5 frames, opcodes, BLE/NimBLE, GATT | `references/bms-ble.md` |
| GNSS module, NMEA, wheel-pulse speed | `references/gnss-speed.md` |
| SIM800L / SIM7670G, APN, MQTT, ThingsBoard, LittleFS queue, OTA | `references/cellular-cloud.md` |
| MAX7219 pinout, cascade, 5161AS digits, TM1637, 74HCT125, LED map | `references/display-max7219.md` |
| Immobilizer state machine, charge control, MOSFET safety rules | `references/immobilizer-safety.md` |
| PCB (KiCad PCBA/PCBB), netlist, power chain, optos, buck | `references/pcb-hardware.md` |
| Humayun's conventions & working style (instructions to future-you) | `references/conventions.md` |
| Version history, config, deliverables, open issues, roadmap | `references/project-state-current.md` |

When the conversation names just one module, still skim this SKILL.md's verified facts +
gotchas first — several modules share them (UART crossing, GPIO traps, opto inversion).
