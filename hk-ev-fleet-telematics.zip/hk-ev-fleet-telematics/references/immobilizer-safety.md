# Immobilizer and charge control (MOSFET safety)

The telematics node can remotely disable the bike and control charging by driving the DALY
BMS's MOSFETs (0xA5 write opcodes, ADDR 0x40 — see `bms-ble.md`). Because this can strand a
rider or interrupt charging, it is gated by a safety state machine. **VERIFIED design** this
project.

---

## State machine — VERIFIED

Three states:

- **IMM_IDLE** — normal operation, bike rideable.
- **IMM_PENDING** — an immobilize command received but safety conditions not yet met; the node
  waits rather than cutting power under load.
- **IMM_LATCHED** — discharge MOSFET off, bike immobilized.

---

## The safety rules — VERIFIED

1. **Discharge-OFF is refused unless BOTH:**
   - **speed < 3 km/h**, AND
   - **|current| < 5 A**.

   You never cut the discharge MOSFET while the bike is moving or drawing real current — that
   would drop load instantly and could be dangerous. The command sits in IMM_PENDING until the
   bike coasts/stops, then latches.

2. **Discharge is the master switch.** **Charge-ON is refused while discharge is OFF.** You
   cannot charge an immobilized pack; re-enabling discharge is the prerequisite.

---

## MOSFET opcodes (from bms-ble.md)

- **0xD9 = discharge** MOSFET (the master / immobilizer switch).
- **0xDA = charge** MOSFET (charge control, subordinate to discharge state).
- Written as 0xA5 frames with **ADDR = 0x40**.

---

## Why it's built this way

- A fleet operator (K-Electric / TCS) needs to remotely immobilize a stolen or
  policy-violating bike — but safely, never mid-ride under load.
- Charge control lets the operator stop charging (e.g. a flagged pack) without a separate relay.
- Making discharge the master prevents the nonsensical/unsafe state of "charging an
  immobilized bike".

---

## Gotchas

- **Don't treat an immobilize request as immediate** — honour the PENDING→LATCHED gate, or you
  risk cutting power at speed.
- The speed input feeding this gate comes from the wheel pulse (see `gnss-speed.md`); if that
  input is dead, the gate should fail safe (refuse discharge-off), not fail open.
