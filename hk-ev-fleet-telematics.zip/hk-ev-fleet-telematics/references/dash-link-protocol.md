# Node ↔ Dash UART link protocol

**Header:** `dash_link.h` (**v3**, current). Bidirectional framed link between the telematics
node and the Mk2 dashboard. VERIFIED design this session; clean hardware round-trip on the
pilot bike is **bench-pending**.

---

## Wiring — CROSSED (VERIFIED intent)

| Node | Dash |
|---|---|
| GPIO15 (TX) | → GPIO16 (RX) |
| GPIO16 (RX) | ← GPIO15 (TX) |
| GND | GND (same bundle) |

**Straight-through (15→15, 16→16) is wrong.** Each node's TX goes to the other's RX.
Runs over the CAT cable between handlebar and node.

---

## Forward frame (node → dash) — 22 bytes

- **Sync:** `AA 55`
- Payload: soc, current, pack voltage, speed, temps, flags, seq (and the fields the dash
  renders).
- **CRC16-CCITT** over bytes 0..19 (the 20 bytes before the 2 CRC bytes).

## Reverse frame (dash → node) — 14 bytes

- **Sync:** `55 AA` — **deliberately byte-swapped** from the forward sync so the two directions
  can never be mistaken for each other on a mis-wired bus.
- Payload: rpm, gear, motor temp, controller temp, flags.
  - **flags b7 = trip-reset request** (edge-triggered).
- **CRC16-CCITT** over bytes 0..11.

---

## API (in `dash_link.h`)

| Function | Side | Purpose |
|---|---|---|
| `dashLinkBegin()` | both | init UART + link state |
| `dashLinkPump()` | both | parse inbound bytes into the latest valid frame |
| `dashTripResetEdge()` | node | returns true **once** per trip-reset request (consume-once) |
| `dashLinkSend()` / `dashLinkTick()` | both | emit the outbound frame at the link cadence |
| `dashOnline()` | node | true while valid reverse frames are arriving |

---

## Gotchas

- **Consume-once edge:** `dashTripResetEdge()` must clear its own flag so a single 10 s hold on
  the dash produces exactly one `tripReset()` on the node — not a reset every loop while the
  request bit is still set in the last frame.
- **CRC range matters:** forward CRC covers 0..19, reverse covers 0..11. Getting the range wrong
  makes every frame look corrupt.
- **Byte-swapped sync is intentional** — don't "fix" it to match.
