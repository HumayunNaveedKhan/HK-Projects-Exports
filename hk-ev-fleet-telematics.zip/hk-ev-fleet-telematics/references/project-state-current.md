# Project state — current

Single source of truth for **where the project is right now**: version history, live config,
deliverables, open issues, roadmap. Keep this file updated as the project moves. VERIFIED vs
ASSUMED is marked throughout; superseded items are kept and labelled, not deleted.

Last substantial update reflects the session that built this skill (2026-10-09).

---

## Version history

| Component | Version | State |
|---|---|---|
| Telematics node firmware | **v8.8.0** | current; clean end-to-end flash on pilot bike **bench-pending/unknown** |
| Dash link header | **dash_link.h v3** | current (22-byte forward / 14-byte reverse, CRC16) |
| Mk2 dashboard firmware | `mk2_dash.ino` (current rewrite) | current; clean compile/flash on real HW **bench-pending/unknown** |
| Node ↔ dash | two-node, crossed UART | current |
| Merged single-node build | planned **v9.0.0** | deferred (see roadmap) |

**Superseded (kept for context, do not use):**
- **Firebase + Google Sheets, single node** cloud design → superseded by two-node + ThingsBoard.
  (The installed `ev-fleet-telematics` skill still describes this older version.)
- **44-LED** dashboard layout → superseded by the **47-LED** as-built map.
- **11-optocoupler** count in older memory → a 13th opto + RPM/current TM1637 were added this
  session; **current opto count TBC against the board**.
- Single **TM1637 (trip only)** in older memory → now **three TM1637** (trip, RPM, current)
  this session.
- Earlier node/dash sketches: `mk2_dash_v3/v4.ino`, `c3_dash_*.ino`, `led_test*.ino`,
  `max7219_selftest.ino`, `c3_led_map*.ino`, `gnss_console_v2.ino`, `s3_uart_sim.ino` → test
  scaffolding, superseded by the current firmware.

---

## Live config — VERIFIED (ThingsBoard Cloud Free)

- Broker: **`mqtt.eu.thingsboard.cloud:1883`** (EU Frankfurt), plain MQTT (no TLS — SIM800L).
- **Device ID:** `30b150d0-9001-11f1-be6c-6b7076fe8a8d`
- **BIKE_ID:** `EVBIKE-01`
- **FW_TITLE:** `EVBIKE-FW`; firmware version string: bare semver (e.g. `8.4.0`).
- Telemetry cadence: **30 s fast / 900 s slow**.
- `mqtt.setBufferSize(1024)` (mandatory — 256 default truncates).
- Engineering keys: `e_rpm`, `e_gear`, `e_tmot`, `e_tctl` (separate from rider-facing).
- Interim public access: **Tailscale Funnel**; DuckDNS `mmevfleet.duckdns.org`.
- Cellular: SIM800L, Jazz SIM, APN `jazzconnect.mobilinkworld.com`.

### Node hardware config
- ESP32-S3-WROOM-1 **N16R8**; custom partition: **2 MB app slots (×2 OTA), 11.875 MB LittleFS**.
- `IGN_ENABLED` pending physical opto wiring; **`BENCH_MODE` still = 1** (not yet field mode).

---

## Three-stakeholder dashboard architecture — VERIFIED design

Role-based dashboards with a **hard privacy boundary enforced at the API layer**:
- **Mentor Mobility (MM):** never receives GPS coordinates or rider identities.
- **K-Electric (KE):** never receives rider names.
- Bikes appear to all as **anonymized asset IDs**.
- **Recommended build order: TCS first, then KE, then MM.**

---

## Deliverables produced

- Firmware: `evbike_node_v8_8_0.ino`, `mk2_dash.ino`, `dash_link.h` (v3), plus the test sketches.
- Docs: `EVBIKE_DASH_MK2_HANDBOOK.md`, `MK2_TRIP_ODOMETER.md`, `MK2_VEROBOARD_BUILD.md`,
  `MK2_SCHEMATIC_SPEC.md`.
- Tools: `mk2_netlist.py`, `validate_firmware.py`, `tb_export.py`, `build_dashboard_v7.py`,
  `oci_create_evfleet_v2.sh`, `oci_retry_launch.sh`.
- PCB: KiCad `PCBA_and_PCBB_schematics.net` ("ESP32S3-Dashboard" v1).
- CI: GitHub Actions weekly ThingsBoard export backup.

---

## Open issues

| Issue | Root cause / status |
|---|---|
| **Brownout resets during GSM registration** | SIM800L registration current spike sags the rail. Needs bulk cap / stiffer 4 V rail. **Open.** |
| **Silent BLE drops** (blerc 0x08 / 0x13) | Possible rail or app interference; clean disconnect event missing. Root cause **unknown**; mitigated by reconnect logic. **Open.** |
| **PCB netlist never machine-verified vs firmware** | Uploads arrived empty repeatedly; read via /mnt but not cross-checked against pin map. **Open.** |
| **TB Cloud Free data-point cap** | 1M points/month, at **~86% with ONE bike**; 30-day TTL; 5-device ceiling. Does **not** scale to 100. Self-hosting is a prerequisite. **Open/blocking for fleet.** |
| **Oracle Cloud provisioning** | Rejected on card authorization; A1 capacity retries ongoing. **Blocked.** |
| **TLS + 4G LTE** | Pending SIM7670G module delivery. **Pending hardware.** |
| **IGN_ENABLED / BENCH_MODE=1** | Pending physical optocoupler wiring; still in bench mode. **Pending.** |
| **Opto count drift** | Board added 13th opto + TM1637s this session; exact as-built opto count **TBC**. |

---

## Roadmap

1. **SIM7670G Cat-1** delivery → unlocks 4G LTE + TLS.
2. **Self-hosted ThingsBoard** on Oracle Cloud Always Free (Docker + Caddy HTTPS + nginx MQTT
   stream) — prerequisite for 100-bike scale; blocked on OCI card/capacity.
3. **Scale** single-bike bench → 100-bike Karachi pilot.
4. Build the three stakeholder dashboards (**TCS → KE → MM**).
5. **Possible merge to single-node v9.0.0** — technically feasible (5.5% CPU, 43% RAM, 2 spare
   pins) but **deferred** until dash firmware is stable, to protect deployed production node
   firmware and preserve independent OTA at fleet scale.
6. Keep the GitHub Actions weekly TB export running as backup.

---

## Known unknowns (explicitly)

- Whether `evbike_node_v8_8_0.ino` and the current `mk2_dash.ino` compile+flash clean on the
  real pilot bike end-to-end — **unknown** (session-workspace files, not hardware-logged).
- Exact as-built optocoupler count on the current Mk2 board — **unknown, TBC**.
- Root cause of the silent BLE drops — **unknown**.
- PCB netlist correctness vs firmware pin map — **unverified**.
