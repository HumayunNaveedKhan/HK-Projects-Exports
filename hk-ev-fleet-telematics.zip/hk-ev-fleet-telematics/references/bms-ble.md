# DALY BMS over BLE

The telematics node reads the DALY smart BMS over **BLE** using **NimBLE-Arduino 2.x**, with
the DALY **0xA5 protocol** carried over the BLE GATT characteristics. This is the most
battle-tested part of the stack — protocol and opcodes are **VERIFIED on hardware**.

---

## 0xA5 frame format — VERIFIED

Every frame is **13 bytes**:

```
A5 ADDR CMD 08 D0 D1 D2 D3 D4 D5 D6 D7 CKSUM
```

- `A5` = start byte.
- `ADDR` = **0x80** for reads (host→BMS), **0x40** for MOSFET writes.
- `CMD` = opcode (below).
- `08` = fixed data length.
- 8 data bytes.
- **`CKSUM` = sum(bytes 0..11) & 0xFF** (sum of the first 12 bytes, low byte).

## Read opcodes — VERIFIED

| CMD | Returns |
|---|---|
| 0x90 | pack voltage, current, SOC |
| 0x93 | MOSFET state, remaining Ah |
| 0x94 | cell count, temp-sensor count, charger/load status, cycles |
| 0x95 | individual cell voltages (multi-frame) |
| 0x96 | individual temperatures |
| 0x97 | balancing state |
| 0x98 | faults / protection flags |

## MOSFET write opcodes — VERIFIED

Written with **ADDR = 0x40**:

| CMD | Action |
|---|---|
| **0xDA** | charge MOSFET on/off |
| **0xD9** | discharge MOSFET on/off |

See `immobilizer-safety.md` for the safety rules gating these writes.

## Scaling — VERIFIED

- **Current = (raw − 30000) × 0.1 A.** Negative = discharge, positive = charge.
- Voltage / SOC scale per DALY convention (0.1 units); SOC in 0.1 %.

---

## BLE / GATT — VERIFIED

- GATT service **FFF0**.
- **FFF1** = notify (BMS → host responses).
- **FFF2** = write (host → BMS commands).
- Subscribe to FFF1 notifications, write 0xA5 frames to FFF2, reassemble multi-frame replies
  (0x95 cell voltages span several notifications).

### NimBLE 2.x specifics — VERIFIED (compile-error fix)

The 1.x → 2.x API change bit us. Correct 2.x usage:
- `getResults(5000, false)` — **milliseconds, not seconds**; the `false` is the no-delete arg.
  (The old error was `NimBLEScanResults` converting from bool.)
- Connect by **`NimBLEAddress`** object, not a raw string.
- `setPower(9)` for TX power.

---

## Gotchas

- **Checksum is a plain byte sum of the first 12 bytes**, masked to 8 bits — not CRC. Easy to
  get wrong by summing 13 bytes or forgetting the mask.
- **0x95 is multi-frame** — one request yields several notifications; don't parse the first as
  the whole answer.
- **Silent BLE drops** observed (blerc 0x08 / 0x13) — connection drops without a clean
  disconnect event. Root cause **unknown**; mitigation is reconnect logic. Listed open in
  `project-state-current.md`.
