# GNSS and wheel speed

The telematics node gets position from a GNSS module over UART and computes road speed from a
wheel hall-pulse. Both **VERIFIED** on hardware.

---

## GNSS module — VERIFIED

- **Ebyte E108-GN03D**, chipset **AT6558R**.
- **9600 baud, 8N1, NMEA** output.
- **3.3 V native** — no level shifting needed to the ESP32-S3.
- **Multi-constellation:** GPS + BeiDou + GLONASS. Talker IDs seen: **GN** (combined),
  **BD** (BeiDou), **GL** (GLONASS). Parse by sentence type, not a fixed talker ID.
- Parsed with **TinyGPSPlus**.
- Fields used: lat, lon, accuracy/HDOP, sats, speed, timestamp (and derived trip distance via
  haversine between successive fixes).

---

## Wheel speed — VERIFIED

- **1 pulse per wheel revolution** (hall sensor).
- **Wheel circumference = 1.70 m** → distance per pulse = 1.70 m.
- **1 s measurement window** — count pulses per second → speed.
- **3 s zero-timeout** — if no pulse arrives for 3 s, speed is forced to 0 (otherwise a stopped
  bike would hold its last non-zero reading).
- Speed opto / pulse input is on **node GPIO42** on the dash board side; on the node the wheel
  pulse feeds the speed counter. (The dash also derives RPM from its own opto — see
  `dashboard-mk2.md`.)

---

## Gotchas

- **Don't lock to one talker ID** — the module emits GN/BD/GL depending on which constellations
  have a fix; filtering on `$GP...` only would drop valid sentences.
- **3 s zero-timeout is essential** — without it, speed sticks at the last value when the bike
  stops.
- Trip distance uses GNSS haversine, and `tripReset()` clears `haveLastFix` to avoid a jump on
  the next fix (see `telematics-node.md`).
