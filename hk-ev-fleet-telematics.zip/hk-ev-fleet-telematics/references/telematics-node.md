# Telematics node

**Firmware:** `evbike_node_v8_8_0.ino` (current). ESP32-S3-WROOM-1 **N16R8** (16 MB flash,
8 MB PSRAM). Arduino IDE, FreeRTOS, custom partition (2 MB app slots × 2 for OTA,
11.875 MB LittleFS). The brain of the bike: BMS, GNSS, speed, cellular, cloud, immobilizer,
and the master of the UART link to the dashboard.

Separate the two sources below: **VERIFIED** = seen in a flashed build / on hardware this
project; **ASSUMED** = design intent not yet proven end-to-end on the pilot bike.

---

## Responsibilities

- Read DALY BMS over BLE (see `bms-ble.md`): V, I, SOC, cell voltages, temps, MOS state,
  cycles, faults, balancing.
- Read GNSS over UART + compute wheel speed from a hall pulse (see `gnss-speed.md`).
- Drive battery MOSFETs for immobilizer + charge control (see `immobilizer-safety.md`).
- Stream telemetry to ThingsBoard over cellular; queue to LittleFS when offline
  (see `cellular-cloud.md`).
- OTA with MD5 verify + resume.
- Master the UART link to the dashboard: send forward frames, receive reverse frames,
  act on the trip-reset request.

---

## UART link (node side) — VERIFIED wiring intent

- node **GPIO15 = TX** → dash GPIO16 (RX)
- node **GPIO16 = RX** ← dash GPIO15 (TX)
- common GND in the same bundle. **CROSSED** — straight-through does not work.
- Framing + API in `dash-link-protocol.md`.

The node's terminal block exposes pins **15 and 16** for this link; the dash connects there.

### dashFeed()
Called in the loop:
1. `dashLinkPump()` — parse any inbound reverse frame.
2. `if (dashTripResetEdge()) tripReset();` — consume-once edge; a held-10 s trip button on
   the dash sets reverse-frame flag b7, which fires this.
3. `dashLinkTick()` / `dashLinkSend()` — emit the forward frame at the link cadence.

### Engineering keys published when dash is online
When `dashOnline()` is true, the node publishes the reverse-frame data as engineering keys:
`e_rpm`, `e_gear`, `e_tmot` (motor temp), `e_tctl` (controller temp). These are kept in the
`e_*` engineering namespace, separate from rider-facing telemetry (see `cellular-cloud.md`).

---

## Trip vs odometer — VERIFIED behaviour

- **`tripReset()`** zeros `tripKm` and sets `haveLastFix = false`. It does **NOT** touch the
  odometer.
- **Odometer** can only be reset over the serial console — never by the trip button, never by
  the dashboard. This is deliberate: odometer is the tamper-resistant lifetime distance.
- Trip distance accumulates from GNSS fixes (haversine between successive fixes); resetting
  `haveLastFix` prevents a spurious jump on the next fix after a reset.

---

## GPIO map (node) — VERIFIED traps

| GPIO | Use | Note |
|---|---|---|
| 15 | UART TX → dash | link, crossed |
| 16 | UART RX ← dash | link, crossed |
| 17 | SIM800L UART | do not reuse |
| 18 | SIM800L UART | do not reuse |
| 35 | — | PSRAM, unusable |
| 43/44 | UART0 | USB serial / console |

Full S3 strapping/PSRAM trap list is in the SKILL.md gotchas and `pcb-hardware.md`.

---

## Version note

`v8_8_0` is the current node firmware developed this session. Whether it compiled and flashed
clean on the real pilot bike end-to-end is **unknown / bench-pending** — the file lives in the
session workspace, not in verified hardware logs. Earlier node sketches and the Firebase/Sheets
single-node design are **superseded** (see `project-state-current.md`).
