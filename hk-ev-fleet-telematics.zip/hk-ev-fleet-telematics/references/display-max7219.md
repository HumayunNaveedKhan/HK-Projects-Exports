# Display: MAX7219 cascade, 5161AS, TM1637, level shift

The Mk2 dashboard's visible output. Three MAX7219s in a cascade plus three TM1637 modules.
Most of this is **VERIFIED on hardware** — the pinout and LED map were corrected the hard way.

---

## MAX7219 DIP-24 pinout — VERIFIED (corrected)

**The earlier doc had pin 24 as SEG C. That was wrong.** Correct:

| Pin | Signal | Pin | Signal |
|---|---|---|---|
| 1 | DIN | 24 | **DOUT** |
| 2 | DIG0 | 23 | DIG3 |
| 3 | DIG4 | 22 | SEG D |
| 4 | **GND** | 21 | SEG DP |
| 5 | DIG6 | 20 | **SEG C** |
| 6 | DIG2 | 19 | V+ |
| 7 | DIG3? | 18 | ISET |
| 8 | DIG7 | 17 | SEG G |
| 9 | **GND** | 16 | SEG B |
| 10 | DIG5 | 15 | SEG F |
| 11 | DIG1 | 14 | SEG A |
| 12 | LOAD/CS | 13 | CLK |

Key corrections (five pins moved): **pin 24 = DOUT (not SEG C); SEG C = pin 20.** Both
**GND pins 4 and 9** must be connected — not internally tied. (If any single pin here is needed
precisely for a layout, verify against the Analog Devices MAX7219 datasheet DIP-24 drawing —
the critical, hard-won facts are DOUT=24 and SEG C=20.)

### RSET — VERIFIED
- Chip **A** (status LEDs): **10 kΩ**.
- Chip **B** (5161AS speed digits): **15 kΩ** — needed because of the 3-digit scan limit;
  fewer digits scanned means higher per-digit duty, so current must be trimmed down.

### LED index rule — VERIFIED
`index = LED number − 1`. Direct, no lookup table. (The old design had a segBit[] lookup; the
as-built wiring made it a plain offset.)

### Registers
- 0x0F test off; **0x09 decode: 0x00 on chip A (discrete LEDs), BCD on chip B (5161AS digits)**;
  0x0B scan limit; 0x0A intensity (dimming); 0x0C = 0x01 normal operation (power-on default is
  shutdown).

---

## Cascade — VERIFIED

- **3 chips on hardware SPI @ 8 MHz.**
  - **A** = 47 discrete status LEDs.
  - **B** = 3× **5161AS** 7-seg speed digits (BCD decode).
  - **C** = 8-digit odometer.
- **`mxSend(rC,vC, rB,vB, rA,vA)`** sends the **farthest chip (C) first** — in a daisy chain the
  first byte shifted ends up in the last chip.
- **Dirty-digit `mxFlush()`** writes only changed digits @ ~60 Hz.

---

## As-built 47-LED status map — VERIFIED, CURRENT

Supersedes the old **44-LED** layout (the 44-LED serial log is a superseded artifact).

| LEDs | Meaning |
|---|---|
| 1 | safety switch |
| 2 | emergency |
| 3 | breaker |
| 4 | indicator right |
| 5 | headlight |
| 6 | indicator left |
| 7 | BMS OK |
| 8 | BMS hot |
| 9–18 | SOC (10) |
| 19 | controller OK |
| 20 | controller hot |
| 21–30 | current (10) |
| 31 | motor OK |
| 32 | motor hot |
| 33–42 | RPM (10) |
| 43–47 | gears, **G4→N descending** |

Every discrete LED: **anode → SEG rail, cathode → DIG rail** (netlist `Sim.Pins "1=K 2=A"`
confirms pin1=cathode, pin2=anode). **No series resistors** — the MAX7219 is a constant-current
driver.

---

## TM1637 modules — VERIFIED

Three separate TM1637 2-wire displays: **trip**, **RPM**, **current**. **RPM TM1637 DIO moved
to GPIO45** to free GPIO42 for the speed opto.

---

## Level shifting — VERIFIED (and a fire)

- MAX7219 V+ = 5 V, logic-high threshold 0.7×V+ = **3.5 V**; the ESP32-S3 drives 3.3 V — below
  threshold. Needs a shifter.
- **Use a 74HCT125 / 74AHCT125 buffer** (HCT inputs accept 3.3 V as high, outputs swing to 5 V),
  V+ at full 5 V.
- **Do NOT use a series diode** to drop V+. The **1N4001 diode shifter smoked** — one shared
  series diode cannot carry ~300 mA × multiple MAX7219 chips. That was the root cause of the
  burn. The diode trick is acceptable only for a single chip on the bench, never production.

---

## Gotchas recap

- pin 24 = DOUT, SEG C = pin 20 (five pins were wrong).
- both GND pins required.
- no series resistors on LEDs.
- chip B RSET 15 kΩ, not 10 kΩ.
- decode must be OFF on the discrete-LED chip or it renders BCD instead of your bits.
