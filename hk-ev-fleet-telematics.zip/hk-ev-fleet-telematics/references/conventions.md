# Conventions & working style — instructions to future-you

How the engineer (Humayun, R&D engineer / independent consultant, building this for Mentor
Mobility) works, and how you should work on this project. These are **instructions to
future-you**, derived from how the collaboration actually runs.

---

## Communication

- **Direct, results-oriented. Working code over lengthy explanation.** Lead with the deliverable.
- He **pushes back when responses get overly diagnostic.** Don't narrate a long differential of
  what *might* be wrong — give the fix, then the reason in a line or two.
- Don't over-hedge. State VERIFIED facts plainly; flag the genuinely unknown as unknown.

## Firmware practice

- **Explicit semantic versioning**, bumping the version per feature addition (e.g. node
  `v8.8.0`; dash link `dash_link.h v3`). Keep doing this and record the bump.
- **Bench-validate before field.** Isolate each subsystem with a dedicated test sketch
  (`bms_simple.ino`, `gnss_test_node`, `speed_test`, `mk2_cascade_test.ino`, …) before
  integrating. When adding a feature, offer the standalone test sketch too.
- **Engineering keys stay prefixed `e_` and separate** from rider-facing telemetry — never mix
  them in a payload.
- Firmware version string is **bare semver** (e.g. `"8.4.0"`), `FW_TITLE` = `"EVBIKE-FW"`.

## Documentation habits

- Hardware decisions get written down: **KiCad netlists, markdown handbooks, veroboard build
  guides.** Existing docs: `EVBIKE_DASH_MK2_HANDBOOK.md`, `MK2_TRIP_ODOMETER.md`,
  `MK2_VEROBOARD_BUILD.md`, `MK2_SCHEMATIC_SPEC.md`, netlist generator `mk2_netlist.py`,
  `validate_firmware.py`.
- When you produce firmware, a matching handbook/readme "for us, another engineer, and any AI"
  is expected — that's literally why this skill exists.
- **Compliance / client-facing PDFs run in parallel with firmware**, kept low-key; implementation
  claims are delivered **verbally, not in writing.** Mirror that framing in written client docs.

## Uploads

- **File uploads frequently arrive empty.** When a file doesn't come through, **ask for a text
  paste** — it's the reliable path. Don't keep retrying the upload.

## Toolchain (so you reach for the right thing)

- MCUs: **ESP32-S3-WROOM-1 N16R8** (node + dash); ESP32-C3 SuperMini (earlier prototype only).
- IDE/libs: **Arduino IDE**, NimBLE-Arduino 2.x, LittleFS, FreeRTOS, ESP-IDF partition tooling,
  TinyGPSPlus.
- Cellular: SIM800L (interim), SIM7670G Cat-1 (target); Jazz SIM.
- Display ICs: MAX7219 (3-chip cascade), TM1637; 5161AS digits.
- Cloud/backend: ThingsBoard Cloud Free (EU) now; **self-hosted ThingsBoard on Oracle Cloud
  Always Free** (Docker + Caddy HTTPS + nginx MQTT stream) is the migration target.
- Networking (interim public access): **Tailscale Funnel**, DuckDNS (`mmevfleet.duckdns.org`),
  Tailscale MagicDNS.
- VCS/CI: GitHub; **GitHub Actions** (weekly ThingsBoard export backup).
- PCB/mfg: **KiCad**; **JLCPCB** assembly path for production.
- Python tooling: `tb_export.py` (TB data export), `build_dashboard_v7.py`, `mk2_netlist.py`,
  `oci_create_evfleet_v2.sh`, `oci_retry_launch.sh`.

## KiCad reminder
Symbol search matches **description, not name** — search `Device:R`, `Device:C`,
`Device:1N4148`.

---

## What NOT to put in writing / scope

- This project is sometimes documented **without naming the EV/bike project or "E-BEX"** in
  certain client-facing contexts; derived skills are listed instead (LiFePO4 BMS, wide-input
  DC-DC, TVS, reverse-polarity protection, Hall-effect sensing, GNSS, cellular). Follow his lead
  on naming per audience.
- Keep this skill **EV-fleet only** — the robotic-arm / UTM / workshop and CV/resume work are out
  of scope here by his instruction.
