# PCB and hardware (power, optos, KiCad)

The custom dashboard PCB and the board-level hardware facts. Mixed VERIFIED / ASSUMED —
the PCB netlist has **never been machine-verified against the firmware** (uploads failed
repeatedly), so treat the netlist detail as ASSUMED until checked.

---

## KiCad project — PARTIALLY VERIFIED

- Netlist file: `PCBA_and_PCBB_schematics.net` (Eeschema 10.0.4). Title **"ESP32S3-Dashboard"**,
  rev **v1**.
- Seen in the netlist: C1/C3/C5/C6 decoupling caps; **CLK1 "Trip Module"** connector;
  **D1–D28+ LEDs** with `Sim.Pins "1=K 2=A"` → **pin1 = cathode, pin2 = anode** (confirms
  anode→SEG, cathode→DIG for the MAX7219 wiring).
- **The netlist was never cross-checked against the firmware pin map** — upload attempts
  arrived empty 4×; it was finally read via /mnt paths but not machine-validated. **Open issue.**

### KiCad gotcha — VERIFIED
Symbol search matches the **description, not the name**. To place passives, search the library
prefix: **`Device:R`, `Device:C`, `Device:1N4148`** (not "resistor"/"capacitor"/"diode").

---

## ESP32-S3 GPIO traps — VERIFIED

| GPIO | Trap |
|---|---|
| 35 | PSRAM — unusable on N16R8 |
| 43 / 44 | UART0 (USB serial / console) |
| 45 / 46 | strapping pins — **no internal pulls**, so cannot `INPUT_PULLUP` an opto |
| 17 / 18 | SIM800L UART on the node |

Consequences this caused:
- **Speed opto → GPIO42** (couldn't sit on a strapping pin).
- **RPM TM1637 DIO → GPIO45** (moved off GPIO42 to free it for the speed opto).

---

## Optocoupler inputs — CURRENT

The Mk2 dash board has optos for **ignition, gears, switches, RPM**. Per-channel inversion is
stored in NVS (`optoInv`, command `i N`) because channels differ between normally-open and
normally-closed. This fixed the "safety LED always lit" interlock issue.

**Opto count note (version drift):** older memory/skills say **"11 optocoupler inputs"**. A
**13th opto** plus the RPM/current TM1637 displays were added this session. The current count
supersedes the 11-opto figure; the exact final opto count on the as-built board is **unknown /
to be confirmed against the board** — record as "11-opto version superseded; current count TBC".

---

## Power chain — VERIFIED design

```
48 V pack (40–54.75 V)
  → fuse
  → TVS (SMBJ58A class) to GND
  → reverse-polarity P-FET
  → buck ≥100 V input rating (MP9486A class — NOT LM2596, which is only 40 V in)
  → 5 V @ 1 A
       ├ 470 µF bulk + 100 nF
       ├ MAX7219 V+ (pin 19): 10 µF + 100 nF at the pin
       ├ 74HCT125 VCC: 100 nF
       └ ESP32 5V pin (onboard LDO → 3V3)
             └ 3V3 → DS18B20 VDD + 4.7 kΩ pull-up
```

- **Buck EN → ignition opto output** so the dash is ignition-switched and doesn't drain the
  pack while parked.
- **Star ground at the buck output** — do not daisy-chain the LED board ground through the MCU
  ground.
- **MP9486A-class buck, not LM2596:** the 48 V pack can hit 54.75 V and transients exceed the
  LM2596's 40 V input rating.

### Current budget — VERIFIED estimate
MAX7219 ~300 mA peak (one column conducts at a time; absolute max supply 330 mA, the scan limit
keeps you inside it) + ESP32 ~25 mA (radios off) + buffer <1 mA ≈ **~350 mA peak; spec the buck
at 1 A**.

---

## Temperature sensing — VERIFIED
**DS18B20** 1-Wire with a 4.7 kΩ pull-up to 3V3. (Local dash temps; BMS pack temps come over
BLE.)

---

## RS485 — DEFERRED / ASSUMED
An **RS485 path (MAX3485 each end, 120 Ω terminations)** is planned for when the dash sits >~1 m
from the node or shares conduit with motor phase wiring. For now the inter-node link is plain
UART over CAT cable. Lay out the production PCB with the transceiver footprint present either
way. **Not yet built.**
