# Cellular, cloud, offline queue, OTA

How the telematics node gets data off the bike: a cellular modem, plain MQTT to ThingsBoard,
a LittleFS queue for offline periods, and OTA for firmware updates.

VERIFIED = configured/seen working; ASSUMED = design intent. The SIM7670G migration is
**ASSUMED / planned** — SIM800L is the interim on the bench.

---

## Cellular modem

- **Interim: SIM800L (2G).** VERIFIED on bench. **No TLS** → plain MQTT only. GPIO17/18 on the
  node are its UART. 2G is being shut down in many markets, so this is interim only.
- **Target: SIM7670G (Cat-1 LTE).** ASSUMED/planned — the production modem. Supports TLS and
  survives 2G sunset.
- **SIM:** Jazz (Mobilink). **APN = `jazzconnect.mobilinkworld.com`.** VERIFIED.

---

## Cloud — ThingsBoard — VERIFIED config

- **ThingsBoard Cloud Free**, EU region.
- Broker: **`mqtt.eu.thingsboard.cloud:1883`** (plain MQTT, no TLS — matches SIM800L).
- **`mqtt.setBufferSize(1024)` is mandatory.** Default is 256 and silently truncates the JSON
  telemetry payload. (This was a real bug.)
- **Two-tier telemetry cadence:** fast tier every **30 s**, slow/aggregate tier every **900 s**
  (15 min). Keeps point count down while staying live.
- **Key namespaces:** rider-facing telemetry vs **engineering keys `e_*`** (`e_rpm`, `e_gear`,
  `e_tmot`, `e_tctl`, …) are kept separate so dashboards and rules don't mix them.

### The old cloud design — SUPERSEDED
The earlier architecture used **Firebase + Google Sheets** with a **single node**. That is
superseded by the two-node + ThingsBoard design. The old `ev-fleet-telematics` installed skill
still describes the Firebase/Sheets version — treat this file as current.

---

## Offline queue — VERIFIED design

- **LittleFS** ring/queue on the node's 11.875 MB LittleFS partition.
- Holds roughly **~588 hours** of buffered telemetry at the chosen cadence, so a bike out of
  coverage for days still back-fills when it reconnects.
- On reconnect, drain the queue to the broker before resuming live publish.

---

## OTA — VERIFIED design

- Dual **2 MB app slots** (custom partition table).
- **MD5 verify** of the downloaded image before switching slots.
- **Resume** support for interrupted downloads (important on flaky 2G).

---

## Gotchas

- **MQTT rc = −2 is NOT an auth failure** — it's TCP connect failure: unreachable host/port,
  placeholder IP, an unpublished Docker port 1883, or a Tailscale Funnel in the way. Check
  reachability, not credentials.
- **Buffer size 256 → truncated payload.** Always `setBufferSize(1024)`.
- **SIM800L brownout resets during GSM registration** — the registration current spike sags the
  rail and resets the node. Root cause: rail can't supply the TX burst. Mitigation: bulk
  capacitance / a stiffer 4 V rail at the modem. Still **open** (see `project-state-current.md`).
- **TB Cloud Free has a 1M-data-point cap** — already at ~86% with ONE bike. It does **not**
  scale to 100 bikes; self-hosting ThingsBoard is a prerequisite for the fleet (open issue).
