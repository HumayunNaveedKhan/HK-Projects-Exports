# Dashboard node (Mk2, handlebar)

**Firmware:** `mk2_dash.ino` (current). Second ESP32-S3, on the handlebar. Drives the rider
display and reads local optos; gets live data from the telematics node over UART and sends
rpm/gear/temps + a trip-reset request back.

VERIFIED = seen working on the bench this project; ASSUMED = design intent, bench-pending.
The current `mk2_dash.ino` living in the session workspace is **unknown / bench-pending** for
a clean end-to-end compile+flash on the pilot bike. Earlier sketches (`mk2_dash_v3/v4.ino`,
`mk2_bench_test.ino`, `mk2_cascade_test.ino`, `c3_dash_*.ino`, `led_test*.ino`,
`max7219_selftest.ino`, `c3_led_map*.ino`) are **superseded**.

---

## Display hardware (see `display-max7219.md` for pinout/map)

- **3× MAX7219 cascade** on hardware SPI @ 8 MHz, dirty-digit tracking @ ~60 Hz.
  - Chip **A** = 47 status LEDs (10 kΩ RSET).
  - Chip **B** = 3× **5161AS** speed digits (15 kΩ RSET, BCD decode on).
  - Chip **C** = 8-digit odometer.
- **TM1637** modules: trip, RPM, current (separate 2-wire each).
- **74HCT125** level shifter (3.3 V logic → 5 V MAX7219 threshold).

### mxSend / mxFlush
- `mxSend(rC,vC, rB,vB, rA,vA)` sends the **farthest chip first** (C, then B, then A) — correct
  order for a daisy chain where the last byte shifted lands in the nearest chip.
- `mxFlush()` writes only digits whose cached value changed (dirty-digit), keeping the 60 Hz
  refresh cheap.

---

## Render model — VERIFIED split

- **`renderLocal()`** — always runs, link-independent: switches, gears, RPM, local temps.
  The rider's safety-critical indicators never blank just because the BMS link dropped.
- **`renderBms()`** — runs only when the forward link is live: SOC, current, pack temps.
- **`attractBms()`** — attract/animation when the BMS link is absent (subtle, not a hard blank).
- When the BMS is disconnected the firmware writes **"bms disc"**-style text on the odometer
  line so the condition is visible, then returns to normal when the link returns.
- Transitions are deliberately **subtle** (no harsh flashing) — a rider UX requirement.

---

## Road-build hardening — VERIFIED requirements

- **Instant boot display:** the dash shows immediately when ignition goes on. It does **not**
  wait for WiFi.
- **Ignition bulb-check:** brief all-on sweep at ignition to prove every LED.
- **8 s task watchdog**; blocking diagnostics use **`waitMs()`** (feeds WDT every 10 ms) instead
  of `delay()`.
- **`testAllowed()`** refuses blocking diagnostics when `rpm > MOVING_RPM` (200) — no self-test
  while the bike is moving.
- **WiFi is opt-in, off the critical path:** a **20 s hold** of the brightness button starts a
  dev-WiFi FreeRTOS task on **core 0**. SSID `GN175`. (Credentials were set per-session;
  treat any pasted password as a secret — do not echo it.)
- **Telnet console:** a `Tee : public Print` class mirrors serial to a telnet client for remote
  debugging over dev WiFi.

---

## Local inputs (optos) — VERIFIED

The Mk2 board has optocouplers for: switches, ignition, gears, and RPM. Per-channel opto
inversion is stored in NVS (`optoInv`, command `i N`) to handle normally-closed vs
normally-open channels — this is what fixed "LED 1 (safety) always lit".

- One switch LED reads as "one" irrespective of the raw opto sense (handled by inversion).
- **Trip reset switch on GPIO17**: a **10 s hold** sends the reverse-frame trip-reset request
  (flag b7) to the node.
- **Brightness button on GPIO18**: short press cycles **4 dimming levels**; **20 s hold** →
  dev WiFi.
- **Speed opto on GPIO42**; **RPM TM1637 DIO moved to GPIO45** (freed GPIO42 for the opto).

---

## Reverse data sent to node

Via the reverse frame (see `dash-link-protocol.md`): rpm, gear, motor temp, controller temp,
and flags (b7 = trip-reset request, edge-triggered / consume-once). The node turns these into
`e_rpm/e_gear/e_tmot/e_tctl`.
