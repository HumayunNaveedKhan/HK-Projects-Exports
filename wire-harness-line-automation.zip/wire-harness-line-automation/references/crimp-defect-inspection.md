# Wire Crimp / Terminal Defect Detection — Yazaki

Inspection of crimped terminals for copper bellmouth formation, terminal bend,
PVC insulation position and terminal deformation.

Status: **active.** Android POC app working; moved to a desktop Python/OpenCV
toolchain (`thal-inspect`) with learned tolerances; a correct OK verdict with
accurate bend measurement achieved on a real sample (2 Oct 2026).

---

## 1. Scope and plant constraints [VERIFIED — from the plant]

- **Defects in scope:** copper bellmouth formation, terminal bending (**3°
  tolerance**), PVC insulation positioning, terminal deformation.
- **Terminal range, first phase:** small / fine gauge, **0.13–0.85 mm**.
- **Presentation:** operators present terminals **in batches through a 90 mm
  window** — not 100 wires slid at once. The fixture and field of view are
  designed around that window.
- **The terminals are closed female terminals with no exposed copper strands.**
  This was discovered from a real photo and invalidated an earlier
  copper-visibility gate. Assumptions about male pin crimps with visible
  strands are wrong for these parts.
- **Volume: 270,000 pcs/day** (6 × 15,000 + 18 × 10,000). 100% inspection is a
  many-station throughput claim. **Phase 1 proves detection, not throughput** —
  keep that distinction explicit when framing success to management.

## 2. Current architecture [DESIGN + VERIFIED where noted]

**Two tracks, both alive:**

**(a) Android app** — Kotlin + OpenCV on a **Samsung Note10** (landscape-
locked, Android 10+). Handheld, used on the floor. Its real Phase-1 job is
**building the labelled image dataset** for a later trained model. Reported
working behaviour [VERIFIED]: locks onto the **largest object in view** (the
terminal), draws a rotated box, measures tilt against horizontal, green box →
red if tilt > 3° with the angle printed; **CAPTURE** saves clean frames to
`Pictures/ThalPOC`; **VIEW** cycles Normal → Silhouette → Edges so you can see
on the floor exactly what the camera can and cannot resolve; torch toggle; live
edge-sensitivity slider. A later version reached a **5-slot horizontal batch
layout** reporting per slot: `OK`, `NG:BELL`, `NG:PVC-CU`, `NG:PVC-SHORT`,
`NG:BEND`.

**(b) Desktop `thal-inspect`** — Python + OpenCV, the current direction.
Learned-reference architecture:

| File | Role |
|---|---|
| `capture.py` | saves images |
| `tune.py` | live trackbars to calibrate copper / background HSV thresholds |
| `learn.py` | measures **golden (good) sample images** and derives acceptable tolerance bands as **mean ± k·std** — tolerances are learned, not hardcoded |
| `inspect_live.py` / `inspect_image.py` | run detection |
| `selftest.py` | validates the pipeline against **synthetic** terminal images, no camera needed |

A standalone iPhone-webcam utility exists as a side tool, kept deliberately
separate from the main project.

**Imaging rig:** **Logitech MX BRIO 4K** webcam on an overhead stand, **two
white high-CRI lights at 45°**, matte-grey comb fixture, focus and exposure
**locked in Logi Tune** on the Mac. Compute: refurbished desktop PC (Pi 5 8GB
+ Hailo-8L AI Kit retained in the BOM for the later model phase).

**Comb fixture:** flat slots with a rest-ledge, to hold terminals flat and
front-facing for consistent presentation. A **V-groove self-seating comb**
(black Delrin/acetal, 90° groove) was recommended as the first orientation
mechanism but the **V-groove is deferred**; flat slots first.

## 3. Detection decisions that survived contact with reality [VERIFIED]

1. **Colour is used only for copper-bellmouth detection.** Everything else —
   bend, PVC reach, terminal shape — is measured by **geometry/silhouette**, so
   it works across all insulation colours.
2. **Copper detection must be gated to the thick terminal body, never the thin
   wire**, because warm-coloured insulation shares copper's hue.
3. **The working combination**, found after shading the setup to kill
   ceiling-light glare and moving the camera much closer: **bright-on-dark
   silhouette segmentation + a high-saturation threshold (S ≥ 150)** for
   copper. That successfully isolated **both bellmouths** from a warm-tinted
   reflection on the tin terminal body and produced a **correct OK verdict with
   a 0.45° bend measurement on a real sample.**
4. **Getting the camera very close and controlling glare with shading and
   diffusion matters more than the exact algorithm choice.**
5. **Subtle terminal deformation is beyond classical CV's reliable reach.** This
   is acknowledged, not papered over, and is the justification for a future
   trained-model phase (YOLO or anomaly detection). The golden and defect images
   being collected now are that model's training data.

## 4. Dead ends — each one cost real time

| Approach | Why it failed |
|---|---|
| **Fixed ROI boxes** at set % of frame (insulation 25–40%, brush 55–70%) | Only works if the wire lands in exactly the same spot every frame — impossible handheld. Also caused the `boundingRect` / `MatOfPoint` crash, which was a *symptom* of forcing a rigid method, not a coding bug. |
| **Colour-based PVC detection** | Insulation comes in many colours, not just red. |
| **Copper-visibility gating** | Closed female terminals have no exposed strands. |
| **Otsu silhouette on an uncontrolled desk scene** | Canny survived bad lighting and "seemed to work"; the silhouette the measurements hung off did not. The pipeline was standing on sand. Fix the light, not the threshold. |
| **Copper-by-colour at normal working distance** | Yellow/red PVC hue collides with copper hue; bellmouths too small and faint to resolve. Solved only by getting much closer + shading + S ≥ 150. |
| **Phone flash / torch as main light** | A hard point light aimed at shiny tin blows the crimp into white glare — exactly what breaks edge detection. Keep the torch as a dark-corner fallback only; rely on diffused external light. |
| **NVIDIA Jetson Orin Nano** | Expensive, hard to source in Pakistan. Removed from BOM. |
| **Global-shutter cameras, blue/red backlighting** | The backlight existed to serve a silhouette method that was abandoned. |
| **iPhone 15 / iOS rewrite** | Better macro optics (~2 cm via the ultrawide), but the MacBook Pro is **Intel** — current Xcode is going Apple-Silicon-only — and the whole Kotlin pipeline (profile scanning, copper gate, bellmouth logic) would be re-implemented in Swift + the fiddlier OpenCV iOS framework. Decision: stay Android. If you want the iPhone's lens, use its **built-in Camera app in macro mode** for dataset shots; the images feed training regardless of which device took them. |

## 5. Known OpenCV-on-Android gotchas [VERIFIED]

- `Mat` fields must be `lateinit` and initialized **after**
  `OpenCVLoader.initDebug()`, or you get `UnsatisfiedLinkError` — this was a
  fatal crash.
- Unthrottled frame processing freezes the UI. Cap frame size and throttle.
- The OpenCV Android SDK was missing functions in one configuration; check the
  SDK build before assuming a logic bug.

## 6. Phase 2 directions discussed, not chosen

- In-line camera at the crimp press (inspect at the moment of crimping).
- Rotating or multi-camera presentation to see the terminal from more than one
  side.
- **Anomaly-detection models trained only on good parts** — attractive because
  defect samples are scarce and the golden-sample dataset already being
  collected is exactly the right input.

## 7. Open questions

- [UNKNOWN] Was the comb fixture actually built?
- [UNKNOWN] Was `PX_PER_MM` ever calibrated against a ruler shot? Until it is,
  the **gate** (pass/fail logic) is more trustworthy than the **absolute
  numbers** it reports. Say so rather than quoting millimetres with confidence.
- [UNKNOWN] Pass/fail tolerance bands for bellmouth size and PVC reach, in mm,
  signed off against the plant's own spec.
- [UNKNOWN] How many golden and defect images have been collected so far.
- [UNKNOWN] Whether a station design (throughput, operator cycle) has been
  scoped beyond the handheld/bench POC.
