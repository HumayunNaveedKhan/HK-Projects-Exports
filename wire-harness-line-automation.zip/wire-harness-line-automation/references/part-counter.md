# Part Counter — Yazaki Store

Weigh-counting of small parts (terminals, connectors, clips) issued from the
store to workers, with job-card traceability.

Status: **not started.** Recommended as the clear quick win in the Aug 2026
project-selection review, PoC estimated at **2–3 weeks**. Still the
highest-fit, lowest-risk project on the list and still unopened. Everything
below is [DESIGN] — nothing has been built or bought.

---

## 1. Why this one was picked as the quick win

From the full feasibility review across nine candidate projects:

| Project | Plant | Embedded : CV | Difficulty | Business value | PoC | Full deploy | Fit |
|---|---|---|---|---|---|---|---|
| **Part counter** | Yazaki | **95 : 5** | Low–Med | Med–High | **2–3 wk** | 3–4 mo | ★★★★★ **best fit** |
| Wireless ECT | Korangi | 85 : 15 | High | Very High | 6–10 wk (wired PoC) | 9–12+ mo | ★★★★ embedded ✓ but a programme |
| Guided sub-assy (poka-yoke) | Yazaki | 90 : 10 | Medium | High | 4–6 wk | 2–3 mo | ★★★★ duplicates Korangi work |
| Guided sub-assy | Korangi | 90 : 10 | Medium | Med (deprioritized) | ~done / 4–6 wk | 2–3 mo | ★★★ least priority |
| Defect detection (crimp/connector) | Yazaki | 40 : 60 | High | High | 6–8 wk | 4–6 mo | ★★ CV creeps in |
| Kaizen Mgmt System + chatbot | Yazaki | software | Medium | Medium | 4–6 wk MVP | 3–4 mo | ★★ off the embedded skillset |
| FVI | Korangi | 10 : 90 | Very High | High | 2–3 mo | 8–12+ mo | ★ CV-heavy, wrong tool |
| Co-pilot (head-cam guidance) | Yazaki | 30 : 70 | High | Medium | 2–3 mo | 6+ mo | ★ CV-heavy, least priority |
| Ergonomics scoring | Yazaki | 5 : 95 | High | Medium | 2–3 mo | 6+ mo | ★ pure pose-estimation CV |

(Timelines are calendar time for a solo engineer who also carries DM duties,
not man-hours.)

**The strategic argument:** the binding constraint is one person with limited
runway, so bank one guaranteed quick win to build credibility, then make one
strategic embedded bet. **Ship the part counter first, then open the ECT PoC.**
That sequencing advice still stands and has not yet been followed.

## 2. Architecture

**MVP: a single "smart shelf" of load-cell bins.**

```
bin → load cell → NAU7802 (I²C, 24-bit) → ESP32-S3 → local display
                                              └→ Pi / Excel logging backend
barcode scan of the job card at issuance → consumption attributed to a job
```

- **Tare the empty bin**, store the **unit weight per part**, count live from
  the delta weight.
- **Multiplex several NAU7802s** (address or mux) on one ESP32-S3.
- Local display plus logging to the same **Pi/Excel backend pattern** already
  used elsewhere in the programme.
- **The barcode scan of the job card at issuance is the traceability hook** —
  it is what turns a scale into an IATF-friendly consumption record, and it is
  the reason this is worth doing at all rather than buying counting scales.

## 3. Watch-outs

- **Match the cell range to the part.** Sub-gram terminals need **1–2 kg
  cells, not 5 kg**, or resolution dies.
- **Drift and vibration** → filtering plus periodic auto-retare.
- **Mixed parts in one bin breaks weigh-counting.** Enforce **one part number
  per bin.**
- **Use NAU7802, not HX711** — the programme-wide rule; HX711's 10/80 SPS is
  too slow, and the 24-bit NAU7802 at up to 320 SPS is the settled part.
- **Define the accuracy target up front** — ±1 part on discrete items is the
  suggested commitment. Agree it before building, because it decides cell
  range, filtering and whether the result is auditable.

## 4. Phasing

1. **Single-bin PoC — 2–3 weeks.** One bin, one part number, prove the count
   against a hand count.
2. **6–8 bin shelf pilot — ~1 month.**
3. **Store-wide rollout — 3–4 months.**

## 5. Open questions — all of it, essentially

- [UNKNOWN] How many bins / part numbers the store issues.
- [UNKNOWN] The part list and unit weights (and whether unit weights are stable
  enough across lots to weigh-count at all).
- [UNKNOWN] Lightest part in scope — sets the load-cell range and the accuracy
  that is physically achievable.
- [UNKNOWN] Accuracy target, agreed with the store and quality.
- [UNKNOWN] Whether the store already scans job cards, and in what format.
- [UNKNOWN] Any BOM or cost estimate — none has been produced.
- [UNKNOWN] Whether management has been asked for this at all.
