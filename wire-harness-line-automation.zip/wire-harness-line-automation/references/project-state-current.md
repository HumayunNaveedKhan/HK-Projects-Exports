# Project State — Current

**As of: 9 October 2026.** Update the date and the changed rows whenever
something lands; this file is the one that goes stale fastest.

---

## 1. Where each machine stands

| Machine | Phase reached | Last movement | Next action |
|---|---|---|---|
| **Fuse box inspection** | App delivered, engine rewrite mid-flight | 9 Oct 2026 | Confirm what the rewrite fixed; mount camera + lighting; teach a real golden box; compile and bench-test the STM32 firmware |
| **Crimp defect inspection** | Desktop `thal-inspect` producing correct verdicts on real samples | 2 Oct 2026 | Calibrate `PX_PER_MM`; build/confirm the comb fixture; grow the golden/defect dataset |
| **Wireless ECT** | Architecture + README + SVG diagram | 3 Sep 2026 | **Close the two gating decisions** (test-point count, hi-pot in/out) before any schematic |
| **Sub-assembly machine** | Phase-1 BOM (~$1,700) and full design | 25 Aug 2026 | **Phase 0 gemba**: connector Pareto + 4 weeks of checker data + change-control path |
| **FVI** | One-pager issued to management and floor | 27 Aug 2026 | Phase 0 image collection (~$150) — **gate, nothing else approved** |
| **Part counter** | Recommended, scoped verbally | 28 Aug 2026 | Not started. Single-bin PoC, 2–3 weeks |

**The sequencing advice given and not yet followed:** ship the **part counter**
first to bank credibility, then open the **ECT PoC**. Everything else queues
behind those two. The vision work (crimp, fuse box) ran ahead of this plan
because the plant asked for it.

## 2. Deliverables produced to date

| Deliverable | Machine | Form |
|---|---|---|
| `PC_Guided_SubAssy_Machine_Strategy.md` — market research, four architecture families, vendor/cost analysis, full system design, Excel schema, phasing, risk register | Sub-assy | Markdown document |
| Five-jig component list with per-block costing (~$4,213/station) | Sub-assy | In-chat tables |
| Simplified Phase-1 BOM (~$1,700, two jigs, Pi CM5) | Sub-assy | In-chat table |
| Wireless ECT engineering README — architecture, per-channel topology, component selection with Pakistan sourcing, POC vs industrial comparison, BOM, protection philosophy, firmware flowcharts, repo structure | ECT | Markdown document |
| Full SVG connection diagram, one complete 64-pin card (power rails, I²C bus, one channel in detail, LED chain, REF pigtail) | ECT | SVG |
| Email + README bringing the boss up to speed on the ECT concept and the GND/REF refinement | ECT | Email + doc |
| `thal_android_poc_v2.md` — complete Android POC guide with all code files | Crimp | Markdown document |
| Working Android crimp-inspection app, 5-slot batch detection | Crimp | Kotlin app |
| `thal-inspect` Python toolchain (`capture`/`tune`/`learn`/`inspect_live`/`inspect_image`/`selftest`) | Crimp | Python project |
| POC imaging rig: MX BRIO + 2× high-CRI lights + comb fixture | Crimp | Physical |
| `fusebox_inspector.zip` — PySide6 app, OpenCV engine, camera abstraction, STM32 link + simulator, teach mode, STM32 firmware, demo/selftest/smoketest tools | Fuse box | Python project + firmware |
| Fuse-box architecture Word document (architecture diagram, IO protocol table, timeline) | Fuse box | .docx |
| FVI one-page A4 brief for management and floor (scope, concept, BOM, 22-week timeline, OMI-10 baseline questions, three floor data requests) — two iterations | FVI | PDF via ReportLab |
| Nine-project feasibility table with embedded:CV ratios, difficulty, value, PoC and deploy timelines, fit scores | All | In-chat table |

## 3. Configuration — current values

### Fuse box station (`config.json`)
| Key | Current / default | Note |
|---|---|---|
| `camera.type` | `folder` (Mac dev) → `hik` on the station | |
| `camera.folder` | `samples/live` | |
| `camera.hik_user_set` | `1` | MVS User Set holding manual exposure/gain/WB |
| `bayer_swap_rb` | `false` | set `true` if red and blue swap |
| `serial.port` | `SIM` → `COM5` on the station | Black Pill USB-CDC |
| `station.seat_settle_ms` | `300` | |
| `station.buzzer_ms` | `2000` | |
| `station.stamp_button_rechecks_ng` | `true` | |
| `storage.save_raw` | `ng` | keep NG raws — they are what colour limits are tuned on |
| `admin_password_sha256` | sha256("1234") | **change this** |
| ΔE limit | `10` | good ≤ 4.6, wrong = 18 on the demo set; **re-tune on real station images** |
| Alignment | `affine` on the fixture | `homography` only for the hand-held demo photos |

**Station network:** PC `192.168.10.1/24`, camera `192.168.10.2`, dedicated
NIC, jumbo frames 9000, firewall exception. Pixel format **BayerRG8**, all
autos **off**, saved to User Set 1.

### Sub-assembly machine (planned)
Compute **Pi CM5** (eMMC) + 7" DSI touchscreen; read-only rootfs with
overlayfs, `/data` partition, DC UPS on the 24 V rail. Shared **~19-conductor
ribbon**: SPI ×4, mux address ×4, board enable ×5, 1-Wire ×1, drive/sense ×2,
power ×3. Jig board: 4× CD74HC4067, 2× TLC5947, 1× DS28E07, 6× SP3012-06UTG
TVS, 64 LEDs + 1 kΩ series. Scan: one-hot drive, <10 mA, resistance-thresholded
(`max_resistance_ohm` default 2.0), compare to `expect_net`.

### Wireless ECT (planned)
Per card: 1× ESP32-S3, 4× MCP23017 (unique 3-bit addresses), 64× 470 Ω,
64× BAT54S, 64× WS2812B, 4.7 kΩ I²C pull-ups, AMS1117-3.3, PTC + SMBJ5.0A.
**All logic at 3.3 V**, USB-C 5 V in. Two cards, master on telnet-serial to the
laptop, ESP-NOW between cards. **Single GND/REF pigtail, mandatory.**

## 4. Superseded configuration — kept deliberately

These were real decisions that were then replaced. **Marked, not deleted** —
if a constraint changes, the earlier answer may become right again.

| Superseded | Replaced by | Why |
|---|---|---|
| Sub-assy: fanless Intel N100 mini-PC ($230) as station computer, Windows 11 IoT LTSC or Ubuntu kiosk | Raspberry Pi CM5 + DSI touchscreen | The Pi absorbs the mini-PC's job (Excel compiler, SQLite, UI) at no net cost and removes Windows from the floor. **Still the right answer if the plant mandates Windows or a nameplate industrial PC.** |
| Sub-assy: ESP32-S3 + W5500 wired Ethernet station controller ($72 board) + 7" RGB parallel panel via LVGL | Pi CM5 | Was itself the answer to the phone-HMI proposal, and is still the fallback if Linux timing or boot time ever proves unacceptable. |
| Sub-assy: RP2040 or STM32G031 per jig node + RS-485 Modbus RTU daisy chain + DB-37 harness per jig | Dumb jig boards on a shared ribbon from one controller | Five extra firmware targets, an address scheme and five desync risks, for five jigs bolted to one bench. |
| Sub-assy: 5-jig station at $4,213 | 2-jig Phase-1 at ~$1,700 | Deferred pull force, pick-to-light, cabin LEDs, enclosure, EMI/surge, e-stop, 3 of 5 jigs. |
| ECT: 64 switched I/O at **24 V** field rail with opto-isolation | **3.3 V** logic, 470 Ω + BAT54S, USB-C 5 V | Harness is always de-energized at test. **Reinstate isolation if that ever stops being true.** |
| ECT: screen mounted on the hardware | Laptop/MacBook shows the map | |
| ECT: TPIC6B595 switch matrix + 4-wire Kelvin + 24-bit ADC (from the project-selection review) | MCP23017 pull-up drive-one/read-all | Continuity-only scope. **The Kelvin design returns the moment resistance grading enters scope.** |
| FVI: multiple fixed camera pods, 2× 20 MP + 6× 5 MP + IPC/Jetson, ~$9–12k | Single traveling camera head on a belt rail, ~$925 | Cost. |
| Crimp: Jetson Orin Nano | Refurb desktop PC; Pi 5 + Hailo-8L retained | Cost and Pakistan sourcing. |
| Crimp: global-shutter cameras + blue/red backlight | MX BRIO + 2× white high-CRI at 45° | The backlight served an abandoned silhouette method. |
| Crimp: V-groove self-seating comb (black Delrin, 90°) | Flat slots with a rest-ledge | V-groove **deferred**, not rejected — it is still the recommended next orientation mechanism. |
| Crimp: Android app as the detection platform | Desktop Python `thal-inspect` | The app remains the **dataset-collection and floor-demo tool**. |

## 5. Open issues, by severity

**Blocking — nothing downstream can be committed without these**
1. **Reject Pareto / defect frequency data** (4–6 months of checker data).
   Requested for both FVI and sub-assy. Never supplied. It is the ROI baseline
   *and* it decides which defects each machine targets.
2. **Connector Pareto** for the sub-assy jig library — $6k project or $22k
   project.
3. **ECT total test-point count** and **hi-pot / IR in or out of scope**.
   Flagged twice; still open; nothing about card count or electrical design can
   proceed.
4. **Takt time** for every station.

**High**
5. **`F_threshold` per connector/terminal**, from supplier spec with customer
   sign-off. The sub-assy pull check cannot be configured without it.
6. **Customer change-control / PPAP path** for modifying an approved poka-yoke
   device. Find this out before building, not after.
7. **Fuse box engine rewrite outcome** — unreported as of 9 Oct.
8. **Fuse box STM32 firmware has never been compiled or run on hardware.**
9. **Fuse box lens–sensor mismatch** — crop ROI or buy a 1.1" lens. Unresolved.

**Medium**
10. **OMI-10 nameplate specs** — the baseline the new ECT must beat.
11. **`PX_PER_MM` calibration** for the crimp pipeline; absolute measurements
    are untrustworthy until it is done.
12. Crimp pass/fail bands in mm for bellmouth size and PVC reach, signed off.
13. Whether the crimp comb fixture was built.
14. Whether the two ECT cards were built.
15. Which plant owns the photographed sub-assy station.
16. Part counter: **everything** — bin count, part list, unit weights, accuracy
    target, BOM, whether it has even been proposed.
17. Management / budget approval status for **any** of the six machines. No
    record of anything being funded.

## 6. Roadmap

**Near term (weeks)**
- Fuse box: confirm the rewrite, mount camera + enclosure lighting, teach real
  golden boxes, compile and bench the STM32 firmware, re-tune ΔE on station
  images. Deadline self-set at ~2 months from early Oct, Friday on-site.
- Crimp: calibrate `PX_PER_MM`, keep growing the golden/defect dataset.
- Ask the floor, once, for the four blocking data items above. They have been
  asked for repeatedly in pieces; a single consolidated request is overdue.

**Mid term (1–3 months)**
- Part counter single-bin PoC (2–3 weeks) — the unclaimed quick win.
- Sub-assy Phase 0 gemba and the connector Pareto. Zero cost, highest leverage.
- ECT: close the two gating decisions, then a wired single-board PoC against
  one representative harness validated to a golden sample.

**Later**
- Sub-assy Phases 1–2 (screen-only prototype, then single-jig continuity node;
  gate = 500 consecutive insertions, zero false reject, zero false accept).
- Crimp Phase 2: trained model (YOLO or anomaly detection on good parts only)
  using the dataset being collected now.
- FVI Phase 0 image collection, only if resourcing changes.
- Sub-assy Phase 3 pull force (bolts on at ~$533 without touching Phase 1).

**Explicitly parked:** FVI as a solo pursuit, ergonomics scoring, the head-cam
co-pilot, Kaizen management system + chatbot. All ruled out on CV load or
skill-fit grounds, not on value.

## 7. Adjacent work — not part of this programme

These share the person, the toolkit and some learnings, but not the plant line.
Don't let them bleed into harness answers.

- **DCRC-TE** — LBS remote control/monitoring unit for K-Electric. STM32F411 +
  A7670E, custom `TE-DCRC-v3` PCB. Has its own memory file.
- **OLTS** — oil level and temperature sensor, PPMC type approval, SGS EMC
  testing, STM32G030 + MAX31865 + isolated RS-485 board.
- **EV fleet telematics** — prior project, has its own installed skill
  (`ev-fleet-telematics`). The ESP32-S3 + SIM7670G stack and several learnings
  originate there.
