# Wireless ECT / OMI Continuity Tester — Korangi

End-of-line electrical check tester for completed harnesses. Modular,
wireless-linked 64-pin cards. Thal's company side supplies the fixture boards
and jigs; the electronics are his.

Status: **architecture settled, engineering README and SVG connection diagram
delivered (3 Sep 2026). No hardware built.** [DESIGN throughout unless marked]

---

## 1. What an ECT is

"ECT" (Electrical Check Tester; also *kensa-ki*, continuity checker, harness
board tester, **OMI** in this plant) is the end-of-line poka-yoke gate. The
finished harness drops onto a fixture where every connector mates with a
**counterpart connector** wired back to the tester, which verifies it against
**master data** — the netlist exported from harness CAD. [RESEARCH]

Tests, in rough order of importance:

| Test | Catches |
|---|---|
| Continuity within net | Open wire, broken crimp, missing wire |
| Short / isolation between nets | Stray strand, pinched wire, wrong-cavity insertion |
| Mis-wire / cross-wire | Terminal in wrong cavity, swapped pins |
| Contact resistance | Bad crimp, half-fit terminal, oxidised terminal |
| Component check | Diode polarity, resistor value, relay coil, lamp, fuse |
| Connector-seated / lock detect | Half-fit connector (sensor per jig, not electrical) |
| Clip / grommet / branch length | Mechanical limit switches, pin gauges |
| Insulation resistance / hi-pot | HV (EV) harnesses only — 500 V DC IR, 1–3 kV withstand |

**The governing property is zero false-accept.** A false reject costs 30
seconds; a false accept ships a defect to Toyota. Every design decision flows
from that.

## 2. Measurement fundamentals [RESEARCH]

**The matrix.** Each pin of each counterpart connector is a test point. A
tester with N points switches any point onto a few shared analogue buses:
FORCE+/FORCE− carry test current, SENSE+/SENSE− take a high-impedance Kelvin
voltage reading. With only 2 buses, switch on-resistance (4–8 Ω CMOS mux,
100–200 mΩ reed relay) sits in series with the measurement and destroys a 1 Ω
continuity threshold. **With 4 buses no current flows in the sense path, so Ron
cancels entirely. Use 4 buses** — the single most important electrical decision
for a resistance-grading tester.

**Measurement engine (industrial class):** programmable current source (1 mA
continuity, 10–100 mA or 1 A for power circuits) plus a 24-bit differential ADC
(ADS1220 / ADS131M) covering ~0.05 Ω to 20 MΩ.

**Note the deliberate divergence:** the POC below does *not* use Kelvin or a
current source. It is continuity-only by choice, and resistance grading is the
documented upgrade path. Don't confuse the two tiers when answering.

## 3. The POC architecture as built out on paper

**One node = one 64-pin card:**

- 1 × **ESP32-S3 dev board** — MCU + radio + its own 3.3 V from USB-C 5 V
- 4 × **MCP23017** I²C GPIO expanders = 64 individually switchable test pins,
  each with a built-in pull-up (~100 kΩ)
- 64 × **470 Ω** series resistor, one per pin
- 64 × **BAT54S** dual Schottky, clamping each pin to the rails
- 64 × **WS2812B** (strip), one RGB per pin, chained off a single GPIO
- 4.7 kΩ I²C pull-ups, AMS1117-3.3, ~8 × 100 nF + bulk decoupling, PTC fuse,
  TVS (SMBJ5.0A) on the rail, screw terminals / headers, protoboard or PCB

**Two cards for the POC.** One is master: talks to the laptop over
**telnet-serial**, and to the second card over **ESP-NOW**. Each card owns a
64-pin address range. **No screen on the hardware** — the laptop/MacBook draws
the connection map. Power: **USB-C 5 V chargers**. Everything runs at **3.3 V**
(ESP32-S3 and MCP23017 are both 3.3 V parts, so no level shifting).

### The one mandatory wire: the GND/REF pigtail

**All cards must share a single physical GND/REF pigtail.** This is the key
architectural refinement of the whole design. **Radio carries commands and
results; it cannot carry measurement current.** Continuity needs a physical
return path. Forget this wire and the machine simply does not work across
cards. [DESIGN — load-bearing]

### Test method: drive-one / read-all

- **Idle:** every pin = input with pull-up → all read HIGH.
- **Drive:** set one pin to output LOW.
- **Read all** (both cards): any pin pulled LOW is connected to the driven pin
  through a harness wire. That is the measured net.
- **Compare to the master netlist:** missing pin = **open** (red LED);
  unexpected low pin = **short** (amber); exact match = **pass** (green).
  Repeat per net → one OK/NG verdict.

### Why driving the harness from the MCU is safe

The current is set by the **pull-up resistor, not the MCU**. An MCP23017
internal pull-up is ~100 kΩ, so at 3.3 V that is **~33 µA per connected pin**.
The MCU can source/sink ~25 mA — a thousandth is in use. Even a 60-pin net
pulls only ~2 mA. There is no "current injection" risk. This misconception,
once cleared, makes the design *simpler*, not harder.

### Protection philosophy — deliberately minimal

For a **dead, ≤5 V harness**, three cheap things and no isolation:
1. **470 Ω series resistor** per pin — limits current if a pin meets an
   unexpected voltage.
2. **BAT54S Schottky clamp** per pin — shunts over/under-voltage to the rails
   before it reaches the chip.
3. **PTC fuse + TVS** on the supply rail — catches a gross fault.

**Opto-isolation was explicitly removed** once it was established the harness
is always de-energized at test — true for a normal ECT station. Adding it would
be over-engineering; the clamps do the job for a fraction of the cost. The
conscious trade-off: a harness that is accidentally *live* (charged capacitor,
battery still connected) could damage the ESP32. If that assumption ever
changes, isolation comes back.

## 4. POC vs industrial-grade BOM

| Qty | Part | Build | Purpose |
|---|---|---|---|
| 1 | ESP32-S3 dev board | Both | MCU + wireless |
| 4 | MCP23017 | Both | 64 GPIO with pull-ups |
| 64 | 470 Ω resistor | Both | per-pin series protection |
| 64 | BAT54S | Both | per-pin rail clamp |
| 64 | WS2812B strip | Both | per-pin RGB indication |
| 1–2 | PTC resettable fuse | Both | rail overcurrent |
| 1 | TVS SMBJ5.0A | Both | rail transient clamp |
| ~8 | 100 nF + bulk | Both | decoupling |
| 1 | AMS1117-3.3 | Both | regulation |
| 2 | 4.7 kΩ | Both | I²C pull-ups |
| — | screw terminals, protoboard/PCB | Both | harness interface |
| 1 | **GND/REF pigtail** | Both | **mandatory return path** |
| 1 | ADS1220 | Industrial | current source + 24-bit ADC (resistance) |
| 4 | CD74HC4067 | Industrial | 64:1 analog mux to reach any pin |
| 2–3 | precision cal resistors | Industrial | meter self-calibration |
| 1 | STM32G4 | Industrial | deterministic safety core (ESP32 → radio only) |
| 1 | DS28E07 | Industrial | node ID + calibration store |
| 1 | 24 V→5 V/3.3 V DIN SMPS | Industrial | field power (POC runs on USB) |
| 1 | tower light + 7" HMI | Industrial | operator indication |
| 1 | backplane rail + connector | Industrial | power + REF, snap-in nodes |
| 1 | IP enclosure, PCBA, conformal coat | Industrial | hardening |

All POC parts are available in Pakistani markets (Hall Road Lahore, Saddar
Karachi, Daraz.pk).

## 5. Bring-up and the acceptance test

Per board: power from USB 5 V, decoupling cap beside every chip. Four MCP23017s
on a shared I²C bus, **each with a unique 3-bit address** so they don't
collide. Each of the 64 GPIO lines through its 470 Ω to a test pin on a screw
terminal. 64 WS2812s chained off one GPIO. Firmware: on start every pin is
input-with-pull-up; master card talks telnet-serial to the laptop and ESP-NOW
to the second card; each board owns a 64-pin range. Then join the boards with
the **single REF/GND pigtail**, land the harness per the address map, and scan.

**Prove it before trusting it:** run a known-good harness (all green), then a
harness with **one wire deliberately cut and two deliberately bridged**, and
confirm the machine flags the open and the short **every single time**. That
check is what makes it a tester rather than a demo.

## 6. Scope boundaries

- **Continuity only** at this stage. Resistance / analog grading is explicitly
  a roadmap item, not in scope.
- Wireless, battery and hi-pot were all deferred in the earlier
  project-selection review, which recommended a **wired single-board PoC first**
  with a fixed point count against one representative harness, validated
  against a golden sample. The later design went modular+wireless anyway; if
  schedule pressure appears, the wired single-board fallback is the documented
  de-scope.
- **The win is correlation:** prove the board passes/fails a real Yaris harness
  the same way the current DMI-10 / OMI flow does. That is what earns budget
  for the full build.

## 7. Open questions — these gate matrix sizing

- [UNKNOWN] **Total test-point count** across the harnesses in scope. Flagged
  twice as a gating decision; still open. Nothing about card count or backplane
  can be committed until this is closed.
- [UNKNOWN] **Is hi-pot / insulation resistance in scope?** Changes the entire
  electrical design (HV switching, isolation, safety interlocks).
- [UNKNOWN] Whether the two POC cards were ever built or tested.
- [UNKNOWN] Takt time and harness changeover time at the existing OMI station.
- See `fvi-machine.md` for the **OMI-10 nameplate** data request, also open.
