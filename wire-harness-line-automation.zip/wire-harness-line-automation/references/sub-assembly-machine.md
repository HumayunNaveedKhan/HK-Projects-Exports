# PC-Guided Sub-Assembly Machine

Guided terminal-insertion station. The operator inserts terminated wires into
connector cavities; the machine tells them which cavity, verifies the
insertion, and logs it against the job card.

Status: **designed to a Phase-1 BOM, not built.** Research and architecture
complete as of 25 Aug 2026.

---

## 1. What the existing plant machine is

The bench label reads **"PC GUIDED SUB-ASSY MACHINE"** [VERIFIED from photo].
That is the correct industry name for this class. Other names in use
[RESEARCH]: Sub-Assy Navigation System / Assembly Navigation (Yazaki, Sumitomo
internal), Guided Assembly / Build-Aid Tester (Cirris, CAMI), Terminal
Insertion Guiding Apparatus (patent literature), Wiring Harness Poka-Yoke
Machine (Indian SPM builders), Operator Guidance Platform (Arkite, LightGuide).

The screen decode and the six defect modes are in SKILL.md — they are shared
facts, not machine-specific.

**The existing machine is Family B** (continuity-verified), proven by "Dotsu
NG" on the defect board. [VERIFIED]

### Why the operation resists automation [RESEARCH — CAMI white paper]

Inserting a terminated wire into a cavity depends on human vision and finger
dexterity in a way no cost-effective machine matches. Every serious system
**assists the human**. The three goals: reduce the abstraction level of pin
location, minimise physical motion to insert, give positive feedback that the
insertion is complete and correct. Four perceptual burdens are removed:
identifying the pinned wire, looking its code up in a build list, finding the
cavity in a crowded housing, confirming insertion. Field data: **20–50%
productivity improvement with error rates near zero**.

---

## 2. The four architecture families [RESEARCH]

**Family A — cavity illumination.** A super-bright LED drives a plastic optical
fibre terminating *inside* each cavity, so the target cavity glows. The
inserted terminal physically blocks the light — insertion confirmation is free.
All unpopulated cavities can be flashed at once to guide seal-plug insertion.
Pro: eyes stay on the work. Con: one fibre-loaded fixture per connector P/N,
and that library is the dominant cost. Reference: CAMI "Light Director".

**Family B — continuity / second-side sensing. ← the plant's machine.** The
connector sits in a receiver jig with a **spring probe (pogo pin) at the back of
every cavity**. The controller drives a signal down the wire and watches which
probe sees it. Two things fall out free: **wire identification by touch** (touch
a wire, the system knows the circuit, no barcode) and **insertion verification**
(continuity at the expected probe = OK; at a different probe = wrong cavity;
nowhere = not seated = "Dotsu NG").

Sumitomo **US 6,993,833** ("Apparatus for manufacturing sub-harness") describes
exactly this loop: terminal contacts probe → continuity checked against the
second connector → NG blocks advancing and fires lamp+buzzer → OK advances the
guide → completion button counts the unit and releases it. Earlier **US
5,477,606** names the weakness: rigid per-connector receptors are costly, bulky
and slow to change over. **That is the design problem to solve.**

**Family C — screen + pick-to-light.** Monitor shows the connector graphic with
the target cavity highlighted; bins and rack slots lamped; operator confirms
with a pedal. Cheap, universal, no fixture — but guidance only, not
verification. A determined mistake gets through.

**Family D — projected AR.** Overhead high-lumen projector paints 1:1 CAD
geometry on the board; a 3D sensor validates and refuses to advance
("no-faults-forward"). LightGuide and Arkite. Excellent for the **lay-out
board** stage; poor at resolving a 2.2 mm cavity.

**Decision [DESIGN]:** B as the backbone, A layered on for high-mix connectors,
C as the fallback for connectors too odd to fixture, D deferred to the lay-out
board as a separate project. Design the controller so all four modes are
supported by one software and one step-file format.

---

## 3. Market and cost [RESEARCH]

| Vendor | Product | Family | Note |
|---|---|---|---|
| Cirris (US) | 8100 / CH2 + Easy-Wire | B (+A) | 256 pts base, expandable to 100,000. **Smart-Lights** adapters carry an ID chip so a fixture auto-identifies in any port. |
| CAMI Research (US) | CableEye + AutoBuild + Light Director | A | Most transparent published cost model in the industry. |
| Komax (CH) | Zeta | Full automation | Vision-guided Cartesian insertion. Different budget universe. |
| Schleuniger / Metzner | Wire processing | — | Upstream cut/strip/crimp. |
| LightGuide (US) / Arkite (BE) | Projected AR | D | Arkite explicitly markets harness routing by 1:1 CAD projection. |
| Purvi Automation and Pune/Chennai SPM builders | "Wiring Harness Poka-Yoke Machine" | B/C | **The realistic commercial benchmark.** |

**CAMI's published worked example** [RESEARCH, the one hard cost anchor]:
256-point platform + AutoBuild + voice ≈ **USD 3,400** one-time, 5-year
depreciation ≈ **USD 75/month per station**. **≈ USD 450 per Light Director
fixture board.** At 25–40% labour saving, two fixtures (USD 900) pay back in
**14–23 working days** or **56–90 assemblies**.

Directional planning figures [RESEARCH — not quotes]:

| Class | Indicative capital/station |
|---|---|
| Screen-only (C), self-built | 800 – 1,500 |
| Continuity (B), self-built, 256 pts | 2,500 – 5,000 + jigs |
| Continuity, imported (Cirris-class) | 6,000 – 15,000 + jigs |
| Connector-specific jig | 250 – 600 each |
| Projected AR station | 30,000 – 80,000 |
| Full automated insertion cell | 250,000+ |

**The cost fact that decides the project:** a Yaris + Hyundai mix can need
**60–150 distinct connector jigs**. At USD 400 each that is USD 24,000–60,000 —
several times the controller cost. [UNKNOWN: the actual connector count. The
Pareto has never been done. It is the highest-value zero-cost action available.]

**ROI buckets, in the order management values them:** escaped-defect
elimination (a wrong-cavity terminal reaching the OEM is a containment event —
this is the number that funds the project) → rework/scrap at the checker
station → labour and cycle time (20–50% on the insertion operation) → training
and flexibility → traceability per unit against the job card.

---

## 4. Settled architecture [DESIGN]

### Design principles
1. **Split real-time from presentation.** The compute owns database, Excel
   import, graphics, MES link. Timing-critical loops never depend on the UI.
2. **Job programs are data, not firmware.**
3. **Fixtures self-identify.** Every jig carries a DS28E07. Plug it anywhere;
   the system knows what it is. This is what Cirris's Smart-Lights sell and what
   kills the US 5,477,606 changeover problem.
4. **Fail closed.** NG physically blocks advancement; clearing needs supervisor
   authorisation, not a click-through.
5. **Degrade gracefully.** If continuity hardware is unavailable, fall back to
   Family C guidance and flag those units "guided but unverified" in the log.

### The topology, after two rounds of simplification

**Final [DESIGN]: Raspberry Pi CM5 (eMMC) on a carrier, driving a 7" DSI
touchscreen, owning the I/O directly.** No separate mini-PC, no per-jig MCU, no
RS-485, no phone.

```
Pi CM5 ──SPI (4) ─────────────┐
       ──mux addr (4) ────────┤
       ──board enable (5) ────┼── ~19-conductor shared ribbon, daisy-chained
       ──1-Wire (1) ──────────┤
       ──drive/sense bus (2) ─┤
       ──24V/5V/GND (3) ──────┘
          │      │      │      │      │
        Jig A  Jig B  Jig C  Jig D  Jig E   ← dumb boards, no MCU
```

**Why the jig board can be dumb:** TLC5947 daisy-chains natively (SIN→SOUT
across all boards, one SPI write updates every cavity LED); CD74HC4067 muxes
share address lines and need only one enable each; DS28E07 is 1-Wire, so every
chip's unique 64-bit ROM ID lets all five sit on **one wire** with no addressing
hardware. The jig board is four muxes, two LED drivers, one ID chip, TVS and
resistors — **≈ $35**.

**Why the Pi and not the ESP32-S3 or a mini-PC:** everything above the scan
loop is a Linux problem. The Excel→JSON compiler runs locally (`openpyxl`),
SQLite holds programs and logs, a real UI toolkit draws connector graphics as
SVG, the DSI touchscreen is a single ribbon, Ethernet/Wi-Fi/USB scanner are
native, and you debug over SSH instead of a reflash cycle. Pi 5 has 5 SPI buses
and 28 GPIO — sufficient. **Use CM5, not a consumer Pi 5:** availability
commitment into the 2030s, eMMC included, and a carrier board you control when
an audit asks about the obsolescence plan.

**The three real Pi problems, with fixes:**
1. **SD corruption on power loss** — read-only rootfs with overlayfs (kills
   ~95% of it), `/data` on a separate partition or eMMC, small DC UPS on the
   24 V rail (~$45) for a clean shutdown signal. +$70–110. Not optional.
2. **Boot time** ~22 s vs ~2 s. Irrelevant at shift start; the UPS prevents the
   mid-shift blip that would make it matter.
3. **Timing determinism** — a 20 ms scan budget is soft real-time and Linux is
   fine with a `SCHED_FIFO` thread. **The one exception is Phase-3 pull-force
   capture** at 320 SPS where a 15 ms scheduler stall drops five samples and can
   miss the peak. Fix in order: let the NAU7802 free-run with DRDY on a GPIO
   interrupt (the ADC does the timing, not Linux) → `isolcpus` one core → only
   if still insufficient, an RP2040 on the load-cell node ($8) to buffer the
   curve. **Measure before assuming you need the co-processor.**

### Continuity scanning engine [DESIGN]

One-hot drive + 16:1 mux sense. Drive one point at a time to 5 V through a
1–10 kΩ series resistor (<10 mA), scan all other points, record which read
high. Result is a measured netlist; compare against the *expected* netlist for
the current step.

Four things that will bite if ignored:
- **Sneak paths through splices.** Sub-harnesses are full of joints; one drive
  point can legitimately light five sense points. Compare against the expected
  **net set**, never a 1:1 map.
- **Resistance threshold, not presence.** A terminal touching the pogo pin but
  not locked still shows continuity. Measure resistance; set a low threshold
  (a few ohms) so marginal contact reads NG.
- **Speed.** 256×256 at 20 µs settle is ~1.3 s naively. Scan only the points
  relevant to the current step → under 20 ms. Save the full sweep for
  end-of-harness verification.
- **ESD.** Every test point is a wire an operator is holding. TVS array per
  channel, series resistor before the mux, bonded bench, wrist straps.

Scale: build drive/sense as a 32-channel module and stack. A failed module
costs $20, not $500.

### Cavity indication [DESIGN]

A WS2812 will not fit behind a 2.2 mm or 0.64 mm cavity. Two workable methods:
- **Fibre light pipe (CAMI approach).** 0.5–0.75 mm PMMA POF (Mitsubishi Eska
  SH-2001), one strand per cavity, from a board of 0603 SMD LEDs to the back of
  each cavity. Terminal blocks the light = free optical confirmation,
  independent of the continuity check. **Black-pot between fibres** — crosstalk
  on 2.2 mm pitch is the failure that kills naive designs.
- **Side-fire SMD on a stacked PCB**, viable at ≥2.5 mm pitch, cheaper to build.

Drive with TLC5947 constant current so brightness is stable and patterns are
possible: solid = target cavity, fast flash = wrong insertion, all-flash = seal
plugs required.

### Pull-force sensing — the differentiator [DESIGN]

Commercial systems don't do this well. The plant already does a manual pull
check (there is a pull-check training panel on the defects board), so
instrumenting it is high value.

**Naive:** load cell proves the operator pulled hard enough. Proves effort, not
quality. **Correct — force AND continuity simultaneously:**

```
PASS = peak force ≥ F_threshold  AND  continuity maintained throughout the pull
FAIL = threshold reached but continuity dropped  → terminal backed out (TBO)
FAIL = threshold never reached                   → under-pulled, retry
```

That cannot be defeated by a half-hearted tug, and it directly detects the
locking-lance failure. Hardware: 5–10 kg straight-bar or S-type cell;
**NAU7802** 24-bit I²C at ≥200 SPS (not HX711); capture the full force-vs-time
curve, not just the peak — curve shape catches a "slip then re-grip" that a
peak-only reading passes. Dead-weight calibration per station on a schedule,
due-date stored in the jig's DS28E07, **refuse to run past due** (an automotive
audit will ask).

**F_threshold [UNKNOWN].** It must come from the connector/terminal supplier
spec and be signed off by the customer's engineering — do not invent it. The
standards landscape for orientation only: SAE/USCAR-21 (crimp pull-out, 50–250
mm/min, 100 preferred), LV214 (German OEM equivalent), JASO D616 (Japanese
connector insertion/extraction). Small automotive terminal retention typically
lands in tens of newtons, but the number in the config file is **the customer's
number, per part**. Store it **per connector P/N per cavity** in the job
program, never as a global constant.

### Sensor coverage vs the six defect modes [DESIGN]

| # | Defect | Method | Confidence |
|---|---|---|---|
| 1 | Circuit wire miss | Continuity — expected net absent | High |
| 2 | Wrong wire insertion | Continuity — net at wrong probe | High |
| 3 | Retainer / TPA open | Micro-switch or inductive prox on retainer travel; or go/no-go plunger | Medium — per-connector mechanism |
| 4 | Terminal backout (TBO) | Load cell + continuity-during-pull | High |
| 5 | Accessory missing | Pick-to-light bins with IR beam-break + step gating | Medium — confirms a *pick*, not a *placement* |
| 6 | Male pin bend | Vision at a check pose, or a go/no-go comb gauge | Medium-high, but a separate sub-project |

**Scoping advice given and agreed:** do 1, 2, 4 in v1. Add 3 and 5 in v2. Leave
6 out of the first machine entirely — it is a CV project with its own lighting,
dataset and false-reject tuning, and bolting it on will sink the schedule.

---

## 5. Job programs: Excel in, guidance out [DESIGN]

Three flat sheets — engineers will hand-edit them, so keep them boring.

**`HEADER`:** harness_pn (e.g. YARIS-046d), variant, revision, description,
created_by/date.

**`CONNECTORS`:** ref, connector_pn, cavities, jig_id, orientation,
retainer_check, notes. (e.g. `C1 | ASZLE6-35F | 6 | JIG-0412 | A-up | TRUE`)

**`CIRCUITS`** — one row per wire, the core table: step, circuit_no, from_ref,
from_cav, to_ref, to_cav, gauge, colour, length_mm, terminal_pn, seal_pn,
pull_force_N, accessory, wire_cabin. (e.g. `33 | YQ4 | C1 | D | C2 | 7 | 0.35 |
L | 1512 | ... | 0`)

Optional **`ACCESSORY`** sheet for tubes, tapes, clips and their step positions.

This maps **1:1 onto what the current screen already displays** — deliberate.
Operators should see no change in information, only in reliability.

**The compiler is where the value is.** It must **reject**, not warn, on: a
cavity that doesn't exist in the declared connector; two wires in one cavity; a
connector P/N with no jig in the fixture library; missing `pull_force_N` where
the connector requires a pull check; gauge/terminal mismatch; duplicate or
non-contiguous step numbers; a circuit with only one end defined (unless flagged
as a flying lead).

Compiled step file:

```json
{
  "harness_pn": "YARIS-046d", "revision": 3,
  "hash": "sha256:...", "compiled_utc": "...",
  "connectors": [
    {"ref":"C1","pn":"ASZLE6-35F","jig":"JIG-0412","cavities":6},
    {"ref":"C2","pn":"SSGTSN8-18M-L","jig":"JIG-0876","cavities":18}
  ],
  "steps": [{
    "n": 33, "circuit": "YQ4",
    "wire": {"gauge":0.35,"colour":"L","length_mm":1512,"cabin":0},
    "insert": {"ref":"C1","cav":"D"},
    "expect_net": ["C1.D","C2.7"],
    "max_resistance_ohm": 2.0,
    "pull": {"force_N": 30, "hold_ms": 1000, "monitor_continuity": true}
  }]
}
```

`expect_net` is the list of points that must be electrically common after the
step — **this is what makes splices work**.

**Distribution:** network primary (compiled file pushed, hash validated before
accepting); USB signed `.job` bundle as fallback; MQTT broadcast for fleet
rollout; firmware OTA separate, signed, dual-partition with rollback, staged
one station → one line → plant, never during a shift.

**Sign the compiled job files** (Ed25519 from the engineering workstation's
key). An unsigned Excel anyone can edit and drop on a USB stick is a
change-control finding waiting to happen at audit.

**Traceability record per unit:** job_card, harness_pn, revision, hash,
station_id, operator_id, unit_serial, start/end UTC, per-step
{step_n, insert_time_ms, resistance_mΩ, pull_peak_N, result}, ng_events
[{step_n, code, timestamp, cleared_by}].

**Storage is a non-issue:** a compiled 60-circuit step file is under 100 kB.
The only thing that scales with program count is the **jig library**. A new
program using existing connectors costs nothing; one with two unfamiliar
connectors costs ~$724. That asymmetry is the whole economic story — put it on
one slide.

---

## 6. BOMs [DESIGN — prototype-quantity estimates, USD]

### Full five-jig station (the original, before simplification)
Roll-up ≈ **$4,213** per station, of which $1,530 (36%) is the five jigs.
Station #2 without new jigs ≈ $2,700. Each additional connector ≈ **$362**
($35 board + $252 mechanics + $54 optics). At 60 connectors that is $21,700.
One-time programme tooling ≈ $965 (fibre cleaver+polish kit $120, bench DMM
with mΩ range $180, digital force gauge $320, hot-air/soldering $220, SWD/
ESP-Prog $45, 8-ch logic analyser $80).

### Phase-1 station, as finally scoped: two jigs (A, B), continuity + cavity LEDs + screen. No pull force.

| Block | $ |
|---|---|
| Compute: CM5 4GB/32GB eMMC + carrier | 105 |
| 7" DSI touchscreen | 65 |
| DC UPS / clean shutdown | 45 |
| Controller carrier PCB | 45 |
| Jig boards ×2 (dumb) | 70 |
| Jig mechanics ×2 (baseplate, insert, probes, carrier) | 504 |
| Cavity illumination ×2 | 108 |
| Buttons ×4, foot pedal, andon tower, barcode scanner | 201 |
| Power: 24 V + 12 V PSU, MCB, DIN plate, terminals | 137 |
| Ribbon bus, patch leads, ferrules, labels | 84 |
| ESD: wrist straps, mat, bonding (TVS is in the jig BOM) | 76 |
| Bench mod: jig rail, 2 dowelled positions, task light | 215 |
| Golden sample harness + 50 spare probes + 1 spare jig board | 183 |
| **Phase-1 station** | **≈ 1,700** |

### Jig mechanics, per connector (≈ $252) — the part that doesn't compress
Common 6061-T6 baseplate 120×90×12 mm, dowelled + quick-release ($28); **the
per-P/N machined POM/Delrin insert ($65)**; 32 Mill-Max spring probes (P75-B1
or 0906-series, 100 gf, gold) + receptacles ($27); probe carrier plate, FR4 or
PEEK, drilled to cavity pitch ($35); retainer/TPA check switch — Omron D2F-01L
or PNP inductive prox ($4.50); jig-present sensor ($2); dowels/latch/fasteners
($12); 30 AWG PTFE probe wiring ($8); ~6 h local machining labour ($70).

**Split the baseplate from the insert deliberately.** The baseplate is common
across all jigs; only the insert is per-connector. At 60 connectors you
re-machine a $65 insert, not a $252 jig. **Jig mechanics is 52% of the Phase-1
build and it is not waste — it is the actual problem.** Spring probes at the
right pitch held to ±0.1 mm against a connector body, surviving 100,000
insertions, is genuine precision work.

**Cavity illumination, per jig (≈ $54):** 3 m POF ($3.60), 32 ferrules/bushings
($6.40), SLA LED-to-fibre coupling block holding fibre 0.5 mm off the 0603 LED
($15), black epoxy potting ($4), cleaving/polishing labour ($25).

**Pull-force block (≈ $533, Phase 3, bolts on without touching anything built):**
10 kg cell TAL220B or Zemic L6D-C3 ($14), NAU7802 breakout ($6), load-cell node
PCB ($32), machined hook + swivel ($30), mount with 12 kg hard stop ($40),
**certified class-M1 1/2/5 kg calibration weight set ($85 — not optional)**,
shielded 4-conductor cable ($6), plus the bench force gauge from tooling.

---

## 7. Build phases [DESIGN]

**Phase 0 — gemba and specification (2–3 weeks), before any hardware.** Sit at
station A-2551 with a stopwatch. Time-study seconds per insertion, per
changeover, per NG. Count defect modes actually occurring from four weeks of
checker data — this picks which of the six to solve first and *is* the ROI
baseline. **Inventory and Pareto the connector population.** Pull terminal
retention specs for the top 20. **Confirm the change-control path** — this is a
customer-approved poka-yoke on an automotive line; replacing it needs customer
engineering sign-off and probably a PPAP process-change submission. Find out
now. Deliverable: a URS signed by production, quality and the customer SQE.

**Phase 1 — screen-only prototype (4–6 wk).** Family C, no custom PCB. Validates
the data model, UI and Excel workflow — the parts most likely to be wrong —
before committing hardware. Independently useful.

**Phase 2 — single-jig continuity node (6–8 wk).** Jig board + one jig for the
highest-volume connector. Prove wire-touch identification, cavity LED,
insertion verification, wrong-cavity detection, sub-20 ms scan. Pogo-pin
mechanics will take more revisions than expected. **Gate: 500 consecutive
insertions, zero false rejects, zero false accepts. If you can't hit that, stop.**

**Phase 3 — pull force and full station (6–8 wk).** Load cell, continuity-
during-pull, calibration routine and certificate, pick-to-light bins, andon.

**Phase 4 — pilot on one line (8–12 wk).** Two weeks **shadow mode** — logs but
doesn't block — comparing machine NG calls against checker findings, tuning
thresholds. Then blocking mode. Measure against the Phase 0 baseline. **If the
operators hate it they will defeat it, and no amount of engineering fixes that.**

**Phase 5 — fleet rollout and MES.** Standardise and batch the jig build, plant
program database, central fixture library, calibration due-date tracking. Only
then consider Phase 6: vision for pin-bend and accessory verification.

**Realistic total to a proven pilot station: 6–9 months** with 1 embedded + 1
software + 1 mechanical/fixture engineer and part-time IE support. Anyone
promising three months hasn't built the fixtures yet. **Note: this is a team
estimate; he is solo.**

## 8. Risk register [DESIGN]

| Risk | Severity | Mitigation |
|---|---|---|
| Customer change-control refusal | Critical | Engage the OEM SQE in Phase 0. Shadow mode. Never remove the existing poka-yoke until the new one is approved. |
| Jig library cost exceeds budget | High | Pareto the connectors. Modular baseplate + swappable insert. |
| Pogo-pin wear / false NG | High | Defined replacement interval, gold tips, daily golden-sample self-test. |
| False rejects erode operator trust | High | Shadow mode, tune on real data, fast *logged* escalation path — never a silent override. |
| Load-cell drift | Medium | Scheduled dead-weight calibration, refuse-to-run past due, log every calibration. |
| ESD damage to scan channels | Medium | TVS per channel, series resistors, bench bonding, wrist straps. |
| Key-person dependency | Medium | Document protocol and schema; keep the HAL portable. |
| IP | Medium | Do not reverse-engineer the incumbent vendor's machine. Build from published (largely expired) patent literature and own design. Keep a clean-room record. |

## 9. Patent references [RESEARCH]

- **US 6,993,833** (Sumitomo Wiring Systems) — apparatus for manufacturing
  sub-harness; the continuity-verified guided insertion loop.
- **US 5,477,606** — assembly guiding apparatus for wiring harness
  subassemblies; names the connector-receptor changeover problem.
- **US 6,169,934** (Yazaki) — wire harness manufacturing system, FPS vs OES,
  sub-assy step definition.
- **US 4,849,743** — terminal placement and degree-of-insertion determination.

## 10. Open questions

- [UNKNOWN] Connector Pareto: how many distinct P/Ns cover 80% of insertions.
  **Decides whether this is a $6k or a $22k jig library.**
- [UNKNOWN] `F_threshold` per connector/terminal, from supplier spec + customer
  sign-off.
- [UNKNOWN] Four weeks of checker defect-frequency data (the ROI baseline).
- [UNKNOWN] Takt time the station must hit.
- [UNKNOWN] Customer change-control / PPAP path for modifying an approved
  poka-yoke device.
- [UNKNOWN] Which plant owns the existing machine. The Korangi guided sub-assy
  was described as already running and lowest priority; Yazaki also lists a
  guided sub-assy need. The photographed station is a Toyota Yaris line.
