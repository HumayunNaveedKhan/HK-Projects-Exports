# Fuse Box Vision Inspection Station — Yazaki

Checks a loaded fuse box against a taught golden image and releases a
solenoid-driven quality stamp only on a pass.

Status: **active and the most advanced of the vision work.** Application
delivered as `fusebox_inspector.zip`; a substantial engine rewrite was **in
progress and unreported as of 9 Oct 2026**. Self-imposed deadline: ~2 months
from early Oct, anchored to Friday on-site visits.

---

## 1. What the station does

Two **limit switches** confirm the box is correctly seated → camera photographs
the box → the app inspects it against the golden image for the selected model →
on PASS the operator presses the stamp button and the STM32 fires the solenoid;
on NG the buzzer sounds, the red lamp lights, faults are boxed on screen and
**the stamp stays blocked**.

**Jigs guarantee the correct model is loaded**, so the app checks a fixed model
rather than identifying which model it is looking at.

### Pass criteria
- **every fuse** is in its taught slot with the **same colour** (= rating),
- **no fuse** has appeared where the golden box is empty, and
- the **QC sticker** is present, in position, unskewed, untorn, clean, and its
  **fixed** print matches.

**Colour is the identifying fingerprint. Fuse number printing does not need
OCR reading** — printed numbers are used only as a tie-breaker for close colour
calls. Variable sticker zones (**lot code, QR**) are masked out.

### Verdict codes
| Code | Meaning |
|---|---|
| `MISSING` | taught slot is empty |
| `WRONG` | fuse present but wrong colour, e.g. expected 10A red, found 7.5A brown |
| `MISPLACED` | a part where the golden box is empty |
| `STICKER` | missing / misplaced / skewed / torn or folded / dirty / print mismatch |
| `ALIGN` | box not recognised — badly seated, wrong model, camera blocked |

### Known model
**`model 1-y33`: 33 fuses total** — 16 × 10A, 3 × 7.5A, 3 large orange, 2 large
red, 2 large orange. [VERIFIED — supplied by the plant] Colour + position +
count is the core pass/fail logic.

## 2. Hardware

**Camera: Hikrobot MV-CH120-20GC** (GigE / PoE) with a **12 mm 1/1.8" lens.**
[VERIFIED — the plant's existing camera] **There is a lens–sensor mismatch:**
the 1/1.8" lens does not cover the 1.1" sensor, so either crop the ROI to the
clean centre of the image or fit a matching 1.1" lens. Do not ignore this —
it causes vignetting and edge distortion that break alignment.

**Control board: STM32F411 Black Pill**, STM32duino, USB-CDC serial to the PC.
IO count — three is not enough, plan for at least six:
- **Inputs:** LS1 and LS2 read **separately** (so "box not fully seated" can be
  shown), stamp push button.
- **Outputs:** stamp relay (solenoid valve), buzzer, green/red lamp or tower.
- 24 V opto-isolated inputs; **flyback diode or RC snubber on the solenoid**;
  drive relays with the 3.3 V **INPUT-float / OUTPUT-LOW** technique.

**Development:** MacBook Pro, against saved images via a `FolderCamera`
backend. A live Hikrobot on the Mac is possible — the camera speaks standard
GigE Vision so the open-source **Aravis** library (`brew install aravis`) can
usually grab frames, since Hikrobot's own MVS software lacks solid macOS
support. Fine for experiments; **production stays on the official MVS SDK on
Windows.**

### Camera choice: MX BRIO vs Hikrobot [VERIFIED reasoning]
The MX BRIO *can* do this and is **great for prototyping now** — 4K across a
~300 mm box is ~0.08 mm/px, far more than a fuse needs, and it is plug-and-play
on the Mac. But for production the Hikrobot wins, and **not on resolution**:
- The Hikrobot sends the **raw, unprocessed image**, so the same box gives the
  same colours every time. This is the whole argument.
- Exposure, gain and white balance are saved in the camera's **User Set** and
  survive power cycles. Brio settings locked in Logi Tune reset after a
  reconnect, reboot or OS update.
- Interchangeable C-mount lenses avoid the Brio's wide-angle distortion, which
  bends straight lines near the edges and shows the box sides at an angle,
  making alignment and the sticker geometry check harder.
- PoE, long Ethernet, built for continuous industrial use.

**The hardest colour call is 10A red vs 7.5A brown** — that is why colour drift
means false NGs. **Re-teach golden images on whichever camera goes on the line;
golden and live must always come from the same camera.**

## 3. Station cycle and the interlock

```
SEAT:1 → wait 300 ms → capture → inspect
  PASS → RES:PASS, green lamp → operator presses STAMP
       → board fires solenoid → STAMPED
  NG   → RES:NG, red lamp, buzzer, faults boxed on screen
       → operator fixes the box → presses STAMP → app re-inspects
         (no stamp until PASS)
SEAT:0 (box removed) → everything cleared
```

**Serial protocol — plain ASCII lines:**

| Direction | Messages |
|---|---|
| STM32 → PC | `SEAT:1` / `SEAT:0`, `BTN:STAMP`, `STAMPED`, `HB` (heartbeat) |
| PC → STM32 | `RES:PASS` / `RES:NG`, `BUZ:1` / `BUZ:0`, `LAMP:G` / `LAMP:R` |

**The interlock lives in the STM32, not the PC.** The board fires the solenoid
only if: it received `RES:PASS` for the *current* seating, **and** both limit
switches are still closed, **and** the box has not already been stamped, **and**
the PC is connected. The PASS token clears the moment either switch opens. A PC
crash, a stray serial line, or an operator swapping boxes then cannot stamp a
bad box. **Do not move this logic into the PC.** (Physical safety: keep fingers
clear of the stamp cylinder; a guard may be needed.)

## 4. Inspection algorithm

1. **Align** the live image to the golden: **SIFT features with RANSAC**, then
   fine **ECC** refinement. This absorbs the small seating shift the fixture
   allows. Alignment mode `affine` for the fixture (`homography` only for
   hand-held demo photos).
2. **Colour-correct** against the taught grey reference patch, if present.
3. **Per slot:** find fuse body pixels (coloured, or bright for white/clear
   fuses); the window may slide ±1 mm. Take the **median colour in Lab** and
   compare with the golden using **CIEDE2000**. Too few body pixels → `MISSING`.
   **ΔE > limit (default 10)** → `WRONG`.
4. **New parts:** coloured, white, or simply-brighter-than-housing pixels where
   the golden image is dark or differently coloured → `MISPLACED`.
5. **Sticker:** find the white label; compare position, angle, size, and shape
   (**rectangularity and solidity** catch torn or folded corners); compare the
   fixed print against the golden with **SSIM** and look for marks with a
   difference map. Lot code and QR masked.

**Measured on the demo set** [VERIFIED on the three sample photos]:
good fuses stay within **ΔE ≤ 4.6** of golden; a **7.5A brown in a 10A red slot
measures ΔE 18**. The default limit of 10 sits between. **Re-check this margin
on real station images and tune per model in teach mode.**

## 5. Application: `fusebox_inspector`

Python + **PySide6** + OpenCV.

```
app.py                     start here
config.json                station settings
fbi/engine.py              inspection engine (align, fuse colour, new parts, sticker)
fbi/colour.py              Lab / CIEDE2000, rating-name suggestions
fbi/camera.py              FolderCamera (Mac) and HikCamera (MVS SDK, software trigger)
fbi/link.py                STM32 serial protocol + simulator
fbi/storage.py             models, config, result logs
fbi/gui/operator.py        operator screen and station state machine
fbi/gui/teach.py           teach mode
firmware/fusebox_station/  STM32F411 Black Pill firmware (STM32duino)
tools/                     demo builder, engine self-test, GUI smoke test
samples/photos/            the three phone photos used for the demo models
```

**Quick start on the Mac, no camera and no board:**
```bash
cd fusebox_inspector
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python tools/make_demo.py    # 3 demo models from the sample photos + test images
python tools/selftest.py     # every test image through the engine -> samples/out/
python app.py                # operator screen with the on-screen simulator
```
Select **DEMO-MODEL-2**, **F5** seats a box, **F7** is the stamp button, **F6**
removes the box. `tools/gui_smoketest.py` runs a full headless station cycle
(NG, PASS, stamp, re-check). Teach-mode password: **1234** — change it.

**Station PC (Windows) setup:**
1. Install **Hikrobot MVS** (includes SDK and Python samples), Python 3.11,
   `pip install -r requirements.txt`.
2. Camera on its **own network card**: PC `192.168.10.1/24`, camera
   `192.168.10.2` (set permanently with MVS IP Configurator). **Jumbo frames
   9000** on that card; allow it through the firewall.
3. In MVS: **pixel format BayerRG8**; **exposure, gain and white balance all
   manual, every auto OFF**; set the ROI to the clean centre if the lens
   vignettes; **save to User Set 1**. The app loads User Set 1 at start.
4. `config.json`: `"camera": {"type":"hik","hik_serial":"","hik_user_set":1}`,
   `"serial": {"port":"COM5"}` (the Black Pill's USB serial port).
5. Check colour once — a red 10A fuse must look red. If red and blue are
   swapped, set `"bayer_swap_rb": true`.
6. `python app.py --fullscreen`

**config.json keys:** `camera.type` (`folder` | `hik`), `camera.folder`,
`serial.port` (`SIM` for the on-screen simulator), `station.seat_settle_ms`
(300), `station.buzzer_ms` (2000), `station.stamp_button_rechecks_ng` (true),
`storage.save_raw` (`all` | `ng` | `none`, default `ng`),
`admin_password_sha256` (sha256 of "1234" by default —
`python -c "import hashlib;print(hashlib.sha256(b'NEW').hexdigest())"`).

## 6. Teach mode

1. **Golden image** — seat a known-good box, *Capture from camera*.
2. **Regions** — *Auto-detect coloured fuses* marks every coloured fuse; add
   **white/clear** fuses (25A, clear cartridges) **by hand**. Draw the
   **sticker area** slightly larger than the label, then **sticker masks** over
   the lot code and QR. Optional but recommended: a **grey reference patch**
   over a fixed grey/white card in the enclosure — every image is
   colour-corrected against it. *Select/move* to drag boxes, Del deletes.
3. **Ratings** — fuses are grouped by colour; rename each group to its rating
   (10A, 7.5A…). Misgrouped fuse → select it, select the right row, *Set
   selected fuses to row*.
4. **Tolerances** — enter the real **sticker width in mm** (measure it); this
   calibrates mm-per-pixel so all tolerances work in mm. Keep alignment
   **affine** for the fixture.
5. **Test** — pull one fuse, swap one 10A for a 7.5A, run *Test: camera*. Both
   faults must be found. Then **SAVE MODEL**. Every save keeps a backup of the
   previous version in `recipes/_backup/`.

## 7. Results and traceability

`results/YYYY-MM-DD/` holds `results.csv` (time, model, PASS/NG, faults,
timing), `stamps.csv` (every stamp), an annotated `.jpg` of every box, and the
raw `.png` of every NG box. **Keep raw NG images** — they are what the colour
limits get tuned on.

## 8. In-flight work as of 9 Oct 2026 [status unconfirmed]

The engine was being rewritten after a report that it was "inspecting wrongly".
The rewrite covers: auto-detecting box boundaries; improved fuse-blob detection
(merging blobs split by white printing; handling warm-toned and shadowed fuses
like 7.5A brown via **Lab-space chroma + tint thresholds**); white-balancing on
neutral regions per photo; robust **per-slot local re-alignment** by template
matching to correct seating and parallax shift; **size-based classification**
into blade / big-single / big-triple fuse classes; a **colour-calibration step
that maps live-image colours into golden-image colour space** using the box's
own fuses, label and housing as calibration points (critical because lighting
differs significantly between the sample photos); and printed-number similarity
as a tie-breaker. Checks are constrained to **within the box boundary**.

**This work was not reported back.** Before building on it, ask what landed.

## 9. Known limits of the delivered version

- Demo models come from **hand-held phone photos** (homography alignment,
  uneven light). Real models must be taught from the station camera inside the
  enclosure. **Consistent enclosure lighting is what makes the comparison
  reliable.**
- White and clear fuses (25A, clear cartridges) must be added by hand in teach
  mode.
- **The STM32 firmware has not been compiled or run on hardware.**

## 10. Open questions

- [UNKNOWN] Did the engine rewrite land, and did it fix the mis-inspection?
- [UNKNOWN] Has the camera and lighting enclosure been built and mounted?
- [UNKNOWN] Has the STM32 firmware been compiled / flashed / bench-tested?
- [UNKNOWN] Real-station ΔE margins per model (the demo-set numbers are from
  phone photos and will move).
- [UNKNOWN] Lens decision: crop the ROI or buy a 1.1" lens.
- [UNKNOWN] How many fuse-box models the station must eventually hold.
