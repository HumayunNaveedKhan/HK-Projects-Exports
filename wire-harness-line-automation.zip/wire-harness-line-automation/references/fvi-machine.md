# FVI — Final Visual Inspection Machine, Korangi

Autonomous visual inspection of completed wire harnesses, **after ECT**, on a
**separate dedicated table** (not the assembly lay-out board).

Status: **gated.** One-page A4 brief issued to management and the floor
(27 Aug 2026). **Phase 0 (image collection, ~USD 150) has not been passed and
nothing beyond it is approved.** Separately, FVI was explicitly advised
against as a solo pursuit — it is ~90:10 CV-to-embedded, the wrong tool for a
one-person department, and an 8–12 month slog.

---

## 1. Scope boundary [DESIGN — agreed and defensible]

Because **ECT has already proven continuity, isolation, mis-wire and contact
resistance**, FVI collapses to **pure workmanship**. No electrical redundancy.
That is a clean boundary for a customer audit.

**In scope:** connector orientation, clip/clamp presence, tape wrap, label OCR,
protector positioning, and similar workmanship checks.

**Out of scope:** **terminal back-out (TBO)** and all electrical faults. TBO
belongs to the sub-assembly machine's pull-force check and to ECT. *If we try
to make FVI catch TBO we will spend most of the budget on the one thing it is
worst at.* TPA and NP-lock seating are borderline — each needs a dedicated
close-up view per connector, which is expensive per checkpoint. Scope those in
Phase 2 only for the connectors the reject data actually implicates.

## 2. Two architecture decisions, settled by direct question [VERIFIED answers]

- **Where:** a **separate dedicated FVI board/table**, not the lay-out board.
- **Relative to ECT:** **after** ECT.

**What that combination buys:** we own the fixture. On a lay-out board we would
be stuck with whatever geometry the assembly jigs impose; on our own table we
design the geometry around the optics instead of the other way round. That is
the difference between a project that works and one that doesn't.

**What it costs:** the harness must be lifted off the lay-out board and placed
into our fixture. **That handling time is the single biggest risk in the whole
project** — the Phase 1 hard gate is "harness loads in under 40 s".

## 3. Architecture [DESIGN]

**Rejected first proposal:** many fixed camera pods — two 20 MP wide cameras at
~$800 each, six 5 MP pods at ~$650 each with lens, bar light and controller,
IPC + Jetson Orin NX ~$1,800. **≈ USD 9k–12k** hardware, plus roughly the same
again in local hood and nest-plate fabrication. Judged too expensive.

**Adopted:** a **single camera head traveling on a belt rail** above the table,
**stopping at each checkpoint** instead of many fixed cameras. Phase 1 hardware
drops to **≈ USD 925**. Upgrade path: if one specific checkpoint proves
marginal, swap *that single position* to an industrial global-shutter camera
(~USD 450) rather than buying ten up front.

**Why not imported:** a European or Japanese turnkey FVI for this harness runs
**USD 60,000–120,000**, and no vendor sells one that handles a full 4 m harness
off the shelf.

**Two-tier software:** classical CV (rule-based OpenCV, auditable pass/fail
logic) first; a DL tier later for **tape wrap and half-fit**, which classical
methods handle poorly.

**Capture and inference are not the bottleneck** — in the fixed-pod design all
pods fire simultaneously, capture is under a second and inference is 20–50 ms
per ROI, decision inside three seconds. With the traveling head, **rail travel
and stop settling become the cycle-time driver instead.**

**Reuse from the sub-assembly machine:** **DS28E07 on each quick-change nest
plate** for model identification, and the same **Pi-based HMI pattern** for the
operator screen.

**Lighting warning — the project-killer.** Fluorescent tubes plus daylight
through translucent roof panels. Ambient light will destroy repeatability.
Every checkpoint needs a shroud, or strobed illumination with a matched
bandpass filter on the lens. Cheap designed in, expensive retrofitted.

## 4. Phasing — first model live in ~22 weeks [DESIGN]

| Phase | Weeks | Work | Output / gate |
|---|---|---|---|
| 0. Defect & image study | W1–3 | Pull 6 months of reject data. Rig one camera + light over a table, photograph every OK and NG harness. **No inspection logic.** **USD 150.** | Defect Pareto + image set. **Go / no-go for everything else.** |
| 1. Table, hood, rail | W3–7 | Fabricate table, matt-black hood, nest layout, quick-change plate, belt rail. Parallel with Phase 0. | **Harness loads in under 40 s. Hard gate.** |
| 2. Camera and light setup | W7–10 | Mount head, set and lock focus, build light bars, calibrate rail positions. | Repeatable image at every checkpoint. |
| 3. Software (rule-based) | W10–15 | OpenCV only, no AI. First 6–10 checkpoints. HMI, logging, Andon. | Working machine, auditable logic. |
| 4. Shadow run | W15–19 | Runs alongside manual inspection, advisory only. Tune out false rejects. | **False reject below 1%.** Manual still the gate. |
| 5. MSA and handover | W19–22 | Gauge R&R vs manual, golden-sample daily check, operator training, SOP. | FVI becomes the gate for model 1. |
| 6. Extension | +8 wk | Remaining checkpoints, DL tier for tape wrap and half-fit, models 2 and 3. | Full coverage, multi-model. |

**Phase 0 is the single highest-value step and costs almost nothing.** Without
a real dataset we can neither train the DL tier nor prove the classical tier's
false-reject rate to anyone — a customer auditor included. **Nothing else is
approved until that data says the machine is worth building.**

## 5. The OMI-10 baseline — still unanswered

Visible on the floor: a unit marked **OMI-10**, beige benchtop, red 7-segment
display, rotary selector, indicator lamp and momentary button, **two units
stacked at the lay-out board**. (A **DMI-10** also appears in plant photos at
the assembly board.) **No public datasheet exists** — searched and not found.

**Read the nameplate and confirm** [all UNKNOWN]: total test points, test
voltage and current, insulation-resistance range, contact-resistance range,
cycle time per harness, output/interface, manufacturer and year. This is the
baseline the new ECT and FVI must be measured against.

## 6. The three data requests to the floor — all still open

1. **Reject Pareto** — the top five workmanship defects the line and the
   Toyota/Hyundai customers actually see at final inspection. **This sizes the
   pods and draws the nest layout. Nothing can be committed without it.**
2. **Takt time** the FVI station has to hit.
3. **Retained NG samples** — physical defective harnesses kept for imaging.

## 7. Open questions

- [UNKNOWN] All three floor data requests above.
- [UNKNOWN] OMI-10 nameplate specifications.
- [UNKNOWN] Whether Phase 0 has started, and whether the ~$150 was approved.
- [UNKNOWN] Harness model(s) in scope beyond "model 1".
- **Standing judgement:** FVI, ergonomics scoring and the head-cam co-pilot
  were all explicitly ruled out as solo pursuits because of their CV load.
  Revisit FVI only with help, or after the crimp and fuse-box work has built CV
  capability and credibility.
