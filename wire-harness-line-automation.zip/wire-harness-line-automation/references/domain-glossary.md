# Domain Glossary and Plant Context

Shared vocabulary across the six machines. If a term in a new chat appears
here, it is probably about this programme.

---

## People and organisations

| Name | Role |
|---|---|
| **Humayun Khan** | Deputy Manager R&D, Thal Engineering (from Aug 2026). The entire R&D function. `humayun.khan@thalengg.com`. Also Co-Founder of Haptronica and RobAutoStem (NIC Karachi Cohort 12; BIC NEDUET). Formerly Team Lead at HHRCM Lab, NCRA-NED UET (~6 yrs under Prof. Dr. Riaz Uddin) — **past role, do not refer to it as current**. |
| **Thal Engineering** | The employer. Two plants in scope: Korangi and Yazaki/Port Qasim. Had **no prior R&D function**; the department was created for this role. |
| **Korangi plant** | Wire harness manufacturing. Owns: FVI, wireless ECT, a guided sub-assy line (described as already running, lowest priority). |
| **Yazaki / Port Qasim plant** | Automotive wire harness, Toyota-tier supply chain. Owns: part counter, crimp/connector defect detection, guided sub-assy, fuse box inspection, plus Kaizen system, ergonomics and co-pilot ideas (all deprioritised). **On site Fridays.** |
| **Toyota (Yaris), Hyundai** | End customers for the harnesses. |
| **K-Electric (KE)** | End client for the *adjacent* DCRC-TE and OLTS work — not part of this harness programme. |
| **Inveslab (Shahid San / Usama)** | IT/dashboard team — adjacent DCRC-TE work, not this programme. |

## Harness and assembly terms

| Term | Meaning |
|---|---|
| **Sub-assy** | Sub-assembly: inserting terminated wires into connector cavities to build a branch, before the lay-out board. |
| **Lay-out board** | The big board with jigs and clamps where branches are routed and taped into the full harness (images 2 and 3 of the plant photos). |
| **Cavity** | One hole in a connector housing that accepts one terminal. Cavities are lettered or numbered (the screen shows `A B D E F G`). |
| **Circuit No.** | Circuit designator from the harness drawing, e.g. `YQ4`. |
| **Job card** | The production order, e.g. `2488`. **The traceability key** for every machine in this programme. |
| **Wire cabin** | The wire feed rack / cabin position the operator draws the wire from. |
| **Page No.** | The step number in the build sequence on the guided screen. |
| **Checker** | The downstream verification station and operator; also a button on the sub-assy screen. |
| **SB Start** | Operator button on the sub-assy screen — starts the sub-assembly sequence. |
| **NG** | *No Good* — the universal reject verdict across Japanese-lineage plants. |
| **Dotsu NG** | 導通 *dōtsū* = electrical continuity. "Dotsu NG" = the continuity probe did not see the terminal seat. Proves the machine is doing live continuity checking. |
| **Poka-yoke** | Error-proofing: a device that makes a defect impossible or immediately visible. |
| **TBO** | Terminal Back-Out — the terminal is not locked by its lance and backs out under pull. |
| **NP lock** | The terminal's locking lance / retention feature. |
| **TPA** | Terminal Position Assurance — a secondary retainer that must be closed after all terminals are seated. |
| **Half-fit** | Connector or terminal only partly mated/seated. |
| **Splice / joint** | Several wires joined into one net — the reason netlist comparison must use **expected net sets**, not 1:1 maps. |
| **Golden sample** | A known-good harness / terminal / fuse box, run at shift start to prove the machine itself is healthy. |
| **Bellmouth** | The flared copper trumpet at the end of a crimp barrel — its presence and size indicate crimp quality. |
| **J/B** | Junction box. |
| **Harness model tags seen** | `YARIS-046d` (harness model), `A-2551 ST-7.20` (station/line ID). |
| **Connector P/Ns seen** | `ASZLE6-35F` (6-way), `SSGTSN8-18M-L` (18-way). |
| **AVSS** | Japanese thin-wall automotive wire type; gauge quoted in mm² (e.g. 0.35). |
| **JIS colour codes** | Japanese wire colour letters. `L` = blue. A trailing `/` with nothing after it = no stripe. |

## Test and inspection terms

| Term | Meaning |
|---|---|
| **ECT** | Electrical Check Tester — end-of-line continuity/isolation gate. |
| **OMI** | The plant's name for the ECT class; **OMI-10** is the specific unit on the floor. **DMI-10** also appears in plant photos at the assembly board. |
| **FVI** | Final Visual Inspection. |
| **AOI** | Automated Optical Inspection (the general industry term). |
| **Classical CV** | Rule-based OpenCV, as opposed to a trained model. Auditable; preferred first tier everywhere in this programme. |
| **ROI** | Region of Interest. |
| **MSA / gauge R&R** | Measurement System Analysis / repeatability and reproducibility — what proves an automated gate is as good as the manual one. Required before a machine becomes the gate. |
| **IATF** | The automotive quality management standard; shapes traceability and change-control expectations. |
| **PPAP** | Production Part Approval Process. **Modifying or replacing a customer-approved poka-yoke device likely needs a process-change submission.** Confirm the path before building. |
| **SQE** | Supplier Quality Engineer — the customer's engineer who must sign off. |
| **Shadow mode** | Running the new machine alongside manual inspection, logging but not blocking, while thresholds are tuned. **Always do this before blocking mode.** |
| **False accept / false reject** | A false reject costs ~30 seconds. **A false accept ships a defect to Toyota.** Design for zero false-accept. |
| **Takt time** | The required cycle time per unit. [UNKNOWN for every station here.] |
| **Reject Pareto** | Defect frequency ranking. **The single most requested and still-missing input across the programme.** |

## Standards referenced

| Standard | Covers |
|---|---|
| **SAE/USCAR-21** (Rev. 3) | Crimp pull-out strength methodology; pull rate 50–250 mm/min, 100 preferred. |
| **LV214** | German OEM equivalent for connector/terminal testing. |
| **JASO D616** | Japanese automotive connector insertion/extraction performance. |
| **IEC 61000 series** | EMC immunity — relevant to the adjacent OLTS/DCRC work, not to these machines directly, but the house style for compliance documents comes from it. |

**On pull-force numbers:** the standards give methodology, not the number.
`F_threshold` must come from the connector/terminal supplier spec and be signed
off by customer engineering, **per part**. Never quote a textbook figure as if
it were the spec.

## Vendors and reference systems [RESEARCH]

| Vendor | Relevance |
|---|---|
| **Cirris** (US) | 8100 / CH2 testers + Easy-Wire; **Smart-Lights** self-identifying fixtures — the feature worth copying (DS28E07 is our version). |
| **CAMI Research** (US) | CableEye + AutoBuild + **Light Director** fibre-into-cavity illumination; the only transparent published cost model in the industry. |
| **Komax** (CH) | Zeta — actual automated insertion. Different budget universe. |
| **Schleuniger / Metzner** | Upstream wire cut/strip/crimp. |
| **LightGuide** (US), **Arkite** (BE) | Projected-AR operator guidance. |
| **Purvi Automation** and Pune/Chennai SPM builders | "Wiring Harness Poka-Yoke Machine" — **the realistic commercial benchmark** for price. |
| **Hikrobot** | The plant's industrial camera (MV-CH120-20GC) and its **MVS** SDK. |
| **Aravis** | Open-source GigE Vision library — the macOS route to a Hikrobot camera. |

## Hard numbers worth remembering

- Crimp inspection volume: **270,000 pcs/day** (6 × 15,000 + 18 × 10,000).
- Terminal bend tolerance: **3°**. Terminal size range first phase:
  **0.13–0.85 mm**. Presentation window: **90 mm**.
- Fuse box `model 1-y33`: **33 fuses** — 16 × 10A, 3 × 7.5A, 3 large orange,
  2 large red, 2 large orange.
- Fuse colour separation measured on the demo set: good ≤ **ΔE 4.6**;
  7.5A brown in a 10A red slot = **ΔE 18**; default limit **10**.
- CAMI reference economics: **~$3,400** for a 256-point platform, **~$450** per
  fibre fixture, payback in **14–23 working days** at 25–40% labour saving.
- Sub-assy Phase-1 station: **≈ $1,700** (two jigs). Each additional connector:
  **≈ $305–362**.
- FVI Phase 1 after redesign: **≈ $925** hardware. Phase 0 gate: **$150**.
  Imported turnkey FVI equivalent: **$60,000–120,000**.
