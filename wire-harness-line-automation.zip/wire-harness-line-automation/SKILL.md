---
name: "wire-harness-line-automation"
description: >-
  Complete engineering context for Humayun Khan's (DM R&D, Thal Engineering)
  automotive wire-harness line automation programme across the Korangi and
  Yazaki/Port Qasim plants, Toyota Yaris and Hyundai harnesses, end customers
  Toyota/Hyundai. Covers SIX machines that share one plant, one toolkit and one
  set of constraints: the PC-guided sub-assembly machine (guided terminal
  insertion, Family A/B/C/D architectures, jig boards, cavity LEDs, pull-force
  TBO check, Excel job-program compiler, Raspberry Pi CM5 + ESP32-S3); the
  wireless ECT / OMI continuity tester (64-pin cards, MCP23017, ESP-NOW,
  drive-one/read-all, GND/REF pigtail); the wire crimp / terminal defect
  detection POC (bellmouth, 3-degree bend, PVC reach, Android Kotlin+OpenCV app,
  thal-inspect Python toolchain, MX BRIO, comb fixture); the fuse box vision
  inspection station (Hikrobot MV-CH120-20GC, golden-image compare, CIEDE2000,
  teach mode, STM32 stamp interlock, fusebox_inspector app); the FVI final
  visual inspection machine (traveling camera head on a belt rail, workmanship
  checks, Phase 0 image gate); and the Yazaki part counter (load cell + NAU7802
  + ESP32-S3 weigh counting). USE THIS SKILL WHENEVER the conversation touches
  this harness-line programme or ANY of its machines or parts — sub-assy, SB
  Start, Checker, NG, job card, circuit no, wire cabin, poka-yoke, Dotsu NG,
  TBO, NP lock, TPA, bellmouth, crimp, ECT, OMI, OMI-10, DMI-10, FVI, AOI,
  fuse box, stamp interlock, part counter, jig, pogo pin, spring probe,
  DS28E07, TLC5947, CD74HC4067, MCP23017, NAU7802, ESP32-S3, Raspberry Pi
  CM5, Hikrobot, MVS, Aravis, MX BRIO, thal-inspect, fusebox_inspector,
  YARIS-046d, A-2551 ST-7.20, ASZLE6-35F, SSGTSN8-18M-L, AVSS, JIS colour
  codes, USCAR-21, LV214, JASO D616, golden sample, netlist, Excel compiler,
  Korangi, Yazaki, Port Qasim — EVEN IF the user names just one module or one
  part number without re-explaining the project, because this skill carries the
  shared plant facts, the architecture decisions already paid for, the dead
  ends not to repeat, and the open questions that gate every one of these
  machines.
---

# Wire Harness Line Automation — Thal Engineering

Shared brain for a six-machine industrial automation programme on automotive
wire-harness lines. Read this at the start of any chat about the programme or
one of its machines, then open the one or two reference files for the machine
in play. `references/` holds the depth; this file is the map plus the facts
every machine depends on.

**Everything in this skill is tagged.** `[VERIFIED]` = confirmed on hardware,
on real images, or read directly off the plant floor. `[DESIGN]` = a decision
taken and agreed but not yet built or proven. `[RESEARCH]` = from vendor
literature, patents or standards, not from this plant. `[UNKNOWN]` = genuinely
not established — say so, don't fill it in.

## What this is (60-second orientation)

**Who.** Humayun Khan, Deputy Manager R&D at Thal Engineering (started Aug
2026). The role and the department were created for him; he is the entire R&D
function. Work email `humayun.khan@thalengg.com`. Prior role: Team Lead at
HHRCM Lab, NCRA-NED UET (~6 years, under Prof. Dr. Riaz Uddin) — now past.

**Where.** Two plants: **Korangi** (wire harness manufacturing) and
**Yazaki / Port Qasim** (automotive wire harness, Toyota-tier supply chain).
On site at Yazaki on **Fridays**. End customers: **Toyota (Yaris)** and
**Hyundai**. [VERIFIED]

**What.** Six machines, built in-house because imported equivalents cost
10–50× more and no vendor sells one that fits a 4 m Yaris harness off the
shelf. They sit at different points on the same process flow:

```
 wire cut/strip/crimp ──► SUB-ASSY (guided insertion) ──► LAY-OUT BOARD
        │                        ▲                             │
        │                        │                             ▼
   CRIMP DEFECT              PART COUNTER                  ECT / OMI
   INSPECTION                (store issuance)             (continuity)
                                                               │
                        FUSE BOX INSPECTION ◄──┐               ▼
                        (stamp on pass)        └────────────  FVI
                                                      (workmanship, final)
```

**Constraint that shapes everything.** Solo execution, limited time, strong
preference for embedded-heavy work with minimal computer vision. Two of the six
machines (crimp, fuse box) are CV anyway — taken on deliberately and scoped
hard. FVI was explicitly advised against as a solo pursuit and remains gated.

## Status at a glance (Oct 2026)

| Machine | State | Reference |
|---|---|---|
| Sub-assembly machine | Designed to Phase-1 BOM. **Not built.** | `references/sub-assembly-machine.md` |
| Wireless ECT | Architecture + README + SVG done. **No hardware built.** | `references/ect-tester.md` |
| Crimp defect inspection | Android app works; desktop `thal-inspect` running, real OK verdict achieved | `references/crimp-defect-inspection.md` |
| Fuse box inspection | App delivered; engine rewrite mid-flight as of 9 Oct; firmware never run on hardware | `references/fusebox-inspection.md` |
| FVI | One-pager issued. Phase 0 gate not passed. | `references/fvi-machine.md` |
| Part counter | Recommended as the quick win. **Never started.** | `references/part-counter.md` |

Full version history, config, deliverables, open issues and roadmap:
`references/project-state-current.md`.

## Facts every machine shares (memorize these)

**Reading the sub-assy screen** (photographed at the plant, decoded) [VERIFIED]:

```
A-2551 ST-7.20       station / line ID
Page No.:    33      step 33 of the build sequence
Wire Cabin:  0       wire feed rack / cabin position
Job Card No: 2488    production order — the traceability key
Circuit No.: YQ4     circuit designator from the harness drawing
Wire Gauge:  0.35    mm² (AVSS 0.35)
Wire Color:  L/      L = blue (JIS code), "/" = no stripe
Wire Length: 1512    mm
A B [D] E F G        cavity letters; highlighted = insert HERE now
ASZLE6-35F | SSGTSN8-18M-L    the two connector part numbers
[Checker] [SB Start] [NG]     operator control buttons
Harness model tag:   "YARIS-046d"
```

- **"Dotsu NG" = 導通 (dōtsū), Japanese for electrical continuity.** [VERIFIED]
  Seeing that word on the plant's defect board is what proved the existing
  sub-assy machine does a live continuity check per insertion, not just screen
  guidance. It is a Family B machine (see sub-assy reference).
- **The six defect modes the plant is trying to catch** [VERIFIED, from the
  plant's own "Possible Wiring Harness Defects" board]:
  1. Circuit wire miss · 2. Wrong wire insertion · 3. Retainer miss / TPA open ·
  4. **Terminal backout (TBO) / NP lock** · 5. Accessory part missing (tube,
  tape, grommet, sleeve) · 6. Male terminal pin bend.
  **Only 1, 2 and 4 are electrically detectable.** 3, 5 and 6 need mechanical
  or optical sensing. This single distinction drives every sensor architecture
  decision across the programme.
- **Crimp inspection volume:** 6 × 15,000 + 18 × 10,000 = **270,000 pcs/day**
  [VERIFIED, from the plant]. Any claim of "100% inspection" is a many-station
  throughput claim, not a one-machine claim. Keep detection and throughput
  separate when framing scope to management.
- **Terminal bend spec: 3°** [VERIFIED, Yazaki spec]. Fine-gauge terminal range
  in scope first: **0.13–0.85 mm**. Operators present terminals in batches
  through a **90 mm window**, not 100 wires at once.
- **Ambient light destroys repeatability.** The plant has fluorescent tubes plus
  daylight through translucent roof panels. Every vision checkpoint needs a
  shroud or strobed illumination with a matched bandpass filter. This is the
  single most common reason these projects fail in a shed environment, and it
  is cheap to design in and expensive to retrofit. [RESEARCH + VERIFIED from
  plant photos]
- **Golden sample is mandatory, everywhere.** A known-good harness / terminal /
  fuse box run at shift start is what separates "bad part" from "worn machine".
  Without it the first false NG becomes an argument you lose, and operators stop
  trusting the station. Budget it into every machine.
- **Fixture / jig library is the real cost**, not the electronics. Across every
  architecture except projected AR, the per-connector fixture dominates lifetime
  cost. Attack fixture cost or the economics are decided before firmware starts.

## The settled component stack (reuse, don't re-specify)

[DESIGN — these are the standing choices across the programme]

- **MCUs:** ESP32-S3 (primary), STM32F411 Black Pill V3.1 (WeAct USB-C),
  STM32G0 / STM32G030.
- **Compute:** Raspberry Pi CM5 (eMMC) for station HMI+IO; refurb desktop PC for
  vision; Pi 5 8GB + Hailo-8L retained for the crimp vision path;
  **Jetson Orin removed** (cost, and hard to source in Pakistan).
- **ICs:** MCP23017 (I²C GPIO expander), CD74HC4067 (16:1 analog mux), TLC5947
  (24-ch constant-current LED driver), NAU7802 (24-bit ADC — **never HX711**,
  its 10/80 SPS is too slow to catch a force peak), DS28E07 (1-Wire ID EEPROM),
  DS3231 (RTC), MAX31865, BAT54S, SN65HVD72.
- **Comms:** RS-485, ESP-NOW, telnet-serial, MQTT/Firebase, USB-CDC serial.
- **Dev:** Arduino IDE + STM32duino, Android Studio + Kotlin + OpenCV, Python +
  OpenCV + PySide6 + ReportLab + openpyxl, KiCad, MacBook Pro (**Intel** — this
  rules out current Xcode and therefore iOS development).
- **Sourcing:** Hall Road Lahore, Saddar / Abdullah Haroon Road Karachi,
  Daraz.pk, digilog.pk, JLCPCB/PCBWay for fab.

## Top gotchas (check here first)

1. **Metal enclosures block 4G** — antenna always external. [VERIFIED]
2. **AC opto ripple needs a software hold-window latch** (60 ms proven). It is
   not a hardware problem — don't add hardware to fix it. [VERIFIED]
3. **STM32duino pin macros:** the underscore form (`PB_11`, `PB_2`) is required
   for reserved/cautious pins on the Black Pill; `PB11`/`PB2` are not defined.
   Compile-test every pin explicitly. [VERIFIED]
4. **Relay drive from 3.3 V logic:** "INPUT float for OFF / OUTPUT LOW for ON"
   resolves the 3.3 V→5 V threshold problem on STM32. [VERIFIED]
5. **MAX7219 in noisy environments:** atomic SPI transactions + self-healing
   register re-assertion every 800 ms resolves corruption from AC switching
   noise. [VERIFIED]
6. **OpenCV on Android:** `Mat` fields must be `lateinit` and initialized
   *after* `OpenCVLoader.initDebug()`, or you get `UnsatisfiedLinkError`. Cap
   frame size and throttle the UI or the app freezes. [VERIFIED — cost a
   debugging session]
7. **Otsu silhouettes collapse without controlled lighting.** Canny survives bad
   light; silhouettes don't. If a pipeline's measurements all hang off an Otsu
   threshold, uncontrolled light makes the whole thing stand on sand. Fix the
   lighting before tuning the algorithm. [VERIFIED — cost a rewrite]
8. **Warm-coloured PVC shares copper's hue.** Any copper-by-colour detection
   must be gated to the thick terminal body, never the thin wire. [VERIFIED]
9. **Optical crosstalk between adjacent cavities** on 2.2 mm pitch makes two
   holes glow and the operator picks the wrong one — the machine then
   manufactures its own defects. Black-pot between fibres. [RESEARCH — the known
   failure mode that kills naive light-pipe designs]
10. **A Pi with an SD card and no UPS on a Karachi factory floor will corrupt
    itself** — not might, will. Read-only rootfs + overlayfs, eMMC (CM5), and a
    small DC UPS on the 24 V rail. Budget $70–110 for this; it is not optional.
11. **Consumer webcams drift.** Settings locked in Logi Tune reset after a
    reconnect, reboot or OS update. Fine for collecting a dataset, not for a
    production colour decision. [VERIFIED reasoning; applies to MX BRIO]
12. **Golden and live images must come from the same camera.** Re-teach every
    model on whichever camera ends up on the line.
13. **Job programs must never be firmware.** A new harness is a data file, not a
    flash cycle. Firmware OTA is a separate, rare, signed, staged operation.

## Dead ends already paid for — do not re-propose these

| Rejected | Why | Where |
|---|---|---|
| One MCU per jig node (RP2040/STM32G031 × 5) + RS-485 | Over-engineering for 5 jigs bolted to one bench: 5 more firmware targets, an address scheme, 5 things to desync. TLC5947 daisy-chains, muxes share address lines, DS28E07 is 1-Wire — the jig board is dumb copper. | Sub-assy |
| Phone + Wi-Fi SoftAP as the production HMI | Camera policy on automotive floors, 20 APs on 3 channels in a steel building, 6" screen adds back the perceptual burden the machine exists to remove, phones doze/update/walk off. **Keep it as the dev + commissioning + maintenance tool** — there it's excellent. | Sub-assy |
| Separate engineering mini-PC per bench | The Pi absorbs it. One engineering PC for the compiler, not one per station. | Sub-assy |
| NVIDIA Jetson Orin Nano | Expensive and hard to source in Pakistan. | Crimp, FVI |
| Global-shutter cameras, blue/red backlighting | Backlight was for a silhouette method that was abandoned. | Crimp |
| iPhone 15 / iOS rewrite | Better optics, but the Mac is Intel and the whole Kotlin pipeline would be rebuilt. Use the iPhone's camera app for dataset shots if you want the lens. | Crimp |
| Fixed ROI boxes at set % of frame | Only works if the part lands in exactly the same spot every frame — impossible handheld. Caused the `boundingRect`/`MatOfPoint` crash. Lock onto the largest object instead. | Crimp |
| Colour-based PVC detection | Insulation comes in many colours, not just red. | Crimp |
| Copper-visibility gating | These are **closed female terminals** with no exposed strands. | Crimp |
| Opto-isolation + 24 V field rail on ECT pins | Harness is always de-energized at test. 470 Ω + BAT54S clamp is sufficient and far cheaper. | ECT |
| Screen mounted on the ECT hardware | The laptop shows the connection map. | ECT |
| Many fixed camera pods for FVI (~$11–14k) | Replaced by a single traveling camera head on a belt rail (~$925). | FVI |
| Modbus gateway remapping (ICC XLTR-1000, USR-M100) | Cost and size, for the adjacent OLTS work. | (adjacent) |

## Routing table — which reference to open

| Topic in play | Read |
|---|---|
| Guided insertion, jigs, cavity LEDs, pogo pins, pull-force/TBO, Excel→JSON compiler, Pi CM5 station, Families A–D, vendor/cost benchmarks | `references/sub-assembly-machine.md` |
| Continuity tester, OMI, 64-pin cards, MCP23017, drive-one/read-all, ESP-NOW, GND/REF pigtail, netlist, 4-wire Kelvin, hi-pot | `references/ect-tester.md` |
| Crimp/terminal defects, bellmouth, 3° bend, PVC reach, Android app, `thal-inspect`, MX BRIO, comb fixture, HSV tuning, learned tolerances | `references/crimp-defect-inspection.md` |
| Fuse box station, Hikrobot, golden-image compare, CIEDE2000, teach mode, sticker check, stamp interlock, STM32 serial protocol, `fusebox_inspector` | `references/fusebox-inspection.md` |
| Final visual inspection, workmanship checks, traveling camera rail, Phase 0 image gate, OMI-10 baseline, gauge R&R | `references/fvi-machine.md` |
| Part counter, load-cell bins, weigh counting, job card issuance traceability | `references/part-counter.md` |
| Domain terms, defect vocabulary, standards, plant context, customers | `references/domain-glossary.md` |
| Current state, versions, config, deliverables, open issues, roadmap, what's unknown | `references/project-state-current.md` |

**When machines interact** — and they do: the sub-assy pull check and ECT both
own TBO; FVI scope is defined by what ECT already proved; the crimp POC's
dataset feeds a later model — read both files before proposing anything.

## Working style — instructions to future-you

- **Push back on over-engineering before he has to.** He will, every time, and
  he is usually right. The pattern across three machines: Claude proposes a
  comprehensive architecture, he asks "why so much equipment / why does every
  node need its own MCU", and the simpler answer turns out to be better. Start
  one level simpler than feels complete, and say what's deferred and why.
- **Functional first; safeties and redundancies later.** This is explicit and
  repeated. Don't bundle ESD, enclosures, e-stops and spares into a Phase-1 BOM
  unless they're load-bearing — but *do* argue hard for the cheap items with
  large consequences (ESD protection on operator-touched test points, fibre
  potting, the golden sample).
- **Always define a low-cost Phase 0 gate** before major investment. He thinks
  in phases with gates, and proposals without one get rejected.
- **Commodity parts available in Pakistani markets.** Price and sourcing are
  design constraints, not footnotes.
- **He verifies on real hardware and corrects you with photos.** When he sends
  a screenshot or a captured image, it outranks any assumption in this skill.
  Several entries here exist because an assumption was wrong and the image
  proved it. Ask for the image rather than tuning blind.
- **He wants the reasoning, not just the answer** — especially on CV technique
  choices (why Canny, why morphology, why Lab over HSV). Teach, don't assert.
- **Strict document fidelity on anything customer- or standards-facing.** Every
  test, level and criterion traces to a source document; no inferred additions.
  He has rejected documents for adding standard sub-part numbers that weren't in
  the source.
- **Concise external communications** with documents attached, not elaborated
  email prose.
- **Self-verify extensively before reporting.** Run the automated tests, the
  headless smoke test, the cross-photo validation, render the PDF and look at
  it — then report. He prefers a verified answer over a fast one.
- **Reuse validated stacks.** Check what's already proven on a prior project
  before specifying anything new. The EV fleet telematics project (separate
  skill) is the main prior inventory.
- **Never invent a number.** Thresholds, costs, pull forces and test-point
  counts that haven't been established are `[UNKNOWN]` and go on the open-
  questions list in `project-state-current.md`. He would rather see the gap.
