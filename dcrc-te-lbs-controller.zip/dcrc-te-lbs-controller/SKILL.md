---
name: dcrc-te-lbs-controller
description: >-
  Complete engineering context for the DCRC-TE unit — a transformer-mounted,
  LTE/GSM remote control & monitoring controller for a Load Break Switch (LBS)
  on K-Electric 11 kV distribution, built by Humayun Khan (HHRCM Lab / NCRA-NED
  UET) for Thal Engineering, end client K-Electric (KE). USE THIS SKILL WHENEVER
  the conversation touches the DCRC-TE project or ANY of its modules — even if
  only one is named and the project isn't re-explained. Triggers include:
  DCRC-TE, DCRC, DCRC TE, TE-DCRC, TE-DCRC-v1, TE-DCRC-v3, Thal LBS controller,
  LBS controller, load break switch, TX7000, K-Electric / KE LBS, pole-mounted
  transformer controller; the MCU (STM32 BlackPill, STM32F401CC, STM32F411CEU6,
  STM32duino, Arduino IDE, "HardwareSerial constructor", PB_11/PB_2 pin macros,
  earlier ESP32-WROOM-32U / ESP32-S3 prototype); the modem (A7670E, SIMCom,
  SIM7670G, Jazz APN jazzconnect.mobilink.com.pk, AT commands, AT+HTTPREAD,
  AT+CEREG, PWRKEY, CSQ/RSSI, "can't TLS Cloudflare"); the RTC (DS3231, NITZ/GSM
  time sync); relays & LBS (single relay float trick, interposing relay, dual
  LBS feedback, REMOTE CLOSE/OPEN, 24VDC coils); inputs (PC817 opto, 220VAC opto
  module, 24VDC opto, AC ripple 60 ms hold latch, pin-finder); power (Hi-Link
  HLK-PM01, LM2596 buck, diode-OR 220VAC priority, buck LED blinking); the
  dashboard/cloud (teinnovation.com, ke.teinnovation.com, apmsapi, apmsapi
  payload mapping OL/OT/CS/BS/SS/DS/BAT/P1A/P1V/P2A, TRIP/PWR_SRC/EVT/RSSI,
  Main Breaker, OIL_TRIP_EN, Shahid/Usama/Inveslab IT team); load-shedding
  (/api/loadshading/, category A1/A2, schedule JSON, NVS/EEPROM, buffered flash,
  IWatchdog/IWDG); KE signed scope (5 auto-trip conditions, OCR/AOC/HODO access
  tiers, Viqar Sami, F300 charger, IP54 enclosure); EMC/compliance (IEC 61000,
  MOV 14D471K, X2/Y2 caps, RC snubber, star earth, SIL/61508/61850); KiCad DFM
  (TE-DCRC-v3, annular ring, net classes); the KiCad PCB, feasibility doc, BOM,
  operating manual, or video demo. Also use it when starting a new DCRC-TE chat
  or asking about wiring, pin maps, the field payload contract, trip logic,
  load-shed scheduling, or commissioning.
---

# DCRC-TE — LBS Remote Control & Monitoring Unit

Shared brain for the DCRC-TE project. Read this SKILL.md first, then open the
one or two `references/` files for the module in play. This file is the map plus
the facts every module needs. **`references/project-state-current.md` is the
single source of truth for current state, versions and open issues — read it
before assuming anything is "done" or "decided".**

> **Why this skill exists:** the project has two parallel hardware builds and two
> divergent dashboard contracts that keep getting re-derived from scratch. This
> skill makes the divergences explicit so a new chat asks "which board / which
> dashboard?" instead of guessing. **Separate VERIFIED from ASSUMED; never
> collapse a conflict into one invented answer.**

## What it is (60-second orientation)

A **pole/transformer-mounted controller** that remotely monitors and operates a
**Load Break Switch (LBS)** on **K-Electric 11 kV distribution**. It:
- reads field signals (mains, SPD, gas/SF6, door, selector, oil, LBS feedback,
  battery/24 V) through **opto-isolated inputs**;
- drives the **LBS open/close** (via a relay → 24 VDC interposing relays → LBS
  motor coils) under the **KE-signed auto-trip logic** and remote command;
- reports telemetry to and takes commands from a **web dashboard** over **GSM/4G
  (A7670E)**, **plain HTTP**;
- executes a **load-shedding schedule** from the server, kept by a **DS3231 RTC**
  so it runs **fully offline** once fetched;
- self-heals via an **IWDG watchdog**.

**Who/why:** built solo by **Humayun Khan** (DM R&D, Thal Engineering; Team Lead,
HHRCM Lab / NCRA-NED UET) for **Thal Engineering**, end client **K-Electric**.
Dashboard/IT by **Shahid / Usama at Inveslab**. KE scope sign-off: **Mr. Viqar
Sami**. Pilot device ID: **TX7000**.

## The two builds (know which one you're in)

| | **Build A — TE-DCRC-v1 board** (this is the live-tested one) | **Build B — F411 bench build** |
|---|---|---|
| MCU | STM32 **BlackPill F401CC** | STM32 **BlackPill F411CEU6** (WeAct V3.1) |
| PCB | custom **TE-DCRC-v1** silk (KiCad; memory also calls the design "TE-DCRC-v3") | perfboard / bench |
| Status | **end-to-end verified**: posting, receiving commands, real 220 V inputs read, load-shed fetched | 5 module tests passed; `TEST_MODE` unified firmware |
| Pin map | pin-finder map (J10 opto DEAD) — see hardware ref | different map (PB1=Mains…) — see hardware ref |
| Downlink | **CSV** `1,888,…` field[0]=LBS cmd + separate `/api/loadshading/` | **JSON** `{"Main Breaker","DS","OIL_TRIP_EN"}` |
| Field map | OT=BattFault, CS=Gas, BS=LBS-FB, P2A=SPD | OT=Selector, CS=SPD, BS=Gas, P2A=LBS-FB |

**These are genuinely different and both are "real" in their own session.** When
a request is ambiguous, confirm the build before editing firmware or the API
contract. Most recent live-verified work = **Build A**.

## Architecture (common to both)

```
 220VAC mains ─[T1A fuse·MOV·X2/Y2]→ Hi-Link HLK-PM01 (5V) ─┐
                                                            ├─(diode-OR, 220VAC priority)→ 5V → 3V3
 24VDC batt  ─[fuse·TVS]───────────→ LM2596 buck (~4.7V) ───┘
        │
   FIELD INPUTS (PC817 opto per ch, 60ms AC hold-latch)          STM32 BlackPill
   mains · SPD · gas · door · sel-auto · sel-man · oil · ───────► reads inputs
   LBS-ON-FB · LBS-OFF-FB · 24V-spare · batt-fault · 24V-pwr        │  │
                                                                    │  └─I2C→ DS3231 RTC (PB6/PB7)
   A7670E modem ◄──USART1 PA9/PA10──────────────────────────────────┤      (NITZ time sync)
   (PA8 = PWRKEY)   plain HTTP → dashboard apmsapi + /api/loadshading │
                                                                     ▼
                                            PB4 relay (float trick: LOW=CLOSE/ON, float=OPEN/OFF)
                                              → interposing relays → 24VDC LBS motor coils
                                            dual feedback: LBS-ON-FB + LBS-OFF-FB (true position)
```

Control resolution each loop (AUTO): **load-shed window** → open; **door
unauthorized** (door open + auth 0) → open; any **KE trip** → open; else **follow
dashboard command**. **MANUAL = sense/report only** (MCU locked out), *except*
door-unauthorized forces OPEN in **both** modes (DCRC-TE v1 door-safety add-on).

## Verified ground-truth facts (confirmed on hardware/in practice)

- **A7670E (fw V1.11.1) cannot TLS-handshake Cloudflare** → the dashboard is
  reached over **plain `http://`**, never `https://`. (VERIFIED)
- **`AT+HTTPREAD` streams the body *after* the `OK`** → read the full window /
  wait for the `+HTTPREAD: 0` end-marker, or the reply is truncated. (VERIFIED)
- **LTE registration is in `AT+CEREG` (and `CGREG`), not `CREG`** — `CREG` stays
  `0,0` on a data-only LTE network. Accept `,1` or `,5`. (VERIFIED)
- **IWDG max timeout ≈ 32.76 s.** `IWatchdog.begin(60000000)` (60 s) is out of
  range → `begin()` fails → **no watchdog at all** → manual reset needed. Use
  **≤ 25 s** and feed it inside every modem wait. (VERIFIED)
- **STM32 EEPROM-emulation: per-byte `EEPROM.write()` → full sector-erase hang**
  (looks like a watchdog reset loop). Proper fix: **buffered flash API**
  (`eeprom_buffered_write_byte` × N + a **single** `eeprom_buffer_flush()`), and
  **only write when the data actually changes**. (VERIFIED, Build B)
- **STM32duino core 3.0.0: don't construct `HardwareSerial(rx,tx)`** — global
  `HardwareSerial` is abstract; use the ready-made **`Serial1`** instance (USART1
  = PA9 TX / PA10 RX), set pins with `setRx/setTx` if needed. (VERIFIED)
- **Pin macros `PB_11` and `PB_2` (underscore form)** are required on this
  BlackPill variant; `PB11`/`PB2` are undefined. (VERIFIED)
- **Relay at 3.3 V logic:** "**INPUT float = OFF / OUTPUT LOW = ON**" trick drives
  a 5 V relay module reliably. (VERIFIED)
- **AC opto ripple** reads as flicker → a **60 ms software hold-latch** turns
  half-cycle conduction into a steady state. Not a hardware problem. (VERIFIED)
- **Diode-OR for dual-supply priority**, not a changeover relay — the relay's
  5–10 ms transfer gap resets the MCU/modem. (VERIFIED)
- **Metal enclosure is a Faraday cage** → the 4G antenna must be external.
  (VERIFIED)
- **Load-shed group binding is server-side:** the server maps `TXID → category`.
  `TX7000` was bound to **A1**; deleting A1 makes `/api/loadshading/` return
  **404 `{"detail":"No active schedule found for group 'A1'."}`** — a config
  issue, not a device fault. Reassign the unit's group on the dashboard.
  (VERIFIED)
- **PWRKEY (PA8) is direct, LOW = press.** Cold-boot fails if pulsed before VBAT
  settles; re-pulsing a *booting* module turns it off. Fix: wait ~2.5 s, check if
  already awake, then pulse with ~12 s probe gaps. (VERIFIED, Build A)

## Top gotchas (root cause → fix) — full list in `references/gotchas-debugging.md`

1. **Dashboard "not updating" / device stuck re-registering** → firmware checked
   `CREG` only; LTE registers in `CEREG`. Fix: check CEREG/CGREG.
2. **Reply truncated / "no CSV"** → read before body streamed; data comes after
   `OK`. Fix: read full `+HTTPREAD` window.
3. **Board resets in a loop / needs manual reset** → either invalid 60 s IWDG
   (no watchdog) **or** EEPROM per-byte flash write hang. Fixes above.
4. **Modem silent until you press its button** → PWRKEY pulsed before VBAT
   stable. Fix: settle delay + check-awake + spaced retries.
5. **RTC jumps to 2070** → bad NITZ (`70/01/01`) accepted. Fix: validate year ∈
   [2024, 2040] before `rtc.adjust`.
6. **Won't compile (`HardwareSerial`)** → 3.0.0 abstract class. Fix: use
   `Serial1`.
7. **Buck 5 V LED blinking at power-up** → 5 V-rail overload/short or untrimmed
   buck. Fix: power-off rail-to-GND resistance check; trim buck to 5 V isolated.
8. **KiCad DRC flood (annular/hole/via)** → Constraints only *check*; **Net
   Classes + Pre-defined Sizes** set real geometry. annular = (OD − drill)/2 →
   grow via **diameter** (1.6/0.6 mm), not drill.

## Routing table — open the right reference

| Topic | File |
|---|---|
| Pin maps (both builds), PCB, opto inputs, power, BOM, KiCad DFM | `references/hardware-pcb-pinmap.md` |
| Control logic, trip rules, selector priority, relay/feedback, firmware structure, TEST_MODE | `references/firmware-control-logic.md` |
| A7670E AT flow, HTTP, registration, the apmsapi payload contract (both versions) | `references/cellular-dashboard-api.md` |
| Load-shedding: API, schedule JSON, category binding, RTC execution, NVS persistence | `references/loadshedding-rtc-nvs.md` |
| KE signed scope, access tiers, enclosure, EMC/IEC 61000, compliance roadmap | `references/ke-scope-compliance.md` |
| Every gotcha with root cause + fix (debug here first) | `references/gotchas-debugging.md` |
| **Current state, version history, config, deliverables, open issues, roadmap** | `references/project-state-current.md` |

## Working style (instructions to future-you)

- **Simplicity first.** Ship a functional POC to build credibility, then layer in
  safeties/redundancy. Humayun pushes back hard on over-engineering.
- **Reuse proven stacks.** The EV-fleet-telematics ESP32-S3 + SIM7670G stack was
  the starting reference; check prior inventory before specifying new parts.
- **Commodity parts, local sourcing** (Hall Road Lahore; Saddar / Abdullah Haroon
  Rd Karachi; digilog.pk; daraz.pk). Solo build — he must execute and maintain it
  alone.
- **Phased Phase-0 gates** before major spend.
- **VERIFIED vs ASSUMED, always.** Mark superseded config explicitly; don't
  delete it. No invented facts — write "unknown" and list it.
- **Record gotchas with root cause + fix**, not just the symptom.
- **Concise external comms** with a supporting table/doc attached; strict
  document traceability (no additions not sourced from the reference).
- When handing firmware over, give a **bench vs field** path (`TEST_MODE` or a
  RAW/override mode) and a **commissioning/demo sequence**.
