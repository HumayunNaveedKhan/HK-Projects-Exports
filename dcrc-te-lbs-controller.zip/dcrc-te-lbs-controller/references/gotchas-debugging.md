# DCRC-TE — Gotchas (root cause → fix). Debug here first.

Every entry: **symptom → root cause → fix**. VERIFIED unless marked.

## Cellular / HTTP

1. **Dashboard never updates; device loops `[MODEM] reg=0` despite good RSSI.**
   → Firmware checked **`CREG`** only; A7670E is LTE Cat-1 and registers in
   **`CEREG`** (CREG stays `0,0` on data-only LTE). → Check `CEREG?`/`CGREG?`,
   accept `,1`/`,5`. `postIO()` was gated on registration so it never sent.

2. **Reply truncated (`[RX] 0,250,12`) or "no CSV".**
   → `AT+HTTPREAD` was read before the modem finished streaming; the **body
   arrives AFTER the `OK`**. → Read a full fixed window / wait for `+HTTPREAD: 0`.
   Also **drain the UART before each transaction** so leftover bytes don't
   corrupt the next parse.

3. **HTTPS fails / handshake errors.**
   → A7670E **fw V1.11.1 can't TLS-handshake Cloudflare**-fronted hosts. → Use
   **plain `http://`**. (Not a code bug.)

4. **Modem is silent until you physically press its power button.**
   → PWRKEY (PA8, LOW=press) was pulsed **before VBAT settled**; and re-pulsing a
   module that's mid-boot **turns it back off**. → Wait ~2.5 s, probe `AT`
   (maybe already awake), then pulse with **~12 s probe gaps** between retries.
   If still silent: VBAT < 3.4 V or supply can't source ≥ 2 A.

5. **Modem thrashes, never settles; serial floods; occasional reset.**
   → `AT+COPS=0` (operator re-scan) was run **every cycle**, restarting network
   search; plus verbose modem echo to USB-CDC **blocked the write and starved the
   watchdog**. → Run heavy init (`CFUN/CNMP/CGDCONT/COPS`) **once**; keep
   `VERBOSE 0`.

## Watchdog / flash / resets

6. **Board hangs and needs a manual reset (watchdog never saves it).**
   → `IWatchdog.begin(60000000)` (60 s) **exceeds the IWDG max ≈ 32.76 s**, so
   `begin()` fails and **no watchdog runs**. → Use **≤ 25 s** and feed it inside
   every modem wait.

7. **Resets every cycle right after a load-shed save.**
   → Per-byte **`EEPROM.write()`** triggers a **full flash sector erase** that
   hangs; the marker never persists so every poll re-writes. → **Buffered flash
   API** (`eeprom_buffered_write_byte` × N + **one** `eeprom_buffer_flush()`),
   **write only on change**. Build-A interim: `LS_PERSIST 0` (RAM-only + re-fetch).

8. **RTC time jumps to 2070; load-shed fires at the wrong minute.**
   → Network returned `70/01/01` via `AT+CCLK?` and `yy=70` was accepted
   (`2000+70`). → Accept only **24 ≤ yy ≤ 40**; seed RTC on lostPower or
   implausible year; set manually at commissioning where NITZ is absent.

## Build / toolchain (STM32duino 3.0.0)

9. **Won't compile: `HardwareSerial(rx,tx)` no matching constructor / abstract.**
   → Core 3.0.0 made global `HardwareSerial` abstract (ArduinoCore-API). → Use
   the ready-made **`Serial1`** (USART1 = PA9/PA10); `setRx/setTx` if needed.

10. **`PB11` / `PB2` undefined.**
    → This BlackPill variant needs the **underscore form `PB_11` / `PB_2`**.
    Compile-test every pin explicitly.

11. **Relay won't switch from 3.3 V logic (5 V module).**
    → 3.3 V doesn't clear the module's threshold. → **INPUT float = OFF /
    OUTPUT LOW = ON** trick.

## Power / signal integrity

12. **Relay chatter; modem resets on transmit.**
    → Coil inrush / TX current (~2 A) sags the 5 V rail. → Bulk caps (incl.
    **1000 µF right at modem VCC**) + a solid 5 V feed.

13. **Buck 5 V LED blinking at power-up.**
    → Hiccup/overload: 5 V-rail short/overload or the LM2596 pot never trimmed.
    → Power-off resistance 5 V→GND (near-0 Ω = short); isolate buck, trim to 5.0 V.

14. **Dual supply resets the MCU on transfer.**
    → A **changeover relay** has a 5–10 ms break. → **Diode-OR** (220 VAC
    priority), no moving contact.

15. **AC opto input flickers/bounces in logic.**
    → Half-cycle opto conduction. → **60 ms software hold-latch**.

16. **4G won't connect inside the enclosure.**
    → Metal box = Faraday cage. → **External antenna** always.

17. **MAX7219 LED panel latches all-on/all-off under switching noise.**
    → AC switching noise corrupts the shift register. → Atomic SPI + **self-heal
    re-assert config every 800 ms**. (From an earlier display build; may not be
    in the current GSM-only production.)

## KiCad DFM (TE-DCRC-v3)

18. **DRC flood of annular-width / hole / via errors after tightening rules.**
    → The **Constraints** page only *checks*; real geometry lives in **Net
    Classes + Pre-defined Sizes**, still at defaults (0.6/0.3 vias). → Set sizes
    there; **Edit → Edit Track & Via Properties** ("set to net-class values") to
    push onto existing vias; **Tools → Cleanup Tracks & Vias**; enlarge footprint
    pad holes under 0.55 mm. **Annular = (OD − drill)/2** → grow **diameter**
    (via 1.6/0.6), not the drill. First opto's shorted series resistor killed a
    channel — found with a pin-finder sketch, remapped around it.

## Load-shed / API

19. **`/api/loadshading/` returns 404 `No active schedule found for group 'A1'`.**
    → Server maps TXID→group; the unit's group (A1) was deleted. → Reassign the
    unit's group on the dashboard. Firmware: on 404 clear schedule; on other
    non-200 keep last.

20. **Added a 2nd schedule but device says "unchanged".**
    → Compact int change-key missed it (or the server returned only one at that
    instant). → Change-key = full `schedules` text whitespace-stripped; print the
    raw reply to see what the server actually sent.
