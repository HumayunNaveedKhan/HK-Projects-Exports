# DCRC-TE — Cellular (A7670E) & Dashboard API

## Modem — VERIFIED

- **SIMCom A7670E** (LTE Cat-1), **Jazz** SIM, APN **`jazzconnect.mobilink.com.pk`**.
  Earlier spec used SIM7670G (reused from the EV telematics project); production
  is A7670E. Modem firmware **V1.11.1**.
- UART: **Serial1 = PA9 (TX) / PA10 (RX)**, 115200. PWRKEY on **PA8** (LOW=press).
- **Cannot TLS-handshake Cloudflare** (fw V1.11.1) → the dashboard is reached over
  **plain `http://`**. Do not switch to `https://`.

### Power-on (cold boot) — VERIFIED (Build A)
Wait ~2.5 s for VBAT to settle → probe `AT` (maybe already awake) → if silent,
pulse PWRKEY ~1.2 s LOW then release, and **wait ~12 s while probing before
re-pulsing** (a second pulse during boot turns it off). Up to ~4 attempts. If
still silent: VBAT < 3.4 V or supply can't deliver ≥ 2 A.

### Registration — VERIFIED
Check **`AT+CEREG?`** (and `CGREG?`), accept `,1` (home) or `,5` (roaming).
**Do NOT rely on `CREG`** — on a data-only LTE network it stays `0,0` forever,
which looks like "never registers" and blocks all posting. Init once (`CFUN=1`,
`CNMP=2`, `CGDCONT`, `COPS=0`); don't re-run `COPS=0` every cycle (it restarts
the network search and thrashes). `AT+CSQ` RSSI 10–31 good, 99 = none.

### HTTP flow — VERIFIED
`HTTPTERM → HTTPINIT → (CSSLCFG lines, harmless on http) → HTTPPARA URL/CONTENT
→ HTTPDATA <len> (send body at "DOWNLOAD") → HTTPACTION=1 → HTTPREAD → HTTPTERM`.
- **`HTTPREAD` streams the body AFTER the `OK`.** Read the full window (fixed
  ~4 s) or wait for the `+HTTPREAD: 0` end-marker; do not return on the first
  `OK` or the reply is truncated (`[RX] 0,250,12` style). Drain the UART before
  each transaction so stale bytes don't corrupt the next parse (and don't
  fragment the heap into a hardfault).
- Keep modem echo **off** on the USB console (`VERBOSE 0`): dumping every byte to
  USB-CDC can block the write and starve the watchdog → reset.

## apmsapi payload contract — **TWO DIVERGENT VERSIONS. CONFIRM WHICH IS LIVE.**

The endpoint is the same family (`.../apmsapi/`) but the key→sensor mapping,
polarities, and downlink format differ between the two builds/sessions. **Both
were stated by the user in their own session; do not merge them.**

### Version 1 — "Rev. 2" emailed to Shahid/Inveslab (Build B / F411 thread)
Endpoint `POST ke.teinnovation.com/apmsapi/`, `application/json`, every 10 s +
on change. **Uplink:**

| Key | Sensor | 1 / 0 |
|---|---|---|
| `TXID` | device id | "TX7000" |
| `OL` | Oil Level | Normal / Low |
| `OT` | **Auto/Manual Selector** | Auto / Manual |
| `CS` | **SPD** | Protected / Fault |
| `BS` | **Gas** *(polarity corrected)* | OK / Alarm-Low |
| `SS` | Door (physical) | Closed / Open |
| `DS` | Door Authorization (echo) | Auth / Unauth |
| `BAT` | 24 VDC power | OK / Fault |
| `P1A` | **Battery Fault Alarm** | OK / Fault |
| `P1V` | Mains 220 VAC | `220` / `0` |
| `P2A` | **LBS Feedback** | ON / OFF |
| `P2V,P3A,P3V,KW,KWH` | reserved | `0` |
| `TRIP` | trip reason (new) | NONE/DOOR_UNAUTH/BATT_FAULT/GAS_LOW/OIL_LOW/SURGE_UNPROTECTED |
| `PWR_SRC` | source (new) | LINE/BATTERY/NONE |
| `EVT` | event tag (new) | e.g. SRC_SWAP_LINE_TO_BATT |
| `RSSI` | GSM signal (new) | 0–31 (99=none) |

**Downlink = JSON:** `{"Main Breaker":1|0, "DS":1|0, "OIL_TRIP_EN":1|0}`.
`Main Breaker` honoured only when `OT=1` (Auto) and `TRIP="NONE"`.

### Version 2 — CSV contract (Build A / this project, most recently live-verified)
Endpoint `teinnovation.com/apmsapi/` **or** `ke.teinnovation.com/apmsapi/`
(**canonical host unresolved — confirm**), `application/json`, HTTP. **Uplink
key→sensor (user-dictated, confirmed field-by-field on the live dashboard):**

| Key | Sensor (pin) | 1 / 0 |
|---|---|---|
| `OL` | Oil Level (PB8) | OK / Low |
| `OT` | **Battery Fault** (PB3) | OK / Fault |
| `CS` | **Gas** (PB5) | OK / Fault |
| `BS` | **LBS ON feedback** (PB9) | ON / OFF |
| `SS` | Selector (PB15/PB14) | Auto / Manual |
| `DS` | Door (PB10) | Closed / Open |
| `BAT` | 24 V power (PB0) | Present / Off |
| `P1A` | Mains (PB13) | On / Off |
| `P1V` | **LBS OFF feedback** (PA2) | LBS-OFF / LBS-ON |
| `P2A` | **SPD** (PB12) | Fault-unprotected / Protected |
| `P2V` | 24 V spare (PA3) | — |
| `P3A,P3V,KW,KWH` | reserved | `0` |

**Downlink = quoted CSV**, e.g. `"1,888,999,777,666,22,11,33,44"` → **field[0] =
LBS command** (1 = ON/close, 0 = OFF/open); remaining fields **reserved /
meaning unconfirmed**. Strip the surrounding quotes before parsing (it's a JSON
string). A separate **3-position CSV** (LBS cmd, door-auth, post-interval-sec)
was also seen in the F411 thread — another variant to confirm.

### Polarity calibration — VERIFIED method
Whichever version is live, two channels are wiring-dependent and must be checked
against a known state on first power-up: **the battery-fault channel** and **the
SPD channel**. Each is a single ternary to flip in `buildJson()` if inverted.

## Open API items (confirm with Inveslab) — UNKNOWN
- Which mapping version is live for the deployed TX7000 (V1 JSON vs V2 CSV).
- Canonical host: `teinnovation.com` vs `ke.teinnovation.com`.
- **Door-Allow-Access** position in the CSV downlink (needed to make the
  door-unauthorized trip fully server-driven; defaults to allowed until then).
- Meaning of the reserved CSV fields (`888,999,…`).
- The **10 s** post interval is a firmware choice, **not** a KE requirement.
