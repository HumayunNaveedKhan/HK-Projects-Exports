# DCRC-TE — Hardware, Pin Maps, PCB, Power, BOM

> Read the build banner in SKILL.md first. There are **two pin maps** because
> there are **two boards**. Both are recorded; neither is deleted.

## Fixed pins (common to both STM32 BlackPill builds) — VERIFIED

| Function | Pin | Notes |
|---|---|---|
| LBS relay output | **PB4** | float trick: `OUTPUT LOW` = CLOSE/ON, `INPUT` (float) = OPEN/OFF |
| Modem PWRKEY | **PA8** | direct to A7670E PWRKEY; **LOW = press** |
| Modem UART | **Serial1** = **PA9 (TX) / PA10 (RX)** | USART1 to A7670E, 115200 |
| RTC I²C | **PB6 (SCL) / PB7 (SDA)** | DS3231 @ 0x68 |
| Debug | USB-C CDC | 115200; set USB "CDC (generic 'Serial' supersede U(S)ART)" |

## Pin map — BUILD A: TE-DCRC-v1 board, STM32F401CC (VERIFIED by pin-finder)

Discovered with a pin-finder sketch after **opto #1 / terminal J10 was found
DEAD (shorted series resistor)**. 220 V signals were shifted one terminal right
onto **J11–J19**; J10 is unused. "present/connected = 1".

| idx | Signal | STM32 pin | Terminal | Level |
|----:|--------|:---------:|:--------:|:-----:|
| 0 | Mains 220V | **PB13** | J11 | 220VAC |
| 1 | SPD Status | **PB12** | J12 | 220VAC |
| 2 | Gas/Smoke (SF6) | **PB5** | J13 | 220VAC |
| 3 | Door Status | **PB10** | J14 | 220VAC |
| 4 | Selector Auto | **PB15** | J15 | 220VAC |
| 5 | Selector Manual | **PB14** | J16 | 220VAC |
| 6 | Oil Level | **PB8** | J17 | 220VAC |
| 7 | LBS **ON** feedback | **PB9** | J18 | 220VAC |
| 8 | LBS **OFF** feedback | **PA2** | J19 | 220VAC |
| 9 | 24V Spare | **PA3** | J20 | 24VDC |
| 10 | Battery Fault | **PB3** | J21 | 24VDC |
| 11 | 24V Power | **PB0** | J22 | 24VDC |

- **J10 (leftmost 220 V terminal) is dead and unused** — no 220 V spare input
  remains on this board rev. The 220 V-side **silk labels are shifted by one**
  (J11 silk says "SPD" but carries Mains, etc.); relabel the terminal strip.
- `PA2`/`PA3` are USART2 default pins but free here; fine as GPIO. No conflict
  with Serial1 (PA9/PA10), USB (PA11/12) or SWD (PA13/14).

## Pin map — BUILD B: STM32F411 bench build (VERIFIED in its session; SUPERSEDED for Build A)

From the "ESP32S3 industrial control system prototype" chat and memory. Same KE
input *order* (idx 0–11) but **different pins** — do not apply to Build A.

| idx | Signal | STM32 pin |
|----:|--------|:---------:|
| 0 | Mains 220V | PB1 |
| 1 | SPD Status | PB13 |
| 2 | Gas/Smoke | PB12 |
| 3 | Door Status | PB5 |
| 4 | Selector Auto | PB8 |
| 5 | Selector Manual | PB9 |
| 6 | Oil Level | PB10 (memory) / unknown-exact |
| 7 | LBS ON FB (FB_CLOSED) | PB14 |
| 8 | LBS OFF FB (FB_OPEN) | PB15 |
| 10 | Battery Fault | PB3 |
| 11 | 24V Power | PB0 |

Memory's compact form: `PB0=24V, PB1=Mains, PB3=BattFault, PB12=Gas, PB13=SPD,
PB5=Door, PB8=SelAuto, PB9=SelMan, PB10=Oil, PB14=FB_CLOSED, PB15=FB_OPEN`.
**Reserved-pin macro note:** `PB_11` and `PB_2` must use the underscore form on
this variant (VERIFIED) — relevant if those pins are pressed into service.

## Pin map — EARLIEST: ESP32-WROOM-32U prototype (SUPERSEDED, archived)

- Relays: **GPIO4** = Relay1 (LBS ON), **GPIO23** = Relay2 (LBS OFF); relay
  modules **active-HIGH** (jumpers on H).
- A7670E: **GPIO14** = SIM power, **GPIO16** = RX (from modem TX), **GPIO17** = TX.
- 24 VDC optos: **GPIO22** = 24 V present, **GPIO21** = 24 V battery fault.
- 220 VAC optos: **GPIO13** = mains, **GPIO32** = SPD; rest TBD.
- Superseded by the STM32 BlackPill builds (migration driven by SIL/IEC
  61508/61850 certification readiness).

## Input conditioning — VERIFIED

- **PC817 opto-isolator per channel.** Off-the-shelf **8-channel AC 220 V opto
  modules** preferred over custom input stages. 100 kΩ series resistors on the
  220 V side; 10 kΩ pull-ups on the logic side.
- 220 VAC inputs on the 220 V terminal bank; 24 VDC inputs on the 24 V bank.
  Never put 220 V on a 24 V terminal.
- **AC ripple → 60 ms hold-latch** in software (`HOLD_MS 60`): if the pin reads
  LOW within the last 60 ms it's treated as active. Converts half-cycle opto
  conduction into a steady state.

## Relay / LBS actuation — VERIFIED

- **Single relay on PB4**, float trick (LOW=close/ON, float=open/OFF), driving
  **24 VDC interposing relays** → **LBS motor coils**.
- **Dual LBS feedback**: LBS-ON-FB + LBS-OFF-FB aux contacts give true position;
  non-complementary (both or neither) = wiring/switch fault → alarm. Firmware
  cross-checks commanded vs actual every ~2 s and re-asserts on mismatch.
- KE naming: **REMOTE CLOSE = LBS ON (connect)**, **REMOTE OPEN = LBS OFF
  (disconnect)**.
- Earlier ESP32 design used **two** relays (LBS ON coil / LBS OFF coil, 24 VDC);
  the STM32 production settled on **one** relay (energise = CLOSE). Pulse-vs-
  maintained drive for the actual LBS mechanism: **unknown / confirm per site**
  (open question carried from the feasibility phase).

## Power — VERIFIED

- Dual supply: **220 VAC** via **Hi-Link HLK-PM01 (5 V)**; **24 VDC** via
  **LM2596 buck**. **Diode-OR** combines them with **220 VAC priority** (set
  mains rail slightly higher, e.g. 5.1 V vs 4.7 V). **No changeover relay** — its
  transfer gap resets the MCU/modem.
- A **1000 µF bulk cap at the modem VCC** + a solid 5 V feed cured relay chatter
  and modem brown-outs (A7670E pulls ~2 A peaks on TX).
- **Buck LED blinking at power-up = hiccup/protection** → 5 V-rail overload or
  short, or the buck pot never trimmed to 5 V. Diagnose: power-off resistance
  from 5 V rail to GND (near-0 Ω = short); isolate the buck and trim to 5.0 V.

## EMC / protection install (perfboard, Build B) — VERIFIED

`T1A fuse → MOV (14D471K, 275 VAC) → X2 + Y2 caps → per-field MOV + ferrite →
RC snubber on relay contacts → single-point (star) earth to the transformer
tank.` See `ke-scope-compliance.md` for the IEC 61000 test plan.

## KiCad / PCB (TE-DCRC-v3 design; board silk "TE-DCRC-v1") — VERIFIED DFM notes

- The **Constraints** page only *checks*; **Net Classes** + **Pre-defined Sizes**
  set the geometry the board is actually built and routed with. Editing
  Constraints alone changes nothing.
- **Annular ring = (via outer diameter − drill) / 2.** To satisfy a ≥0.45 mm
  ring you grow the **diameter**, not shrink the drill. Working numbers that
  passed a Pakistani fab's DFM: **via 1.6 / 0.6 mm**, **min hole 0.55 mm**, track
  0.35 mm, clearance 0.4 mm, silk stroke ≥0.3 mm.
- To fix a DRC flood of annular/hole/via errors: set sizes in Net Classes +
  Pre-defined Sizes, then **Edit → Edit Track & Via Properties** ("set to net
  class values") to push them onto existing vias; **Tools → Cleanup Tracks &
  Vias** removes vias dropped on through-hole pads; enlarge offending **footprint
  pad** diameters (≥ hole + 0.9 mm) via "Push Pad Properties to other pads".

## BOM (prototype, indicative) — from the feasibility doc

Controller+comms: **ESP32-S3 + SIM7670G** (proto) / **STM32 BlackPill + A7670E**
(production); 4G antenna (external); M2M data SIM (Jazz). Power: HLK-PM01 (or
HLK-10M05/20M05 if modem peaks are high), MP1584/LM2596 buck, Schottky ORing
diodes (SR560/1N5822), 2200 µF bulk. Inputs: 8-ch AC 220 V opto module ×2, 24 V
DC opto (PC817), optional MCP23017 I²C expander. Output: opto-isolated relay
module. Protection: MOV 14D471K, Class-II SPD/GDT, TVS (SMBJ5.0A / P6KE30A),
ferrites, fuses. Mechanical: metal IP65/IP54 enclosure, DIN rail + 2.5 mm²
terminals. (Full table in the original feasibility document.)
