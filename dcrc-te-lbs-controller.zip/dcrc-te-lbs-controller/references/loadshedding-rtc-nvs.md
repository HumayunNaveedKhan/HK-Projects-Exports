# DCRC-TE — Load-Shedding, RTC & NVS Persistence

## Concept — VERIFIED

K-Electric load-shedding = scheduled windows when the LBS is opened (power cut)
per a load-management schedule. The device fetches its schedule from the server,
stores it, and the **DS3231 RTC drives execution on-device** so it fires on time
**even with no network**. Load-shed acts **only in AUTO mode**.

## Load-shed API (API #2) — VERIFIED

- `POST http://ke.teinnovation.com/api/loadshading/`  body `{"TXID":"TX7000"}`.
- Reply JSON:
  ```json
  {"TXID":"TX7000","count":1,"schedules":[
    {"category":"A1","start":"11:51:00","end":"11:52:00",
     "from_date":"2026-09-24","end_date":"2026-10-22"}]}
  ```
- Fields: `category`, `start`/`end` (`HH:MM:SS`), `from_date`/`end_date`
  (`YYYY-MM-DD`). Up to **8 windows**; **midnight-crossing** handled.
- Poll cadence: **30 s (test) / 1 h (production)**; also once at boot.
- **Category/group binding is server-side.** The server maps **`TXID → category`**
  (TX7000 → **A1**). The device just sends its TXID and gets its group's schedule.

### The 404 gotcha — VERIFIED (root cause + fix)
Deleting the group a unit is bound to makes the endpoint return **HTTP 404**
`{"detail":"No active schedule found for group 'A1'."}`. This is a **dashboard
config issue**, not a device fault: TX7000 was bound to A1, A1 was deleted (only
A2 left). **Fix on the dashboard:** reassign the unit to the live group (A2),
recreate A1, or have the API return whatever group the unit is mapped to.
Firmware behaviour: on **404**, clear the schedule (no stale shedding); on other
non-200 (500/timeout), **keep the last schedule** and retry.

## Change-detection + NVS — VERIFIED

- Compare the incoming schedule to what's stored; **write to NVS only when it
  actually changed** (identical schedules are discarded — no flash wear, no
  hang). Robust key = the whole `schedules` array text, whitespace-stripped (so
  add/edit/delete are all caught; an earlier compact int-key could miss a 2nd
  window).

### NVS crash — VERIFIED (root cause + the proper fix vs the workaround)
- **Symptom:** saving the ~700-byte schedule JSON to STM32 emulated EEPROM in a
  loop hard-hangs the MCU (looks like a watchdog reset loop; every poll re-writes
  because the marker never persisted).
- **Root cause:** naive **per-byte `EEPROM.write()`** triggers a **full flash
  sector erase per call**, which stalls long enough to trip the watchdog / never
  completes.
- **Proper fix (VERIFIED, Build B):** STM32 **buffered flash API** —
  `eeprom_buffered_write_byte(addr, b)` for every byte, then a **single**
  `eeprom_buffer_flush()` (one erase+write for the whole blob). Write only on
  change. Blob length ~768 bytes (`LS_NVS_LEN`).
- **Build A workaround (this project):** `#define LS_PERSIST 0` — keep the
  schedule in **RAM only** and re-fetch at boot + every poll. Stable (no flash
  write) and, since the unit always polls, effectively current. **Switch to the
  buffered-flash fix for true offline persistence across power cuts** once
  verified on the F401CC board.

## RTC (DS3231) & time — VERIFIED

- DS3231 on I²C PB6/PB7, addr 0x68. GSM **NITZ/NTP** time sync hourly when
  online; the RTC holds time between syncs so load-shed timing is accurate
  offline.
- Seed the RTC if `lostPower()` **or** the year is implausible (< 2024 or > 2040).
- **Bad-NITZ gotcha:** a network that returns `70/01/01` via `AT+CCLK?` must be
  rejected — accept the year only if **24 ≤ yy ≤ 40**, else the RTC jumps to
  2070 and load-shed fires at the wrong time. (In this region NITZ was often not
  provided → set the clock manually at commissioning via `RTCSET HH:MM`.)

## Execution logic — VERIFIED

`loadShedActiveNow()` = today ∈ `[from_date, end_date]` **and** current time ∈
`[start, end]` (overnight handled). In AUTO, an active window forces the LBS
**OPEN** with `TRIP=LOAD_SHED`; outside the window, normal control resumes.
Bench test: `LSTEST <sHHMM> <eHHMM>` injects a today-only window without touching
NVS; `LSPOLL` forces a server fetch; `LS?` shows stored windows + `shedNow`.

## Offline/online resilience — VERIFIED (Build B)
A fast-fail network state machine (`netReady()`, 2-strike threshold, 30 s
re-probe) stops HTTP timeouts from blocking RTC-driven load-shed execution when
the antenna is disconnected.
