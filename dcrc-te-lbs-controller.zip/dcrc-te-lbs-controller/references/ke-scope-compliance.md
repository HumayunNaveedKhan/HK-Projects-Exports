# DCRC-TE — KE Signed Scope, Access Tiers, Enclosure, Compliance

Source: KE-signed documents — "DCRC HT-Side Functional Block Diagram (Control
Side)" and "DCRC HT-Side Trip Parameters", signed off by **KE's Mr. Viqar Sami**;
approved pole-mount enclosure + terminal I/O drawings. Prepared by **Humayun
Naveed Khan** for Thal Engineering. Treat as contract — strict traceability, no
inferred additions.

## Signed-off control scope — VERIFIED

**5 auto-trip conditions** (force LBS OFF / REMOTE OPEN when in AUTO):
1. **Door unauthorized-open**
2. **Battery fault = 1**
3. **Gas low** (SF6)
4. **Oil low** — *only if oil-trip is enabled on the web* (`OIL_TRIP_EN`)
5. **Surge NOT PROTECTED** (SPD fault)

Plus the device-added **6th**: **load-shedding window** (AUTO only). And the
**door-safety improvisation** (beyond sign-off): **door unauthorized-open forces
LBS OFF in BOTH AUTO and MANUAL**.

**Selector priority (KE rule):** the **MANUAL** pushbutton box has **absolute
priority** — in MANUAL the controller does **not** drive the LBS coils under any
condition (remote command or auto-trip); local BS1/BS2 own the switch. **AUTO**
must be powered before the MCU actuates. (The door improvisation is the one
deliberate exception.)

**LBS naming:** **REMOTE CLOSE = LBS ON (connect)**; **REMOTE OPEN = LBS OFF
(disconnect)**. Outputs are **24 VDC coils** on the LBS motor mechanism, driven
through interposing relays.

## Web access tiers — VERIFIED

- **OCR** — view-only (no control path can post a command, by construction).
- **AOC** — limited control.
- **HODO** — full control.
Firmware honours the AOC/HODO controlled parameters (switch ON/OFF, door auth,
oil-trip enable). OCR cannot command.

## Electrical environment — VERIFIED

- DCRC power source: **external 220 VAC via PT/Tx from the 11 kV line**.
- Battery: **F300 charger** with a **24 VDC interposing relay**.
- Enclosure: **IP54, pole-mounted, 1.5 mm sheet steel, earth bar + padlock**.
  (The feasibility BOM also referenced IP65 metal; the **KE-signed spec is
  IP54**.)

## Robustness features retained (beyond scope) — VERIFIED
Galvanic isolation on every field signal (PC817/channel); diode-OR seamless
220VAC↔24VDC handover with no reset; task watchdog (auto-recover within ~10 s);
AC input 60 ms hold-latch; non-blocking LBS pulse with interlock + 500 ms
opposite-action dead-time; dual LBS feedback mismatch alarm.

## EMC / type-approval roadmap — VERIFIED (plan) / ASSUMED (not yet executed)

- Hardening installed on the perfboard: `T1A fuse → MOV 14D471K → X2/Y2 caps →
  per-field MOV + ferrite → relay RC snubber → star-earth to transformer tank`.
- Migration from ESP32 to STM32 is explicitly for **SIL / IEC 61508 / IEC 61850**
  certification readiness (future, not yet certified).
- The **OLTS** sibling project has the concrete EMC test machinery that DCRC-TE
  will likely reuse: an 18-test PPMC schedule and EMC execution docs for **ESD
  (IEC 61000-4-2), EFT/Burst (IEC 61000-4-4), Surge (IEC 61000-4-5)** — spec +
  technician-checklist versions; RFQ to SGS (Thal provides premises, SGS supplies
  equipment/procedures/reports). **IEC 61000 sub-part editions are NOT named in
  the PPMC docs — must be agreed with PPMC D&S and the lab before booking.**

## Known items awaiting sign-off — UNKNOWN / open
- Dashboard event-log field name + final command/response schema (confirmed via
  curl to apmsapi; final schema pending — see the two divergent mappings).
- Physical MANUAL lock-out in the 24 V motor-coil wiring (drawing P-e#02) — to be
  verified at commissioning as defence-in-depth behind the firmware rule.
- EMC / IP54 type-testing of the finished enclosure before mass deployment.
- Whether the 10 s posting cadence is acceptable to KE (it's a firmware default,
  not specified by KE).
