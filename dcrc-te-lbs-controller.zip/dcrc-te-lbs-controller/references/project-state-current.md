# DCRC-TE — Current State, Versions, Config, Deliverables, Open Issues

_Last compiled from memory + chat history on 2026-10-09. Update this file as the
single source of truth; the rest of the skill is reference depth._

## One-line status
**Build A (TE-DCRC-v1, STM32F401CC) is end-to-end live-verified on the bench:**
posts telemetry, receives LBS commands, reads real 220 V inputs, fetches the
load-shed schedule. Remaining work is dashboard-side config + final field-map
reconciliation + offline NVS persistence + EMC/enclosure type-testing.

## Hardware generations (version history)
1. **ESP32-WROOM-32U DevKit + SIM7670G** — earliest bench proto. **SUPERSEDED.**
2. **ESP32-S3 + SIM7670G** — specced reuse of the EV-telematics stack; feasibility
   doc + BOM produced. **Largely superseded by STM32** (kept as parallel notes).
3. **STM32 BlackPill + A7670E** — production direction (for SIL/IEC readiness):
   - **Build B — F411CEU6 (WeAct V3.1)**: 5 module tests passed; `TEST_MODE`
     unified firmware; IEC-61000-hardened perfboard; Rev.2 JSON payload mapping
     emailed to Inveslab. Pin map = PB1=Mains… (see hardware ref).
   - **Build A — F401CC on custom PCB "TE-DCRC-v1"**: the board physically built,
     assembled, and tested in the most recent sessions. Pin-finder map (J10 opto
     dead). CSV downlink + separate `/api/loadshading/`. **This is the latest.**

## Config / constants (current, Build A)
- `DEVICE_TXID "TX7000"`; APN `jazzconnect.mobilink.com.pk`.
- IO API: `http://` apmsapi (host `teinnovation.com` vs `ke.teinnovation.com`
  **unresolved**). LS API: `http://ke.teinnovation.com/api/loadshading/`.
- Post 10 s + on change; LS poll 30 s (test) / 1 h (prod).
- IWDG **25 s** (not 60). `HOLD_MS 60`. `LS_PERSIST 0` (RAM-only) on Build A;
  buffered-flash NVS is the proper fix (Build B) to port over.
- Pins: relay PB4, PWRKEY PA8, Serial1 PA9/PA10, I²C PB6/PB7. Input map: Build A
  table in hardware ref.
- RTC seed when lostPower/implausible year; NITZ often absent → set manually.

## Deliverables produced (exist outside this skill)
- DCRC-TE **feasibility document + BOM** (3-unit prototype).
- **KE scope sign-off package** (auto-trip rules, access tiers, enclosure).
- **TE-DCRC-v3 KiCad PCB** design; the **TE-DCRC-v1** board fabricated & assembled.
- Firmware: Build-B `DCRC_TE_stm32.ino` (TEST_MODE) + 5 module test sketches;
  Build-A `DCRC_TE_KE_Full.ino` (2 APIs) + `Step1_IO`, `BoardTest`,
  `Integrated_Test`, `v2`, `PinFinder`.
- **Operating & commissioning manual**, **engineering README**, **IT/dashboard
  README**, **Rev.2 payload-mapping email** to Shahid/Inveslab.
- IEC-61000-hardened perfboard build (Build B).

## Open issues / to-reconcile (ranked)
1. **Which is the live unit/contract — Build A (CSV, F401CC) or Build B (JSON,
   F411)?** Pin maps AND field mappings AND downlink formats differ. Decide the
   canonical one before any firmware/API edit. _(UNKNOWN — needs user.)_
2. **Dashboard group binding:** reassign TX7000 from deleted group A1 to the live
   group (A2) so `/api/loadshading/` stops 404-ing. _(Dashboard/Inveslab action.)_
3. **Canonical apmsapi host:** `teinnovation.com` vs `ke.teinnovation.com`.
4. **Door-Allow-Access field** position in the CSV downlink (to make the
   door-unauthorized trip fully server-driven; defaults to allowed until then).
5. **NVS offline persistence on Build A:** port the buffered-flash fix and set
   `LS_PERSIST 1` (currently RAM-only).
6. **Battery-fault & SPD channel polarity** — verify on first live signals; flip
   the ternary if inverted.
7. **LBS drive: pulse vs maintained** for the actual motor mechanism — confirm
   per site.
8. **Board-name drift:** silk says **TE-DCRC-v1**, memory calls the design
   **TE-DCRC-v3** — confirm the intended name/rev.
9. **EMC / IP54 type-testing** of the finished enclosure before mass deploy;
   agree IEC 61000 sub-part editions with PPMC/lab.
10. **MANUAL motor-coil physical lock-out** (drawing P-e#02) to verify at
    commissioning.

## Roadmap
- Reconcile Build A/B into one production definition.
- Finish dashboard group binding + confirm live field map; end-to-end field test.
- Port buffered-flash NVS to Build A for true offline load-shed.
- Enclosure + EMC type-testing; SIL/IEC 61508/61850 readiness.
- Field commissioning of TX7000, then fleet rollout (per-transformer TXID +
  category).

## People
- **Humayun Khan** — builder (DM R&D Thal Engineering; Team Lead HHRCM Lab /
  NCRA-NED UET). _Note: memory `overview.md` once attributed DM-R&D to "Hashir";
  the corrected profile states Hashir is a different person — attribute this
  project to Humayun._
- **Shahid San / Usama — Inveslab** — dashboard/IT integrator (HTTP-only).
- **Mr. Viqar Sami — K-Electric** — scope sign-off.

## Gaps I could not fill from memory/chat (write-in as you learn them)
- Exact Build-B pins for idx 6/9 (Oil/24V-spare) — only partially recorded.
- Final reserved-CSV field meanings (`888,999,…`).
- Whether Build A and Build B are the same deployed unit or two boards in flight.
- The actual LBS mechanism drive requirement (pulse width / maintained).
