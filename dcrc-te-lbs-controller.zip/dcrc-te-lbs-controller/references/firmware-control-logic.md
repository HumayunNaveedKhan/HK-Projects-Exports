# DCRC-TE — Firmware Structure & Control Logic

## MCU & toolchain — VERIFIED

- **STM32 BlackPill** (F401CC on Build A / F411CEU6 WeAct V3.1 on Build B),
  **Arduino IDE + STM32duino core 3.0.0**, Intel MacBook Pro.
- Board: "Generic STM32F4" → the specific BlackPill variant. **USB support = CDC
  (generic 'Serial' supersede U(S)ART)** so `Serial` is the USB-C console and
  `Serial1` is free for the modem.
- Libraries: `RTClib` (DS3231), `IWatchdog` (IWDG), `EEPROM` (flash emulation),
  `Wire`.
- Flash via USB-C DFU (BOOT0 + NRST dance) or ST-Link SWD (preferred for dev).

## Loop shape — VERIFIED

Fast, non-blocking main loop (~5 ms tick):
1. **Scan inputs** with the 60 ms AC hold-latch; "present = 1". Bench builds
   support a per-input **override** (`IN <ix> <0|1|-1>`) so logic can be tested
   without 220 V.
2. **`control()`** — resolve the trip policy and drive the relay (below).
3. **`verifyFeedback()`** — cross-check commanded vs actual LBS (dual FB).
4. **Uplink** (apmsapi) every 10 s + within a few s of any change.
5. **Load-shed poll** on its own cadence (30 s test / 1 h prod).
6. **Serial command** handler (bench control).
7. Feed the **IWDG** at the top of loop and inside every modem wait.

## KE-signed control logic — VERIFIED (scope-signed + one documented add-on)

**Selector is king.** 
- **AUTO** (`SS/OT`=1): MCU has full control — senses, auto-trips, and follows the
  dashboard command.
- **MANUAL** (`SS/OT`=0): MCU is **sense/report only**, does **not** drive the
  LBS. Local pushbuttons (BS1/BS2) own the switch. This is a hard KE rule.

**Auto-trip conditions (AUTO), highest priority first:**
1. **Load-shed window active** → LBS **OPEN** (the 6th rule, added on top of the 5
   signed ones). *(AUTO only.)*
2. **Door unauthorized** = door **open** AND web auth = 0 → LBS **OPEN**. ← this
   one fires in **BOTH AUTO and MANUAL** (the **DCRC-TE v1 door-safety
   improvisation**, beyond the original sign-off — added, reverted, then
   re-added per explicit instruction; final state = active in both modes).
3. **Battery fault** = 1 → OPEN.
4. **Gas low** → OPEN.
5. **Oil low** → OPEN **only if oil-trip is enabled** (`OIL_TRIP_EN` from web).
6. **Surge NOT PROTECTED** (SPD fault) → OPEN.
- Else → **follow the dashboard LBS command**, honoured **only when AUTO and
  TRIP=NONE**.

The **active trip reason** is recorded in every telemetry frame: `NONE /
DOOR_UNAUTH / BATT_FAULT / GAS_LOW / OIL_LOW / SURGE_UNPROTECTED / LOAD_SHED /
SEL_FAULT / MANUAL`.

**Relay drive:** change state only on a change (no chatter). Non-blocking pulse
with interlock and a 500 ms opposite-action dead-time was specified for the
two-coil LBS; the single-relay production build drives energise=CLOSE and holds.

## Watchdog & self-healing — VERIFIED

- **IWDG via `IWatchdog`.** Max ≈ **32.76 s** — **use ≤ 25 s** (a 60 s value fails
  `begin()` and leaves you with *no* watchdog; this was a real "needs manual
  reset" bug). Feed it at loop top and inside every blocking modem wait
  (`wdelay()`, inside `at()`), so a genuine hang auto-recovers.
- Watchdog-safe state: an IWDG reset must not glitch the relay or lose
  auth/command state on recovery.

## Bench vs field — VERIFIED (two patterns, by build)

- **Build B — `#define TEST_MODE 1`:** primes all KE conditions favourable in
  software, bypasses the real input scan, shortens poll intervals (3–30 s) for a
  fast demo video, keeps the board instantly responsive to real optos, and lets a
  dashboard command override load-shed. **`TEST_MODE 0`** → production: real
  optos drive `state[]`, strict KE logic, 10 s / 1 h intervals. The `#if` guards
  make the test scaffold vanish cleanly.
- **Build A — serial bench tools:** `IN <ix> <0|1|-1>` force inputs, `SEL
  AUTO|MAN|NONE`, `WEB 0|1`, `AUTH 0|1`, `RELAY ON|OFF|PULSE`, `RAW ON|OFF`
  (dashboard R0 drives relay directly, bypassing selector gating for bench),
  `LSPOLL/LS?/LSTEST`, `RTCSET/RTC?`, `MODEM`, `AT <cmd>` passthrough, `STATUS`.

## Firmware deliverables that exist (filenames seen) — for continuity

- Build A (this project): `DCRC_TE_Step1_IO.ino` (IO+relay only),
  `DCRC_TE_BoardTest.ino` / `DCRC_TE_Integrated_Test.ino` (full board bring-up
  with RTC+modem),  `DCRC_TE_v2.ino` (IO+actuation live),  **`DCRC_TE_KE_Full.ino`
  (current: 2 APIs — IO/actuation + load-shedding)**, plus `DCRC_TE_PinFinder.ino`.
- Build B: `DCRC_TE_stm32.ino` production firmware with `TEST_MODE`, plus five
  per-module test sketches (`01_blink`, `02_relay`, `03_optos_scan`,
  `04_rtc_ds3231`, `05_a7670e_test`).
- **These are not in this skill** (they live in the user's outputs). Rebuild from
  the facts here if needed; always confirm which build before porting code.

## Field/commissioning sequence — VERIFIED pattern

1. SIM inserted, antenna connected (external).
2. Boot → `[modem] reg=1`, RTC sync, dashboard shows device within ~30 s.
3. Toggle the physical Selector → MODE tile updates (AUTO/MANUAL).
4. Trigger each fault input → TRIP tile shows the reason.
5. Command LBS ON/OFF from dashboard (in AUTO) → LBS feedback flips.
6. Upload a schedule window a minute ahead → TRIP=LOAD_SHED at the boundary,
   clears at the end; verify it still fires with the antenna unplugged (offline).
