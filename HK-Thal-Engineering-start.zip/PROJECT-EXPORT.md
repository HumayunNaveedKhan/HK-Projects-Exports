# Thal Engineering Indigenous Development — Full Project Export

Exported 09 October 2026. This single document carries everything needed to
recreate the project in another Claude account: the project setup, scope,
people, hardware stack, every active workstream with its current state, the
hard-won engineering learnings, and what has been delivered so far.

---

## 1. Project setup (paste these into the new project)

**Project name**

```
Thal Engineering Indigenous Development
```

**Project description / custom instructions**

```
Here at Thal Engineering, we need to develop some industrial solutions that help
the industry to enhance their processes. You need to act as an industrial
solutions developer. Having 40 years of experience in embedded systems,
electronics, electrical, hardware, computer vision, machine learning and visual
inspection.
```

**Project files to re-upload:** the four Yazaki plant photos in `project-files/`
(IMG_9232, IMG_9233, IMG_9237, IMG_9238) — wire sub-assembly station with
PC-guided screen (job card 2488, circuit YQ4, Yaris-046d), and the main harness
assembly board line at Port Qasim.

---

## 2. Who I am

- Humayun Khan — **Deputy Manager, R&D at Thal Engineering** (started Aug 2026).
  The role and department were created specifically to build indigenous
  development capability in a firm with no prior R&D function.
- Work email: humayun.khan@thalengg.com
- Previously Team Lead at HHRCM Lab, NCRA-NED UET (~6 years under Prof. Dr. Riaz
  Uddin). That role is now past.
- Co-Founder of two startups: **Haptronica** and **RobAutoStem** (NIC Karachi
  Cohort 12; BIC NEDUET).

---

## 3. Scope and context

- Mandate: develop indigenous industrial solutions and process improvements
  across two plants — **Korangi** (wire harness manufacturing) and
  **Yazaki / Port Qasim** (automotive wire harness, Toyota-tier supply chain).
- End clients: **K-Electric (KE)** and automotive OEMs (**Toyota Yaris**,
  **Hyundai**).
- Key external collaborators:
  - **Shahid San / Usama at Inveslab** — IT/dashboard team for the KE web interface
  - **Mr. Viqar Sami (KE)** — scope sign-off
- On site at **Yazaki on Fridays**.
- Constraints: solo execution, limited time, preference for embedded-systems-heavy
  projects with minimal computer vision.

### Working approach and patterns

- Works solo — solutions must be executable and maintainable independently,
  without a team.
- Strong preference for **functional simplicity and economy**: pushes back on
  over-engineering, chooses commodity parts available in Pakistani electronics
  markets.
- **Phased development**: always define a low-cost/low-risk Phase 0 gate before
  committing major investment.
- **Reuse proven component stacks** across projects rather than redesigning from
  scratch.
- Uses Excel-based compiler patterns for job program management.
- Sequences projects to build organizational credibility early — ship the quick
  win first, then open the harder projects.
- Prefers concise external communications with supporting documents attached
  rather than fully elaborated text.
- Iterates documents with strict traceability; rejects additions not directly
  sourced from reference documents.
- Demonstrated confidence executing at industrial level; consistently pushes for
  functional simplicity first, with safeties and redundancies deferred to later
  phases.

---

## 4. Standard technology stack

| Category | Parts |
|---|---|
| MCUs | ESP32-S3 (primary), STM32F411 Black Pill V3.1 (WeAct USB-C), STM32G0 |
| Modems | SIM7670G 4G/LTE, A7670E (GSM/LTE) |
| Sensors / ICs | NAU7802 (24-bit ADC), MCP23017 (I²C GPIO expander), DS3231 (RTC), MAX31865 (RTD), MAX7219, TLC5947, CD74HC4067 |
| Comms | RS-485 / Modbus RTU, ESP-NOW, MQTT / Firebase, telnet-serial, HTTP |
| Development | Arduino IDE + STM32duino, KiCad, Android Studio + Kotlin + OpenCV, Python + ReportLab, MacBook Pro (Intel) |
| Vision / compute | Raspberry Pi 5 8GB + Hailo-8L AI Kit, Logitech MX BRIO 4K, Hikrobot MV-CH120-20GC GigE/PoE camera + 12mm 1/1.8" lens, Samsung Note10 (landscape-locked, Android 10+) |
| Backend | Pi/Excel logging, Firebase, MQTT, Google Sheets |
| Sourcing | Hall Road Lahore; Saddar / Abdullah Haroon Road Karachi; Daraz.pk; digilog.pk; JLCPCB for fab |

---

## 5. Workstreams — current state

### 5.1 DCRC-TE — LBS Remote Controller for K-Electric (production, STM32)

Distribution Control & Remote Communication unit: an LTE-based remote control and
monitoring unit for an **LBS (load break switch)** mounted on a distribution
transformer.

- Migrated from ESP32 bench prototype to **STM32F411 Black Pill V3.1** (WeAct
  USB-C) for IEC 61508/61850 certification readiness.
- **All five sequential module tests passed**: blink/USB, relay, 11 opto inputs
  with AC latch, DS3231, A7670E AT passthrough.
- Production architecture settled:
  - GSM-only (no WiFi, no LEDs)
  - Single relay — **GPIO energised = CLOSE / ON**
  - Dual LBS feedback contacts
  - DS3231 RTC with GSM time-sync
  - NVS/EEPROM load-shedding schedule: up to 8 daily windows, midnight-crossing
    handled
  - Five KE-signed auto-trip rules plus load-shed as the sixth
- GSM connectivity confirmed to `ke.teinnovation.com/apmsapi/`. **A7670E cannot
  TLS-handshake Cloudflare**; the teinnovation endpoint returns a quoted CSV
  downlink format.
- IEC 61000 safety hardening installed on perfboard:
  `T1A fuse → MOV → X2+Y2 caps → per-field MOV + ferrite → relay RC snubber →
  star-earth to transformer tank`
- Confirmed final pin map: PB0=24V, PB1=Mains, PB3=BattFault, PB12=Gas, PB13=SPD,
  PB5=Door, PB8=SelAuto, PB9=SelMan, PB10=Oil, PB14=FB_CLOSED, PB15=…
- **Critical STM32duino finding:** `PB_11` and `PB_2` underscore forms are
  required; `PB11` / `PB2` macros are not defined for this Black Pill variant.

**KE signed-off scope**
- 5 auto-trip conditions: door unauthorized-open, battery fault = 1, gas low,
  oil low (if enabled), surge NOT PROTECTED
- 3 web access tiers: OCR view-only, AOC limited, HODO full
- DCRC power source: external 220VAC via PT/Tx from 11kV; battery charger F300
  with 24VDC interposing relay
- Enclosure: IP54 pole-mounted, 1.5mm sheet, earth bar + padlock
- **LBS naming convention (KE): REMOTE CLOSE = LBS ON (connect);
  REMOTE OPEN = LBS OFF (disconnect).** Outputs are 24VDC coils on the LBS motor
  mechanism.

**Dashboard integration**
- Reports to the teinnovation / apmsapi web dashboard over **HTTP only** — the
  sole protocol the integrator (Usama at Inveslab) supports.
- Two-way pattern: request = telemetry, response = command.
- Plan: test cloud comms via Google Sheets first, then switch to teinnovation.

### 5.2 DCRC-TE Hardware Prototype (earlier / parallel ESP32 build)

- **ESP32-S3 + SIM7670G 4G/LTE** stack, reused from the EV fleet telematics
  project. Early bench prototype used a classic ESP32-WROOM-32U DevKit.
- Custom PCB **"TE-DCRC-v3"** (KiCad) uses an **STM32 BlackPill F401CC** with a
  SIM module on USART1 (PA9 TX / PA10 RX); firmware in Arduino IDE, STM32 core
  3.0.0.
- Design: 10 field inputs (mix of 220VAC and 24VDC), dual power supply (220VAC +
  24VDC with 220VAC priority), 2 relay outputs actuating LBS ON/OFF at 24VDC.
- Targeted a 2-day prototype first, with ESD/EMI/surge hardening deferred.
- Full feasibility document and BOM produced. Open questions remain on inputs 7/8
  signal levels, LBS actuation (pulse vs. maintained), comms scope, and GNSS
  requirement.
- **Antenna placement is critical** — the metal enclosure acts as a Faraday cage;
  the antenna must be external.

**Confirmed pin map — ESP32-WROOM-32U prototype**
- Relays: GPIO4 = Relay 1 (LBS ON), GPIO23 = Relay 2 (LBS OFF); relay modules
  active-HIGH (jumpers on H)
- A7670E modem: GPIO14 = SIM power, GPIO16 = UART RX (from modem TX),
  GPIO17 = UART TX (to modem RX)
- 24VDC opto inputs: GPIO22 = 24VDC power present, GPIO21 = 24V battery fault
  (fault originates separately from the 24VDC source)
- 220VAC opto inputs: GPIO13 = 220VAC mains available, GPIO32 = 220V SPD status;
  remaining 220V channels still being wired

### 5.3 OLTS — Oil Level and Temperature Sensor, PPMC Type Approval

- Lab engaged; **18-test schedule finalized** across three groups: sensor
  assembly, controller, controller EMC immunity.
- EMC test execution documents produced for **ESD (IEC 61000-4-2)**,
  **EFT/Burst (IEC 61000-4-4)** and **Surge (IEC 61000-4-5)** — in both formal
  spec and technician-executable checklist versions.
- IEC 61000 sub-part **editions are not named in the PPMC documents**; they must
  be agreed with PPMC D&S and the lab before booking.
- RFQ sent to **SGS** — Thal provides lab space/premises, SGS supplies equipment,
  procedures and reports.
- Field node design: an **RS-485 Modbus RTU slave** reporting PT100 temperature +
  oil-level switch (COM/NO dry contact) to customer meters that poll it, each end
  customer using its own slave ID / function code / register map. Decided to build
  a **custom smallest-size SMD board** (STM32G030 + MAX31865 RTD + opto-isolated
  DI + isolated RS-485) rather than off-the-shelf modules or a mapping gateway,
  targeting IEC 61000 compliance and JLCPCB fab.

### 5.4 Wire Crimp Defect Detection POC — Yazaki

- Android app (**Kotlin + OpenCV**) on Samsung Note10, developed through multiple
  rewrites.
- Working detection logic: red-pixel segmentation for PVC, copper-hue segmentation
  for bellmouth, bundle gate, least-squares bend measurement, 5-slot horizontal
  batch layout.
- Each slot reports: `OK`, `NG:BELL`, `NG:PVC-CU`, `NG:PVC-SHORT`, or `NG:BEND`.
- BOM updated: Raspberry Pi 5 8GB + Hailo-8L AI Kit retained; **Jetson Orin Nano
  removed**; ring lights qty 2 confirmed; blue/red backlight deferred.
- **V-groove self-seating comb** (black Delrin/acetal, 90° groove) recommended as
  the first wire orientation mechanism.
- Bought a **Logitech MX BRIO 4K** webcam for the POC rig: overhead stand + 2 white
  high-CRI lights + matte-grey comb fixture; focus/exposure locked in Logi Tune on
  the Mac.
- **Direction change:** moving detection off the phone to a desktop
  **Python + OpenCV** toolchain that learns tolerances from golden samples
  (copper-by-colour for bellmouths, geometry for PVC/bend). Compute will be a
  refurbished desktop PC, not a Jetson.

### 5.5 Wireless ECT — Electrical Check Tester, Korangi

- Architecture defined: modular **64-pin cards**, ESP32-S3 + four MCP23017
  expanders, 64 WS2812B RGB LEDs, 470Ω series + BAT54S clamp per pin, and a
  **mandatory single GND/REF pigtail between cards**.
- Test method: **drive-one / read-all continuity**; master netlist on a laptop via
  telnet-serial; **ESP-NOW** between cards.
- Scope: continuity only. Resistance/analog grading deferred.
- Comprehensive engineering README and SVG connection diagram produced.
- Open decisions before committing to matrix sizing: total test-point count, and
  whether hi-pot / IR is in scope.

### 5.6 Fuse Box Vision Inspection — Yazaki (started Oct 2026)

- Designing a **PC app** (golden-image compare per fuse box model, teach mode to
  add new models) plus an **STM32 control board** (limit switches, stamp push
  button, stamp relay/solenoid, buzzer).
- Uses an existing **Hikrobot MV-CH120-20GC GigE/PoE camera** with a 12mm 1/1.8"
  lens.
- Target: finish within 2 months. Develops and tests on the MacBook Pro.

### 5.7 On the horizon (not yet started)

- **Complete DCRC-TE STM32 production firmware integration** — all modules
  verified individually; full integration pending.
- **Resolve DCRC-TE ESP32-S3 prototype open questions** — input signal levels,
  pulse timing, comms scope.
- **PPMC EMC sub-part edition confirmation** with the lab before test booking.
- **Part Counter for Yazaki** — load cell + NAU7802 + ESP32-S3 weigh-counting with
  job card traceability. Identified as a clear quick win; PoC estimated 2–3 weeks.
- **FVI machine (Korangi)** — Phase 0 image collection gate (~$150) must pass
  before further investment; single traveling camera-head-on-rail architecture
  established.
- **PC-guided sub-assembly machine** — Raspberry Pi 5 / CM5 with DSI touchscreen +
  a single ESP32-S3 driving all jig boards via SPI/GPIO ribbon. Phase 1 BOM ~$1,700
  for a two-jig station.

---

## 6. Delivered to date

| Deliverable | Workstream |
|---|---|
| DCRC-TE STM32F411 bench build with all 5 module tests passing | DCRC-TE |
| DCRC-TE IEC 61000 safety-hardened perfboard | DCRC-TE |
| Confirmed STM32 production pin map + settled production architecture | DCRC-TE |
| Verified GSM connectivity to the KE/teinnovation apmsapi endpoint | DCRC-TE |
| TE-DCRC-v3 custom PCB design (KiCad) | DCRC-TE |
| DCRC-TE feasibility document + BOM | DCRC-TE prototype |
| KE scope sign-off package (auto-trip rules, access tiers, enclosure spec) | DCRC-TE |
| 18-test PPMC type-approval schedule | OLTS |
| EMC test execution documents — ESD, EFT/Burst, Surge (spec + technician checklist) | OLTS |
| RFQ issued to SGS | OLTS |
| OLTS custom SMD board architecture decision (STM32G030 + MAX31865 + isolated RS-485) | OLTS |
| Working Android crimp-inspection app with 5-slot batch detection | Yazaki crimp POC |
| POC imaging rig (MX BRIO + lighting + comb fixture) | Yazaki crimp POC |
| Updated vision BOM (Pi 5 + Hailo-8L) | Yazaki crimp POC |
| Wireless ECT engineering README + SVG connection diagram | Korangi ECT |
| Wireless ECT architecture definition (64-pin modular cards, ESP-NOW) | Korangi ECT |
| EV fleet telematics system — firmware, dashboards, Apps Script (prior project; see `skills/`) | EV telematics |

---

## 7. Engineering learnings (hard-won — treat as ground truth)

**Power and supply**
- **Diode-OR over changeover relay** for dual-supply priority: eliminates the
  5–10 ms transfer gap that resets the MCU/modem.

**RF and enclosures**
- **Metal enclosures block 4G** — the antenna must always be routed externally.

**Inputs and isolation**
- **AC opto ripple requires a software hold-window latch** (60 ms proven). It is
  not a hardware problem.
- Prefer **off-the-shelf isolation modules** over custom input stages where
  available (e.g. 8-channel AC 220V opto modules).

**STM32 / Arduino**
- **STM32duino pin macros:** the underscore form (`PB_11`, `PB_2`) is required for
  reserved/cautious pins. Compile-test every pin explicitly.
- **Relay drive at 3.3V logic:** the "INPUT float for OFF / OUTPUT LOW for ON"
  trick resolves the 3.3V→5V threshold issue on STM32.

**Displays / SPI**
- **MAX7219 in noisy environments:** atomic SPI transactions + self-healing
  register reassertion every 800 ms resolves corruption.

**Vision / mobile**
- **OpenCV on Android:** `Mat` fields must be `lateinit` and initialized after
  `OpenCVLoader.initDebug()` to avoid `UnsatisfiedLinkError`. A frame-size cap and
  UI throttling are required for responsiveness.
- **Computer vision is high-risk solo** — FVI, ergonomics scoring and co-pilot
  were explicitly avoided as solo pursuits; CV involvement is minimized across all
  projects.

**Test systems**
- **The GND/REF pigtail is mandatory in the wireless ECT:** the radio carries
  commands and results but cannot carry measurement current.

**Documentation and process**
- **Document fidelity for PPMC:** every test, standard, level and criterion must
  trace directly to source documents — no inferred additions.
- **Reuse validated stacks:** the ESP32-S3 + SIM7670G combination is proven from
  the EV fleet telematics project. Always reference prior project inventory before
  specifying new components.
- **Simplicity first:** ship a functional POC to build organizational credibility,
  then layer in safeties and redundancies.

---

## 8. What's in this bundle

```
PROJECT-EXPORT.md              ← this file
README-HOW-TO-IMPORT.md        ← step-by-step for the other account
memory/                        ← the raw memory files, ready to re-file
  profile.md
  overview.md
  workstreams.md
  learnings.md
  areas/dcrc-te-lbs-controller.md
skills/ev-fleet-telematics/    ← complete skill, upload as-is
  SKILL.md
  references/*.md  (8 files)
project-files/                 ← the 4 Yazaki plant photos to re-upload
```
