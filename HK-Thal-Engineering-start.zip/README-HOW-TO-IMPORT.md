# How to import this into your other Claude account

Five steps, about ten minutes.

## 1. Create the project

New project → name it **Thal Engineering Indigenous Development**. Paste the
description/custom-instructions block from section 1 of `PROJECT-EXPORT.md` into
the project's instructions field.

## 2. Add the knowledge

Upload **`PROJECT-EXPORT.md`** to the project's knowledge/files. That one file
carries the scope, people, stack, all seven workstreams with current state, the
delivered list, and the learnings — so any new chat in that project starts fully
briefed.

Optionally also upload the four photos in `project-files/` (the Yazaki
sub-assembly station and harness assembly line), since they were part of the
original project's files.

## 3. Install the skill

`skills/ev-fleet-telematics/` is a complete skill folder (SKILL.md + 8 reference
files). In the new account: Settings → Capabilities → Skills → upload it as a
zip of that folder. It carries the EV telematics engineering context — the
verified DALY 0xA5 opcodes, MOSFET frames, pin maps, Firebase/Sheets config and
gotchas — which the DCRC-TE work reuses.

To zip just that skill:

```
cd skills && zip -r ev-fleet-telematics.zip ev-fleet-telematics
```

## 4. Seed memory

The files in `memory/` are the raw memory entries. In the new account, start a
chat inside the new project and say:

> Save these to memory for this project, as separate files at the same paths.

…then paste the contents of each `memory/` file. Claude will re-file them.
(Alternatively skip this — step 2 already puts the same information in the
project knowledge, where it is always in context.)

## 5. Check it took

Start a fresh chat in the new project and ask something like *"what's the current
state of DCRC-TE and what's blocking the PPMC booking?"* If it answers with the
STM32F411 build status and the IEC 61000 sub-part edition issue, the import
worked.

---

### A note on what could not be exported automatically

Claude has no account-to-account transfer, so this bundle is the manual route.
What is **not** in it: the raw transcripts of past chats in the project (those
live only in the original account — the distilled state of each workstream is in
`PROJECT-EXPORT.md` instead), and any files you shared in individual chats rather
than attaching to the project itself. If there are specific chat artifacts you
want carried over — firmware files, the ECT README, the EMC test documents, the
feasibility doc and BOM — download them from the original account and drop them
into the new project's files alongside this export.
